/**
 * DevExtreme (bundles/modules/common.charts.js)
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
const DevExpress = require("./core");
DevExpress.common = DevExpress.common || {};
DevExpress.common.charts = require("../../common/charts");
module.exports = DevExpress.common.charts;
