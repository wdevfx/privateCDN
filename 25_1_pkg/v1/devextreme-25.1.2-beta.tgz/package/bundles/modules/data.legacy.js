/**
 * DevExtreme (bundles/modules/data.legacy.js)
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
require("../../data/errors");
require("../../data/data_source");
require("../../data/query");
require("../../data/abstract_store");
require("../../data/array_store");
require("../../data/custom_store");
require("../../data/local_store");
require("../../data/utils");
require("../../data/apply_changes");
require("../../core/guid");
require("../../core/utils/data");
require("../../data/endpoint_selector");
require("../../data/utils");
