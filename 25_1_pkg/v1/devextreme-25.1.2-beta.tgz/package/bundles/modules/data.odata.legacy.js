/**
 * DevExtreme (bundles/modules/data.odata.legacy.js)
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
require("./data");
require("../../data/odata/store");
require("../../data/odata/context");
require("../../data/odata/utils");
