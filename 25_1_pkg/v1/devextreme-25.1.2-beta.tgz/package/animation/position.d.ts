/**
* DevExtreme (animation/position.d.ts)
* Version: 25.1.2-beta
* Build date: Tue May 13 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import { PositionConfig } from '../common/core/animation';

export {
  CollisionResolution,
  CollisionResolutionCombination,
  PositionConfig,
} from '../common/core/animation';

/**
 * @deprecated Use the PositionConfig type from common/core/animation instead
 */
export interface positionConfig extends PositionConfig { }
