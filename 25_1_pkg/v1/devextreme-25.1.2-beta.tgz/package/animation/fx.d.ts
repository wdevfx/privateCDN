/**
* DevExtreme (animation/fx.d.ts)
* Version: 25.1.2-beta
* Build date: Tue May 13 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import { fx, AnimationConfig } from '../common/core/animation';

export {
  AnimationState,
  AnimationConfig,
  AnimationType,
} from '../common/core/animation';

/**
 * @deprecated Use the AnimationConfig type from common/core/animation instead
 */
export type animationConfig = AnimationConfig;

export default fx;
