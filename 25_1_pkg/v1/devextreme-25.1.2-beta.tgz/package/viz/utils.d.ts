/**
* DevExtreme (viz/utils.d.ts)
* Version: 25.1.2-beta
* Build date: Tue May 13 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
/**
 * The method to be called every time the active entry in the browser history is modified without reloading the current page.
 */
export function refreshPaths(): void;
