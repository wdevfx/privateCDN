/**
* DevExtreme (ui/card_view.d.ts)
* Version: 25.1.2-beta
* Build date: Tue May 13 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import { DeepPartial } from '../core';
import {
    DataType,
    HorizontalAlignment,
 Mode, SelectAllMode, SingleMultipleOrNone, SortOrder, template, ValidationRule,
} from '../common';
import { Format } from '../common/core/localization';
import { UserDefinedElement, DxElement } from '../core/element';
import {
 ColumnChooser, ColumnCustomizeTextArg, ColumnHeaderFilter, DataChange, DataErrorOccurredInfo, FilterPanel, FilterType, HeaderFilter, Pager, ScrollingBase, SearchPanel, SelectionColumnDisplayMode, Sorting,
} from '../common/grids';
import DataSource, { DataSourceLike } from '../data/data_source';
import Widget, { WidgetOptions } from './widget/ui.widget';
import { Cancelable, EventInfo, NativeEventInfo } from '../events';
import { dxToolbarItem, ToolbarItemLocation } from './toolbar';
import { dxSortableOptions } from './sortable';
import { dxLoadPanelOptions } from './load_panel';
import dxScrollable from './scroll_view/ui.scrollable';
import {
    Properties as PopupProperties,
  } from './popup';
import {
    Properties as FormProperties, SimpleItem,
  } from './form';
import { dxFilterBuilderOptions } from './filter_builder';

/**
 * 
 */
export type Paging = {
    /**
     * 
     */
    enabled?: boolean;
    /**
     * 
     */
    pageIndex?: number;
    /**
     * 
     */
    pageSize?: number;
};

/**
 * 
 */
export type RemoteOperations = {
    /**
     * 
     */
    filtering?: boolean;
    /**
     * 
     */
    paging?: boolean;
    /**
     * 
     */
    sorting?: boolean;
    /**
     * 
     */
    grouping?: boolean;
};

// #region Toolbar

export type PredefinedToolbarItem = 'columnChooserButton' | 'searchPanel' | 'addCardButton' | 'selectAllButton' | 'clearSelectionButton';

/**
 * 
 */
export type ToolbarItem = dxToolbarItem & {
    /**
     * 
     */
    name?: PredefinedToolbarItem | string;
    /**
     * 
     */
    location?: ToolbarItemLocation;
};

/**
 * 
 */
export type Toolbar = {
    /**
     * 
     */
    items?: Array<PredefinedToolbarItem | ToolbarItem>;
    /**
     * 
     */
    visible?: boolean | undefined;
    /**
     * 
     */
    disabled?: boolean;
    /**
     * 
     */
    multiline?: boolean;
};

// #endregion

// #region ColumnsController

/**
 * @deprecated Use FieldInfo instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type dxCardViewFieldInfo = FieldInfo;

/**
 * 
 */
export type FieldInfo = {
    /**
     * 
     */
    value: any;
    /**
     * 
     */
    displayValue: any;
    /**
     * 
     */
    text: string;
    /**
     * 
     */
    column: Column;
    /**
     * 
     */
    index: number;
    /**
     * 
     */
    card: CardInfo;
};

/**
 * 
 */
export type CardInfo<TCardData = unknown, TKey = unknown> = {
    /**
     * 
     */
    index: number;
    /**
     * 
     */
    columns: Column[];
    /**
     * 
     */
    fields: FieldInfo[];
    /**
     * 
     */
    key: TKey;
    /**
     * 
     */
    data: TCardData;
    /**
     * 
     */
    isSelected?: boolean;
    /**
     * 
     */
    values: any[];
};

/**
 * 
 */
export type ColumnProperties<TCardData = unknown, TKey = unknown> = {
    /**
     * 
     */
    alignment?: HorizontalAlignment | undefined;
    /**
     * 
     */
    allowEditing?: boolean;
    /**
     * 
     */
    allowFiltering?: boolean;
    /**
     * 
     */
    allowHeaderFiltering?: boolean;
    /**
     * 
     */
    allowHiding?: boolean;
    /**
     * 
     */
    allowReordering?: boolean;
    /**
     * 
     */
    allowSearch?: boolean;
    /**
     * 
     */
    allowSorting?: boolean;
    /**
     * 
     */
    calculateFieldValue?: ((this: Column, cardData: TCardData) => any);
    /**
     * 
     */
    calculateDisplayValue?: ((this: Column, cardData: TCardData) => any);
    /**
     * 
     */
    calculateFilterExpression?: ((this: Column, filterValue: any, selectedFilterOperation: string | null, target: string) => string | Array<any> | Function);
    /**
     * 
     */
    calculateSortValue?: string | ((this: Column, cardData: TCardData) => any);
    /**
     * 
     */
    caption?: string | undefined;
    /**
     * 
     */
    customizeText?: ((this: Column, cellInfo: ColumnCustomizeTextArg) => string);
    /**
     * 
     */
    dataField?: string | undefined;
    /**
     * 
     */
    dataType?: DataType | undefined;
    /**
     * 
     */
    editorOptions?: any;
    /**
     * 
     */
    falseText?: string;
    /**
     * 
     */
    filterType?: FilterType;
    /**
     * 
     */
    filterValue?: any | undefined;
    /**
     * 
     */
    filterValues?: Array<any>;
    /**
     * 
     */
    formItem?: SimpleItem; // TODO: sync with impl
    /**
     * 
     */
    format?: Format;
    /**
     * 
     */
    headerFilter?: ColumnHeaderFilter | undefined;
    /**
     * 
     */
    name?: string | undefined;
    /**
     * 
     */
    setFieldValue?: ((this: Column, newData: DeepPartial<TCardData>, value: any, currentCardData: TCardData) => void | PromiseLike<void>);
    /**
     * 
     */
    showInColumnChooser?: boolean;
    /**
     * 
     */
    sortIndex?: number | undefined;
    /**
     * 
     */
    sortOrder?: SortOrder | undefined;
    /**
     * 
     */
    sortingMethod?: ((this: Column, value1: any, value2: any) => number) | undefined;
    /**
     * 
     */
    trueText?: string;
    /**
     * 
     */
    validationRules?: Array<ValidationRule>;
    /**
     * 
     */
    visible?: boolean;
    /**
     * 
     */
    visibleIndex?: number | undefined;
    /**
     * 
     */
    fieldTemplate?: template | ((data: FieldTemplateData, container: DxElement) => string | UserDefinedElement);
    /**
     * 
     */
    fieldCaptionTemplate?: template | ((data: FieldTemplateData, container: DxElement) => string | UserDefinedElement);
    /**
     * 
     */
    fieldValueTemplate?: template | ((data: FieldTemplateData, container: DxElement) => string | UserDefinedElement);
    /**
     * 
     */
    headerItemTemplate?: template | ((data: ColumnTemplateData<TCardData, TKey>, container: DxElement) => string | UserDefinedElement);
    /**
     * 
     */
    headerItemCssClass?: string;
};

/**
 * 
 */
export type Column<TCardData = unknown, TKey = unknown> = ColumnProperties<TCardData, TKey> & {
    defaultCalculateFilterExpression: NonNullable<ColumnProperties['calculateFilterExpression']>;
    defaultSetFieldValue: NonNullable<ColumnProperties['setFieldValue']>;
    defaultCalculateFieldValue: NonNullable<ColumnProperties['calculateFieldValue']>;
};

// #endregion

// #region HeaderPanel

export type HeaderPanelDragging = Pick<dxSortableOptions, 'dropFeedbackMode' | 'scrollSpeed' | 'scrollSensitivity' | 'onDragChange' | 'onDragEnd' | 'onDragMove' | 'onDragStart' | 'onRemove' | 'onReorder'>;

/**
 * 
 */
export type HeaderPanel<TCardData = unknown, TKey = unknown> = {
    /**
     * 
     */
    dragging?: HeaderPanelDragging;
    /**
     * 
     */
    visible?: boolean;
    /**
     * 
     */
    itemTemplate?: template | ((data: ColumnTemplateData<TCardData, TKey>, container: DxElement) => string | UserDefinedElement);
    /**
     * 
     */
    itemCssClass?: string;
};

// #endregion

// #region ContentView

/**
 * @docid
 */
type WithCardInfo = {
    /**
     * 
     */
    readonly card: CardInfo;
    /**
     * 
     */
    readonly cardElement: DxElement;
};

/**
 * @docid
 */
type WithFieldCaptionInfo = {
    /**
     * 
     */
    readonly field: FieldInfo;
    /**
     * 
     */
    readonly fieldCaptionElement: DxElement;
};

/**
 * @docid
 */
type WithFieldValueInfo = {
    /**
     * 
     */
    readonly field: FieldInfo;
    /**
     * 
     */
    readonly fieldValueElement: DxElement;
};

/**
 * 
 */
export type CardClickEvent = NativeEventInfo<dxCardView, PointerEvent | MouseEvent | TouchEvent> & WithCardInfo;

/**
 * 
 */
export type CardDblClickEvent = NativeEventInfo<dxCardView, PointerEvent | MouseEvent | TouchEvent> & WithCardInfo;

/**
 * 
 */
export type CardPreparedEvent = EventInfo<dxCardView> & WithCardInfo;

/**
 * 
 */
export type FieldCaptionClickEvent = NativeEventInfo<dxCardView, PointerEvent | MouseEvent | TouchEvent> & WithFieldCaptionInfo;

/**
 * 
 */
export type FieldCaptionDblClickEvent = NativeEventInfo<dxCardView, PointerEvent | MouseEvent | TouchEvent> & WithFieldCaptionInfo;

/**
 * 
 */
export type FieldValuePreparedEvent = EventInfo<dxCardView> & WithFieldValueInfo;

/**
 * 
 */
export type FieldValueClickEvent = NativeEventInfo<dxCardView, PointerEvent | MouseEvent | TouchEvent> & WithFieldValueInfo;

/**
 * 
 */
export type FieldValueDblClickEvent = NativeEventInfo<dxCardView, PointerEvent | MouseEvent | TouchEvent> & WithFieldValueInfo;

/**
 * 
 */
export type FieldCaptionPreparedEvent = EventInfo<dxCardView> & WithFieldCaptionInfo;

/**
 * 
 */
export type CardHoverChangedEvent = EventInfo<dxCardView> & WithCardInfo & {
    /**
     * 
     */
    eventType: string;
};

/**
 * 
 */
export type FieldTemplateData = {
    /**
     * 
     */
    field: FieldInfo;
};

/**
 * 
 */
export type CardTemplateData = {
    card: CardInfo;
};

/**
 * 
 */
export type ColumnTemplateData<TCardData = unknown, TKey = unknown> = {
    column: Column<TCardData, TKey>;
};

/**
 * 
 */
export type CardCover<TCardData = unknown> = { // TODO: sync with impl
    /**
     * 
     */
    imageExpr: string | ((data: TCardData) => string);
    /**
     * 
     */
    altExpr: string | ((data: TCardData) => string);
    /**
     * 
     */
    maxHeight?: number;
    /**
     * 
     */
    aspectRatio?: string;
    /**
     * 
     */
    template?: template | ((data: CardTemplateData, container: DxElement) => string | UserDefinedElement);
};

export type CardHeaderPredefinedItem = 'selectionCheckBox' | 'updateButton' | 'deleteButton';

/**
 * 
 */
export type CardHeaderItem = dxToolbarItem & {
    /**
     * 
     */
    name?: CardHeaderPredefinedItem | string;
    /**
     * 
     */
    location?: ToolbarItemLocation;
};

/**
 * 
 */
export type CardHeader = { // TODO: sync with impl
    /**
     * 
     */
    visible?: boolean;
    /**
     * 
     */
    items?: Array<CardHeaderPredefinedItem | CardHeaderItem>;
    /**
     * 
     */
    template?: template | ((data: CardTemplateData) => string | UserDefinedElement);
};

// #endregion

// #region Editing

// Conflicts with recently introduced chat.d.ts Editing after merge
// Use a computed / parent-based docids until agreement
// Specified docid similar to other grids

/**
 * @deprecated Use Editing instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type dxCardViewEditing<TCardData=unknown, TKey=unknown> = Editing<TCardData, TKey>;

/**
 * 
 */
export type Editing<TCardData=unknown, TKey=unknown> = { // TODO: sync with impl
    /**
     * 
     */
    allowAdding?: boolean;
    /**
     * 
     */
    allowDeleting?: boolean;
    /**
     * 
     */
    allowUpdating?: boolean;
    /**
     * 
     */
    changes?: DataChange<TCardData, TKey>[];
    /**
     * 
     */
    confirmDelete?: boolean;
    /**
     * 
     */
    editCardKey?: TKey | null;
    /**
     * 
     */
    form?: FormProperties;
    /**
     * 
     */
    popup?: PopupProperties;
};

/**
 * 
 */
export type EditCanceledEvent = EventInfo<dxCardView> & {
    /**
     * 
     */
    changes: DataChange[];
};

/**
 * 
 */
export type EditCancelingEvent = EventInfo<dxCardView> & Cancelable & {
    /**
     * 
     */
    changes: DataChange[];
};

/**
 * 
 */
export type EditingStartEvent<TCardData = unknown, TKey = unknown> = EventInfo<dxCardView> & Cancelable & {
    /**
     * 
     */
    data: TCardData;
    /**
     * 
     */
    key: TKey;
};

/**
 * 
 */
export type InitNewCardEvent<TCardData = unknown> = EventInfo<dxCardView> & {
    /**
     * 
     */
    data: DeepPartial<TCardData>;
    /**
     * 
     */
    promise?: PromiseLike<void>;
};

/**
 * 
 */
export type CardInsertedEvent<TCardData = unknown> = EventInfo<dxCardView> & {
    /**
     * 
     */
    data: DeepPartial<TCardData>;
};

/**
 * 
 */
export type CardInsertingEvent<TCardData = unknown> = EventInfo<dxCardView> & Cancelable & {
    /**
     * 
     */
    data: DeepPartial<TCardData>;
};

/**
 * 
 */
export type CardRemovedEvent<TCardData = unknown, TKey = unknown> = EventInfo<dxCardView> & {
    /**
     * 
     */
    data: TCardData;
    /**
     * 
     */
    key: TKey;
};

/**
 * 
 */
export type CardRemovingEvent<TCardData = unknown, TKey = unknown> = EventInfo<dxCardView> & Cancelable & {
    /**
     * 
     */
    data: TCardData;
    /**
     * 
     */
    key: TKey;
};

/**
 * 
 */
export type CardUpdatedEvent<TCardData = unknown, TKey = unknown> = EventInfo<dxCardView> & {
    /**
     * 
     */
    data: TCardData;
    /**
     * 
     */
    key: TKey;
};

/**
 * 
 */
export type CardUpdatingEvent<TCardData = unknown, TKey = unknown> = EventInfo<dxCardView> & Cancelable & {
    /**
     * 
     */
    key: TKey;
    /**
     * 
     */
    oldData: TCardData;
    /**
     * 
     */
    newData: DeepPartial<TCardData>;
};

/**
 * 
 */
export type CardSavedEvent = EventInfo<dxCardView> & {
    /**
     * 
     */
    changes: DataChange[];
};

/**
 * 
 */
export type CardSavingEvent = EventInfo<dxCardView> & Cancelable & {
    /**
     * 
     */
    promise?: PromiseLike<void>;
    /**
     * 
     */
    changes: DataChange[];
};

// #endregion

// #region Selection

/**
 * 
 */
export type SelectionConfiguration = {
    /**
     * 
     */
    allowSelectAll?: boolean;
    /**
     * 
     */
    mode?: SingleMultipleOrNone;
    /**
     * 
     */
    selectAllMode?: SelectAllMode;
    /**
     * 
     */
    showCheckBoxesMode?: SelectionColumnDisplayMode;
};

/**
 * 
 */
export type SelectionChangingEvent<TCardData = unknown, TKey = unknown> = EventInfo<dxCardView> & Cancelable & {
    /**
     * 
     */
    selectedCardsData: Array<TCardData>;
    /**
     * 
     */
    selectedCardKeys: Array<TKey>;
    /**
     * 
     */
    currentSelectedCardKeys: Array<TKey>;
    /**
     * 
     */
    currentDeselectedCardKeys: Array<TKey>;
};

/**
 * 
 */
export type SelectionChangedEvent<TCardData = unknown, TKey = unknown> = EventInfo<dxCardView> & {
    /**
     * 
     */
    selectedCardsData: Array<TCardData>;
    /**
     * 
     */
    selectedCardKeys: Array<TKey>;
    /**
     * 
     */
    currentSelectedCardKeys: Array<TKey>;
    /**
     * 
     */
    currentDeselectedCardKeys: Array<TKey>;
};

// #endregion

// #region ContextMenu

export type ContextMenuTarget = 'toolbar' | 'headerPanel' | 'content';

/**
 * 
 */
export type ContextMenuPreparingEvent<TCardData = unknown> = EventInfo<dxCardView> & {
  /**
   * 
   */
  items?: any[];
  /**
   * 
   */
  readonly target: ContextMenuTarget;
  /**
   * 
   */
  readonly targetElement: DxElement;
  /**
   * 
   */
  readonly columnIndex?: number;
  /**
   * 
   */
  readonly column?: Column;
  /**
   * 
   */
  readonly cardIndex?: number;
  /**
   * 
   */
  readonly card?: TCardData;
};

// #endregion

// #region KBN

/**
 * 
 */
export type FocusedCardChanged = EventInfo<dxCardView> & WithCardInfo;

// #endregion

/**
 * 
 * @deprecated 
 */
export interface dxCardViewOptions<TCardData = unknown, TKey = unknown> extends WidgetOptions<dxCardView> {

    // #region DataController

    /**
     * 
     */
    dataSource?: DataSourceLike<TCardData, TKey>;
    /**
     * 
     */
    paging?: Paging;
    /**
     * 
     */
    keyExpr?: string | string[]; // can be undefined because of default?
    /**
     * 
     */
    remoteOperations?: RemoteOperations | boolean | Mode;
    /**
     * 
     */
    onDataErrorOccurred?: (e: EventInfo<dxCardView> & DataErrorOccurredInfo) => void;

    // #endregion

    // #region Pager

    /**
     * 
     */
    pager?: Pager;

    // #endregion

    // #region ColumnsController

    /**
     * 
     */
    columns?: (ColumnProperties<TCardData, TKey> | string)[];

    /**
     * 
     */
    allowColumnReordering?: boolean;

    // #endregion

    // #region HeaderPanel

    /**
     * 
     */
    headerPanel?: HeaderPanel<TCardData, TKey>;

    // #endregion

    // #region ContentView

    /**
     * 
     */
    scrolling?: Pick<ScrollingBase, 'scrollByContent' | 'scrollByThumb' | 'showScrollbar' | 'useNative'>;
    /**
     * 
     */
    errorRowEnabled?: boolean;
    /**
     * 
     */
    loadPanel?: dxLoadPanelOptions;
    /**
     * 
     */
    noDataText?: string;
    /**
     * 
     */
    noDataTemplate?: template | ((e: { text: string }, container: DxElement) => string | UserDefinedElement);
    /**
     * 
     */
    cardsPerRow?: number | Mode;
    /**
     * 
     */
    cardMinWidth?: number;
    /**
     * 
     */
    cardMaxWidth?: number;
    /**
     * 
     */
    wordWrapEnabled?: boolean;
    /**
     * 
     */
    cardCover?: CardCover<TCardData>;
    /**
     * 
     */
    cardTemplate?: template | ((data: CardTemplateData, container: DxElement) => string | UserDefinedElement);
    /**
     * 
     */
    cardContentTemplate?: template | ((data: CardTemplateData, container: DxElement) => string | UserDefinedElement);
    /**
     * 
     */
    fieldHintEnabled?: boolean; // TODO: sync with impl
    /**
     * 
     */
    onCardClick?: (e: CardClickEvent) => void; // TODO: sync with impl
    /**
     * 
     */
    onCardDblClick?: (e: CardDblClickEvent) => void; // TODO: sync with impl
    /**
     * 
     */
    onCardPrepared?: (e: CardPreparedEvent) => void; // TODO: sync with impl
    /**
     * 
     */
    onFieldCaptionClick?: (e: FieldCaptionClickEvent) => void; // TODO: sync with impl
    /**
     * 
     */
    onFieldCaptionDblClick?: (e: FieldCaptionDblClickEvent) => void; // TODO: sync with impl
    /**
     * 
     */
    onFieldCaptionPrepared?: (e: FieldCaptionPreparedEvent) => void; // TODO: sync with impl
    /**
     * 
     */
    onFieldValueClick?: (e: FieldValueClickEvent) => void; // TODO: sync with impl
    /**
     * 
     */
    onFieldValueDblClick?: (e: FieldValueDblClickEvent) => void; // TODO: sync with impl
    /**
     * 
     */
    onFieldValuePrepared?: (e: FieldValuePreparedEvent) => void; // TODO: sync with impl
    /**
     * 
     */
    onCardHoverChanged?: (e: CardHoverChangedEvent) => void; // TODO: sync with impl
    /**
     * 
     */
    cardFooterTemplate?: template | ((data: CardTemplateData, container: DxElement) => string | UserDefinedElement);
    /**
     * 
     */
    cardHeader?: CardHeader;

    /**
     * 
     */
    hoverStateEnabled?: boolean; // TODO: sync with impl

    // #endregion

    // #region Toolbar

    /**
     * 
     */
    toolbar?: Toolbar;

    // #endregion

    sorting?: Sorting;

    /**
     * 
     */
    filterValue?: string | Array<any> | Function;
    /**
     * 
     */
    filterBuilderPopup?: PopupProperties;
    /**
     * 
     */
    filterBuilder?: dxFilterBuilderOptions;
    /**
     * 
     */
    filterPanel?: FilterPanel<dxCardView>;
    /**
     * 
     */
    columnChooser?: ColumnChooser;
    /**
     * 
     */
    searchPanel?: SearchPanel;
    /**
     * 
     */
    headerFilter?: HeaderFilter;

    // #region Editing

    /**
     * 
     */
    editing?: Editing<TCardData, TKey>;
    /**
     * 
     */
    onEditCanceled?: (e: EditCanceledEvent) => void;
    /**
     * 
     */
    onEditCanceling?: (e: EditCancelingEvent) => void;
    /**
     * 
     */
    onEditingStart?: (e: EditingStartEvent) => void;
    /**
     * 
     */
    onInitNewCard?: (e: InitNewCardEvent<TCardData>) => void;
    /**
     * 
     */
    onCardInserted?: (e: CardInsertedEvent) => void;
    /**
     * 
     */
    onCardInserting?: (e: CardInsertingEvent) => void;
    /**
     * 
     */
    onCardRemoved?: (e: CardRemovedEvent) => void;
    /**
     * 
     */
    onCardRemoving?: (e: CardRemovingEvent) => void;
    /**
     * 
     */
    onCardUpdated?: (e: CardUpdatedEvent) => void;
    /**
     * 
     */
    onCardUpdating?: (e: CardUpdatingEvent) => void;
    /**
     * 
     */
    onCardSaved?: (e: CardSavedEvent) => void;
    /**
     * 
     */
    onCardSaving?: (e: CardSavingEvent) => void;

    // #endregion

    // #region Selection

    /**
     * 
     */
    selectedCardKeys?: Array<TKey>;
    /**
     * 
     */
    selection?: SelectionConfiguration;
    /**
     * 
     */
    onSelectionChanging?: (e: SelectionChangingEvent) => void;
    /**
     * 
     */
    onSelectionChanged?: (e: SelectionChangedEvent) => void;

    // #endregion

    // #region KBN

    /**
     * 
     */
    onFocusedCardChanged?: (e: FocusedCardChanged) => void;

    // #endregion

    /**
     * 
     */
    onContextMenuPreparing?: ((e: ContextMenuPreparingEvent<TCardData>) => void);
}

/**
 * 
 */
export default class dxCardView<TCardData = unknown, TKey = unknown> extends Widget<Properties> {
    /**
     * 
     */
    getCardElement(cardIndex: number): DxElement;
    /**
     * 
     */
    getVisibleCards(): CardInfo[];
    /**
     * 
     */
    getCardIndexByKey(key: TKey): number;
    /**
     * 
     */
    getKeyByCardIndex(cardIndex: number): TKey;
    /**
     * 
     */
    getScrollable(): dxScrollable;
    /**
     * 
     */
    beginCustomLoading(text?: string): void;
    /**
     * 
     */
    endCustomLoading(): void;
    /**
     * 
     */
    clearSorting(): void;
    /**
     * 
     */
    getCombinedFilter(): any;
    /**
     * 
     */
    clearFilter(): void;
    /**
     * 
     */
    hideColumnChooser(): void;
    /**
     * 
     */
    showColumnChooser(): void;
    /**
     * 
     */
    searchByText(text: string): void;

    // #region Editing

    /**
     * 
     */
    addCard(): void;
    /**
     * 
     */
    cancelEditData(): void;
    /**
     * 
     */
    deleteCard(cardIndex: number): void;
    /**
     * 
     */
    editCard(cardIndex: number): void;
    /**
     * 
     */
    hasEditData(): void; // boolean?
    /**
     * 
     */
    saveEditData(): void;

    // #endregion

    // #region DataController

    /**
      * 
      */
     byKey(key: TKey): TCardData;
    /**
     * 
     */
    getDataSource(): DataSource<TCardData, TKey>;
    /**
     * 
     */
    keyOf(obj: TCardData): TKey;
    /**
     * 
     */
    pageCount(): number;
    /**
     * 
     */
    pageIndex(): number;
    /**
     * 
     */
    pageIndex(value: number): void;
    /**
     * 
     */
    pageSize(): number;
    /**
     * 
     */
    pageSize(value: number): void;
    /**
     * 
     */
    totalCount(): number;

    // #endregion

    // #region Selection

    /**
     * 
     */
    selectCards(keys: Array<TKey>, preserve: boolean): void;
    /**
     * 
     */
    deselectCards(keys: Array<TKey>): void;
    /**
     * 
     */
    selectAll(): void;
    /**
     * 
     */
    deselectAll(): void;
    /**
     * 
     */
    clearSelection(): void;
    /**
     * 
     */
    getSelectedCardsData(): Array<TCardData>; // TODO: sync with impl
    /**
     * 
     */
    getSelectedCardKeys(): Array<TKey>; // TODO: sync with impl
    /**
     * 
     */
    isCardSelected(key: TKey): boolean;

    // #endregion
}

// usually imported / re-exports are right after heading imports,
// plus, some of these types are already exported with direct declarations

export {
    Sorting,
    Pager,
    DataErrorOccurredInfo,
    PopupProperties,
    FormProperties,
    ColumnChooser,
    SearchPanel,
    HeaderFilter,
};

export type ExplicitTypes<TCardData = unknown, TKey = unknown> = {
    Properties: Properties<TCardData, TKey>;
};

export type Properties<TCardData = unknown, TKey = unknown> = dxCardViewOptions<TCardData, TKey>;
