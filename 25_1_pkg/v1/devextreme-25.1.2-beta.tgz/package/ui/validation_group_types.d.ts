/**
* DevExtreme (ui/validation_group_types.d.ts)
* Version: 25.1.2-beta
* Build date: Tue May 13 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  ValidationStatus,
  DisposingEvent,
  InitializedEvent,
  OptionChangedEvent,
  ValidationResult,
  Properties,
} from './validation_group';
