/**
* DevExtreme (ui/tooltip.d.ts)
* Version: 25.1.2-beta
* Build date: Tue May 13 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import {
    Cancelable,
    EventInfo,
    InitializedEventInfo,
    ChangedOptionInfo,
} from '../common/core/events';

import dxPopover, {
    dxPopoverOptions,
} from './popover';

/**
 * The type of the contentReady event handler&apos;s argument.
 */
export type ContentReadyEvent = EventInfo<dxTooltip>;

/**
 * The type of the disposing event handler&apos;s argument.
 */
export type DisposingEvent = EventInfo<dxTooltip>;

/**
 * The type of the hiding event handler&apos;s argument.
 */
export type HidingEvent = Cancelable & EventInfo<dxTooltip>;

/**
 * The type of the hidden event handler&apos;s argument.
 */
export type HiddenEvent = EventInfo<dxTooltip>;

/**
 * The type of the initialized event handler&apos;s argument.
 */
export type InitializedEvent = InitializedEventInfo<dxTooltip>;

/**
 * The type of the optionChanged event handler&apos;s argument.
 */
export type OptionChangedEvent = EventInfo<dxTooltip> & ChangedOptionInfo;

/**
 * The type of the showing event handler&apos;s argument.
 */
export type ShowingEvent = Cancelable & EventInfo<dxTooltip>;

/**
 * The type of the shown event handler&apos;s argument.
 */
export type ShownEvent = EventInfo<dxTooltip>;

/**
 * 
 * @deprecated 
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export interface dxTooltipOptions extends dxPopoverOptions<dxTooltip> { }
/**
 * The Tooltip UI component displays a tooltip for a specified element on the page.
 */
export default class dxTooltip extends dxPopover<dxTooltipOptions> { }

export type Properties = dxTooltipOptions;

/**
 * @deprecated use Properties instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type Options = dxTooltipOptions;


