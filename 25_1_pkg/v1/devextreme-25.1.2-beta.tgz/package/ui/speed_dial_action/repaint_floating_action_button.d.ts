/**
* DevExtreme (ui/speed_dial_action/repaint_floating_action_button.d.ts)
* Version: 25.1.2-beta
* Build date: Tue May 13 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
/**
 * Repaints the Floating Action Button.
 */
export default function repaintFloatingActionButton(): void;
