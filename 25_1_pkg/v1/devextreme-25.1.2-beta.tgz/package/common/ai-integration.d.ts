/**
* DevExtreme (common/ai-integration.d.ts)
* Version: 25.1.2-beta
* Build date: Tue May 13 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
/**
 * A prompt for the AI model.
 */
export type Prompt = {
  /**
   * Direct instructions for the AI model.
   */
  system?: string;
  /**
   * A user message to the AI model.
   */
  user?: string;
};

/**
 * An object with request parameters for AI service.
 */
export type RequestParams = {
  /**
   * The prompt sent to the AI model.
   */
  prompt: Prompt;
};

/**
 * An object returned by the sendRequest function.
 */
export type Response = {
  /**
   * A promise that resolves with the final AI-generated text.
   */
  promise: Promise<string>;
  /**
   * A function that cancels the request.
   */
  abort: () => void;
};

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type ChangeStyleCommandParams = {
  text: string;
  writingStyle: string;
};

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type ChangeToneCommandParams = {
  text: string;
  tone: string;
};

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type ExecuteCommandParams = {
  text: string;
};

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type ExpandCommandParams = {
  text: string;
};

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type ProofreadCommandParams = {
  text: string;
};

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type ShortenCommandParams = {
 text: string;
};

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type SummarizeCommandParams = {
  text: string;
};

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type TranslateCommandParams = {
  text: string;
  lang: string;
};

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type ChangeStyleCommandResult = string;

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type ChangeToneCommandResult = string;

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type ExecuteCommandResult = string;

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type ExpandCommandResult = string;

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type ProofreadCommandResult = string;

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type ShortenCommandResult = string;

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type SummarizeCommandResult = string;

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type TranslateCommandResult = string;

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type RequestCallbacks<T> = {
  onChunk?: (chunk: string) => void;
  onComplete?: (finalResponse: T) => void;
  onError?: (error: Error) => void;
};

/**
 * An object responsible for sending requests to an AI service.
 */
export type AIProvider = {
  /**
   * A function that sends a request to an AI service.
   */
  sendRequest: (params: RequestParams) => Response;
};

/**
 * A class that activates AI services in DevExpress UI components.
 */
export class AIIntegration {
  /**
   * @docid
   * @param provider
   */
  constructor(provider: AIProvider);
  changeStyle(params: ChangeStyleCommandParams, callbacks: RequestCallbacks<ChangeStyleCommandResult>): () => void;
  changeTone(params: ChangeToneCommandParams, callbacks: RequestCallbacks<ChangeToneCommandResult>): () => void;
  execute(params: ExecuteCommandParams, callbacks: RequestCallbacks<ExecuteCommandResult>): () => void;
  expand(params: ExpandCommandParams, callbacks: RequestCallbacks<ExpandCommandResult>): () => void;
  proofread(params: ProofreadCommandParams, callbacks: RequestCallbacks<ProofreadCommandResult>): () => void;
  shorten(params: ShortenCommandParams, callbacks: RequestCallbacks<ShortenCommandResult>): () => void;
  summarize(params: SummarizeCommandParams, callbacks: RequestCallbacks<SummarizeCommandResult>): () => void;
  translate(params: TranslateCommandParams, callbacks: RequestCallbacks<TranslateCommandResult>): () => void;
}
