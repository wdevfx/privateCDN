/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxSparkline, { Properties } from "devextreme/viz/sparkline";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { DisposingEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, TooltipHiddenEvent, TooltipShownEvent } from "devextreme/viz/sparkline";
import type { DashStyle, Font as ChartsFont } from "devextreme/common/charts";
import type { Format as CommonFormat, template } from "devextreme/common";
import type { Format as LocalizationFormat } from "devextreme/common/core/localization";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type ISparklineOptionsNarrowedEvents = {
    onDisposing?: ((e: DisposingEvent) => void);
    onDrawn?: ((e: DrawnEvent) => void);
    onExported?: ((e: ExportedEvent) => void);
    onExporting?: ((e: ExportingEvent) => void);
    onFileSaving?: ((e: FileSavingEvent) => void);
    onIncidentOccurred?: ((e: IncidentOccurredEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onTooltipHidden?: ((e: TooltipHiddenEvent) => void);
    onTooltipShown?: ((e: TooltipShownEvent) => void);
};
type ISparklineOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, ISparklineOptionsNarrowedEvents> & IHtmlOptions>;
interface SparklineRef {
    instance: () => dxSparkline;
}
declare const Sparkline: (props: React.PropsWithChildren<ISparklineOptions> & {
    ref?: Ref<SparklineRef>;
}) => ReactElement | null;
type IBorderProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const Border: ((props: IBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFontProps = React.PropsWithChildren<{
    color?: string;
    family?: string;
    opacity?: number;
    size?: number | string;
    weight?: number;
}>;
declare const Font: ((props: IFontProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    family?: string | undefined;
    opacity?: number | undefined;
    size?: string | number | undefined;
    weight?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const Format: ((props: IFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMarginProps = React.PropsWithChildren<{
    bottom?: number;
    left?: number;
    right?: number;
    top?: number;
}>;
declare const Margin: ((props: IMarginProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    bottom?: number | undefined;
    left?: number | undefined;
    right?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShadowProps = React.PropsWithChildren<{
    blur?: number;
    color?: string;
    offsetX?: number;
    offsetY?: number;
    opacity?: number;
}>;
declare const Shadow: ((props: IShadowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    blur?: number | undefined;
    color?: string | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISizeProps = React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
}>;
declare const Size: ((props: ISizeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITooltipProps = React.PropsWithChildren<{
    arrowLength?: number;
    border?: Record<string, any> | {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: string;
    container?: any | string | undefined;
    contentTemplate?: ((pointsInfo: any, element: any) => string | any) | template | undefined;
    cornerRadius?: number;
    customizeTooltip?: ((pointsInfo: any) => Record<string, any>) | undefined;
    enabled?: boolean;
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    interactive?: boolean;
    opacity?: number | undefined;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    zIndex?: number | undefined;
    contentRender?: (...params: any) => React.ReactNode;
    contentComponent?: React.ComponentType<any>;
}>;
declare const Tooltip: ((props: ITooltipProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    arrowLength?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    container?: any | string | undefined;
    contentTemplate?: template | ((pointsInfo: any, element: any) => string | any) | undefined;
    cornerRadius?: number | undefined;
    customizeTooltip?: ((pointsInfo: any) => Record<string, any>) | undefined;
    enabled?: boolean | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    interactive?: boolean | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    zIndex?: number | undefined;
    contentRender?: ((...params: any) => React.ReactNode) | undefined;
    contentComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default Sparkline;
export { Sparkline, ISparklineOptions, SparklineRef, Border, IBorderProps, Font, IFontProps, Format, IFormatProps, Margin, IMarginProps, Shadow, IShadowProps, Size, ISizeProps, Tooltip, ITooltipProps };
import type * as SparklineTypes from 'devextreme/viz/sparkline_types';
export { SparklineTypes };
