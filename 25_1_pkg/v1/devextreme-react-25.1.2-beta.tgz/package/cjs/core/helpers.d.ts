/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

import { IElementDescriptor } from './configuration/react/element';
import { TemplateInstantiationModel } from './types';
export declare function generateID(): string;
export declare class DoubleKeyMap<TKey1, TKey2, TValue> {
    private readonly _map;
    set({ key1, key2 }: {
        key1: TKey1;
        key2: TKey2;
    }, value: TValue): void;
    get({ key1, key2 }: {
        key1: TKey1;
        key2: TKey2;
    }): TValue | undefined;
    delete({ key1, key2 }: {
        key1: TKey1;
        key2: TKey2;
    }): void;
    clear(): void;
    get empty(): boolean;
    [Symbol.iterator](): Generator<[{
        key1: TKey1;
        key2: TKey2;
    }, TValue]>;
}
export declare class TemplateInstantiationModels extends DoubleKeyMap<any, HTMLElement, TemplateInstantiationModel> {
}
export declare function capitalizeFirstLetter(text: string): string;
export declare function hasExpectedChildren(elementDescriptor: IElementDescriptor): boolean;
