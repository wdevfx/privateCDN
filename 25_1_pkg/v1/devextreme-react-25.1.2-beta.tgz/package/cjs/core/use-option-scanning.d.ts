/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

import { IOptionElement } from './configuration/react/element';
import { IConfigNode } from './configuration/config-node';
import { NestedOptionContextContent } from './contexts';
export declare function useOptionScanning(optionElement: IOptionElement, getHasTemplate: () => boolean, parentUpdateToken: symbol, parentType: 'option' | 'component'): [
    IConfigNode,
    NestedOptionContextContent
];
