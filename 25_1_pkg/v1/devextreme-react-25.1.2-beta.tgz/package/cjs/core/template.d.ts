/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

import * as React from 'react';
interface ITemplateMeta {
    tmplOption: string;
    component: string;
    render: string;
}
interface ITemplateProps {
    name: string;
    component?: any;
    render?: any;
    children?: any;
}
interface ITemplateArgs {
    data: any;
    index?: number;
}
declare const Template: React.FC<ITemplateProps>;
declare function findProps(child: React.ReactElement): ITemplateProps | undefined;
export { ITemplateMeta, ITemplateProps, ITemplateArgs, Template, findProps, };
