/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

import * as React from 'react';
import { ReactElement } from 'react';
import { ComponentProps } from './component';
declare const DX_REMOVE_EVENT = "dxremove";
type ComponentBaseProps = ComponentProps & {
    renderChildren?: () => React.ReactNode;
};
interface ComponentBaseRef {
    getInstance: () => any;
    getElement: () => HTMLDivElement | undefined;
    createWidget: (element?: Element) => void;
}
interface IHtmlOptions {
    id?: string;
    className?: string;
    style?: any;
}
declare const ComponentBase: <P extends IHtmlOptions>(props: P & {
    WidgetClass?: any;
    isPortalComponent?: boolean | undefined;
    defaults?: Record<string, string> | undefined;
    templateProps?: import("./template").ITemplateMeta[] | undefined;
    expectedChildren?: Record<string, import("./configuration/react/element").IExpectedChild> | undefined;
    subscribableOptions?: string[] | undefined;
    independentEvents?: string[] | undefined;
    useRequestAnimationFrameFlag?: boolean | undefined;
    clearExtensions?: (() => void) | undefined;
    beforeCreateWidget?: ((element?: Element | undefined) => void) | undefined;
    afterCreateWidget?: ((element?: Element | undefined) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    renderChildren?: (() => React.ReactNode) | undefined;
} & {
    ref?: React.Ref<ComponentBaseRef> | undefined;
}) => ReactElement | null;
export { IHtmlOptions, ComponentBaseRef, ComponentBase, ComponentBaseProps, DX_REMOVE_EVENT, };
