/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

import { IOptionElement } from './react/element';
interface IConfigNode {
    parentNode?: IConfigNode | undefined;
    index?: number | undefined;
    templates: ITemplate[];
    readonly name: string;
    readonly predefinedOptions: Record<string, any>;
    readonly initialOptions: Record<string, any>;
    readonly options: Record<string, any>;
    readonly configs: Record<string, IConfigNode>;
    readonly configCollections: Record<string, IConfigNode[]>;
}
interface ITemplate {
    optionName: string;
    isAnonymous: boolean;
    type: 'component' | 'render' | 'children';
    content: any;
}
interface NodeConfigBuilder {
    node: IConfigNode;
    configCollectionMaps: Record<string, Record<string, number>>;
    addChildNode: (name: string, childNode: IConfigNode) => void;
    addTemplate: (template: ITemplate) => void;
    getConfigCollectionData: (name: string) => [IConfigNode[], Record<string, number>];
    updateAnonymousTemplates: (hasTemplateRendered: boolean) => void;
    addCollectionNode: (name: string, collectionNode: IConfigNode, collectionNodeKey: number) => void;
    wrapTemplate: (template: ITemplate) => ITemplate;
}
declare function buildNodeFullName(node: IConfigNode): string;
declare const createConfigBuilder: (optionElement: IOptionElement, parentFullName: string) => NodeConfigBuilder;
export { buildNodeFullName, createConfigBuilder, IConfigNode, ITemplate, };
