/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

export { ExplicitTypes } from "devextreme/ui/validation_summary";
import * as React from "react";
import { Ref, ReactElement } from "react";
import dxValidationSummary, { Properties } from "devextreme/ui/validation_summary";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { CollectionWidgetItem } from "devextreme/ui/collection/ui.collection_widget.base";
import type { ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent } from "devextreme/ui/validation_summary";
import type { template } from "devextreme/common";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IValidationSummaryOptionsNarrowedEvents<TItem = any, TKey = any> = {
    onContentReady?: ((e: ContentReadyEvent<TItem, TKey>) => void);
    onDisposing?: ((e: DisposingEvent<TItem, TKey>) => void);
    onInitialized?: ((e: InitializedEvent<TItem, TKey>) => void);
    onItemClick?: ((e: ItemClickEvent<TItem, TKey>) => void);
};
type IValidationSummaryOptions<TItem = any, TKey = any> = React.PropsWithChildren<ReplaceFieldTypes<Properties<TItem, TKey>, IValidationSummaryOptionsNarrowedEvents<TItem, TKey>> & IHtmlOptions & {
    dataSource?: Properties<TItem, TKey>["dataSource"];
    itemRender?: (...params: any) => React.ReactNode;
    itemComponent?: React.ComponentType<any>;
    defaultItems?: Array<any | CollectionWidgetItem | string>;
    onItemsChange?: (value: Array<any | CollectionWidgetItem | string>) => void;
}>;
interface ValidationSummaryRef<TItem = any, TKey = any> {
    instance: () => dxValidationSummary<TItem, TKey>;
}
declare const ValidationSummary: <TItem = any, TKey = any>(props: ReplaceFieldTypes<Properties<TItem, TKey>, IValidationSummaryOptionsNarrowedEvents<TItem, TKey>> & IHtmlOptions & {
    dataSource?: import("devextreme/data/data_source").DataSourceLike<TItem, TKey> | null | undefined;
    itemRender?: ((...params: any) => React.ReactNode) | undefined;
    itemComponent?: React.ComponentType<any> | undefined;
    defaultItems?: any[] | undefined;
    onItemsChange?: ((value: Array<any | CollectionWidgetItem | string>) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    ref?: React.Ref<ValidationSummaryRef<TItem, TKey>> | undefined;
}) => ReactElement | null;
type IItemProps = React.PropsWithChildren<{
    disabled?: boolean;
    html?: string;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const Item: ((props: IItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    disabled?: boolean | undefined;
    html?: string | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default ValidationSummary;
export { ValidationSummary, IValidationSummaryOptions, ValidationSummaryRef, Item, IItemProps };
import type * as ValidationSummaryTypes from 'devextreme/ui/validation_summary_types';
export { ValidationSummaryTypes };
