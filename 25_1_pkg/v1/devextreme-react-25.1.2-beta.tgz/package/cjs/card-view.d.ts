/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

export { ExplicitTypes } from "devextreme/ui/card_view";
import * as React from "react";
import { Ref, ReactElement } from "react";
import dxCardView, { Properties } from "devextreme/ui/card_view";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { CardClickEvent, CardDblClickEvent, CardInsertedEvent, CardInsertingEvent, CardPreparedEvent, CardRemovedEvent, CardRemovingEvent, CardSavedEvent, CardSavingEvent, CardUpdatedEvent, CardUpdatingEvent, ContextMenuPreparingEvent, EditCanceledEvent, EditCancelingEvent, EditingStartEvent, FieldCaptionClickEvent, FieldCaptionDblClickEvent, FieldCaptionPreparedEvent, FieldValueClickEvent, FieldValueDblClickEvent, FieldValuePreparedEvent, InitNewCardEvent, SelectionChangingEvent, CardTemplateData, CardHeaderItem as CardViewCardHeaderItem, CardHeaderPredefinedItem, FieldTemplateData, ColumnTemplateData, PredefinedToolbarItem, ToolbarItem as CardViewToolbarItem } from "devextreme/ui/card_view";
import type { AnimationConfig, CollisionResolution, PositionConfig, AnimationState, AnimationType, CollisionResolutionCombination } from "devextreme/common/core/animation";
import type { ValidationRuleType, HorizontalAlignment, VerticalAlignment, template, ToolbarItemLocation, ToolbarItemComponent, DataType, Format as CommonFormat, SortOrder, ComparisonOperator, Direction, PositionAlignment, Mode, DisplayMode, SingleMultipleOrNone, SelectAllMode } from "devextreme/common";
import type { LocateInMenuMode, ShowTextMode } from "devextreme/ui/toolbar";
import type { CollectionWidgetItem } from "devextreme/ui/collection/ui.collection_widget.base";
import type { DataChangeType, FilterType, DataChange, PagerPageSize, SelectionColumnDisplayMode } from "devextreme/common/grids";
import type { Format as LocalizationFormat } from "devextreme/common/core/localization";
import type { dxFormSimpleItem, FormItemComponent, FormItemType, LabelLocation } from "devextreme/ui/form";
import type { dxFilterBuilderField, FieldInfo, FilterBuilderOperation, dxFilterBuilderCustomOperation, GroupOperation, ContentReadyEvent, DisposingEvent, EditorPreparedEvent, EditorPreparingEvent, InitializedEvent, OptionChangedEvent, ValueChangedEvent } from "devextreme/ui/filter_builder";
import type { DataSourceOptions } from "devextreme/data/data_source";
import type { Store } from "devextreme/data/store";
import type { ContentReadyEvent as LoadPanelContentReadyEvent, DisposingEvent as LoadPanelDisposingEvent, InitializedEvent as LoadPanelInitializedEvent, OptionChangedEvent as LoadPanelOptionChangedEvent, HiddenEvent, HidingEvent, ShowingEvent, ShownEvent } from "devextreme/ui/load_panel";
import type { event } from "devextreme/events/events.types";
import type dxForm from "devextreme/ui/form";
import type * as CommonTypes from "devextreme/common";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type ICardViewOptionsNarrowedEvents<TCardData = any, TKey = any> = {
    onCardClick?: ((e: CardClickEvent) => void);
    onCardDblClick?: ((e: CardDblClickEvent) => void);
    onCardInserted?: ((e: CardInsertedEvent<TCardData>) => void);
    onCardInserting?: ((e: CardInsertingEvent<TCardData>) => void);
    onCardPrepared?: ((e: CardPreparedEvent) => void);
    onCardRemoved?: ((e: CardRemovedEvent<TCardData, TKey>) => void);
    onCardRemoving?: ((e: CardRemovingEvent<TCardData, TKey>) => void);
    onCardSaved?: ((e: CardSavedEvent) => void);
    onCardSaving?: ((e: CardSavingEvent) => void);
    onCardUpdated?: ((e: CardUpdatedEvent<TCardData, TKey>) => void);
    onCardUpdating?: ((e: CardUpdatingEvent<TCardData, TKey>) => void);
    onContextMenuPreparing?: ((e: ContextMenuPreparingEvent<TCardData>) => void);
    onEditCanceled?: ((e: EditCanceledEvent) => void);
    onEditCanceling?: ((e: EditCancelingEvent) => void);
    onEditingStart?: ((e: EditingStartEvent<TCardData, TKey>) => void);
    onFieldCaptionClick?: ((e: FieldCaptionClickEvent) => void);
    onFieldCaptionDblClick?: ((e: FieldCaptionDblClickEvent) => void);
    onFieldCaptionPrepared?: ((e: FieldCaptionPreparedEvent) => void);
    onFieldValueClick?: ((e: FieldValueClickEvent) => void);
    onFieldValueDblClick?: ((e: FieldValueDblClickEvent) => void);
    onFieldValuePrepared?: ((e: FieldValuePreparedEvent) => void);
    onInitNewCard?: ((e: InitNewCardEvent<TCardData>) => void);
    onSelectionChanging?: ((e: SelectionChangingEvent<TCardData, TKey>) => void);
};
type ICardViewOptions<TCardData = any, TKey = any> = React.PropsWithChildren<ReplaceFieldTypes<Properties<TCardData, TKey>, ICardViewOptionsNarrowedEvents<TCardData, TKey>> & IHtmlOptions & {
    dataSource?: Properties<TCardData, TKey>["dataSource"];
    cardContentRender?: (...params: any) => React.ReactNode;
    cardContentComponent?: React.ComponentType<any>;
    cardFooterRender?: (...params: any) => React.ReactNode;
    cardFooterComponent?: React.ComponentType<any>;
    cardRender?: (...params: any) => React.ReactNode;
    cardComponent?: React.ComponentType<any>;
    noDataRender?: (...params: any) => React.ReactNode;
    noDataComponent?: React.ComponentType<any>;
    defaultFilterValue?: Array<any> | (() => any) | string;
    defaultSelectedCardKeys?: Array<any>;
    onFilterValueChange?: (value: Array<any> | (() => any) | string) => void;
    onSelectedCardKeysChange?: (value: Array<any>) => void;
}>;
interface CardViewRef<TCardData = any, TKey = any> {
    instance: () => dxCardView<TCardData, TKey>;
}
declare const CardView: <TCardData = any, TKey = any>(props: ReplaceFieldTypes<Properties<TCardData, TKey>, ICardViewOptionsNarrowedEvents<TCardData, TKey>> & IHtmlOptions & {
    dataSource?: import("devextreme/data/data_source").DataSourceLike<TCardData, TKey> | undefined;
    cardContentRender?: ((...params: any) => React.ReactNode) | undefined;
    cardContentComponent?: React.ComponentType<any> | undefined;
    cardFooterRender?: ((...params: any) => React.ReactNode) | undefined;
    cardFooterComponent?: React.ComponentType<any> | undefined;
    cardRender?: ((...params: any) => React.ReactNode) | undefined;
    cardComponent?: React.ComponentType<any> | undefined;
    noDataRender?: ((...params: any) => React.ReactNode) | undefined;
    noDataComponent?: React.ComponentType<any> | undefined;
    defaultFilterValue?: string | any[] | (() => any) | undefined;
    defaultSelectedCardKeys?: any[] | undefined;
    onFilterValueChange?: ((value: Array<any> | (() => any) | string) => void) | undefined;
    onSelectedCardKeysChange?: ((value: Array<any>) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    ref?: React.Ref<CardViewRef<TCardData, TKey>> | undefined;
}) => ReactElement | null;
type IAnimationProps = React.PropsWithChildren<{
    hide?: AnimationConfig;
    show?: AnimationConfig;
}>;
declare const Animation: ((props: IAnimationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    hide?: AnimationConfig | undefined;
    show?: AnimationConfig | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAsyncRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    reevaluate?: boolean;
    type?: ValidationRuleType;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: string | number;
    }) => any);
}>;
declare const AsyncRule: ((props: IAsyncRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    reevaluate?: boolean | undefined;
    type?: ValidationRuleType | undefined;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: string | number;
    }) => any) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAtProps = React.PropsWithChildren<{
    x?: HorizontalAlignment;
    y?: VerticalAlignment;
}>;
declare const At: ((props: IAtProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: HorizontalAlignment | undefined;
    y?: VerticalAlignment | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBoundaryOffsetProps = React.PropsWithChildren<{
    x?: number;
    y?: number;
}>;
declare const BoundaryOffset: ((props: IBoundaryOffsetProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: number | undefined;
    y?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICardCoverProps = React.PropsWithChildren<{
    altExpr?: ((data: any) => string) | string;
    aspectRatio?: string;
    imageExpr?: ((data: any) => string) | string;
    maxHeight?: number;
    template?: ((data: CardTemplateData, container: any) => string | any) | template;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const CardCover: ((props: ICardCoverProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    altExpr?: string | ((data: any) => string) | undefined;
    aspectRatio?: string | undefined;
    imageExpr?: string | ((data: any) => string) | undefined;
    maxHeight?: number | undefined;
    template?: template | ((data: CardTemplateData, container: any) => string | any) | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICardHeaderProps = React.PropsWithChildren<{
    items?: Array<CardViewCardHeaderItem | CardHeaderPredefinedItem>;
    template?: ((data: CardTemplateData) => string | any) | template;
    visible?: boolean;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const CardHeader: ((props: ICardHeaderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    items?: (CardViewCardHeaderItem | CardHeaderPredefinedItem)[] | undefined;
    template?: template | ((data: CardTemplateData) => string | any) | undefined;
    visible?: boolean | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICardHeaderItemProps = React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean;
    html?: string;
    locateInMenu?: LocateInMenuMode;
    location?: ToolbarItemLocation;
    menuItemTemplate?: (() => string | any) | template;
    name?: CardHeaderPredefinedItem | string;
    options?: any;
    showText?: ShowTextMode;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    widget?: ToolbarItemComponent;
    menuItemRender?: (...params: any) => React.ReactNode;
    menuItemComponent?: React.ComponentType<any>;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const CardHeaderItem: ((props: ICardHeaderItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean | undefined;
    html?: string | undefined;
    locateInMenu?: LocateInMenuMode | undefined;
    location?: ToolbarItemLocation | undefined;
    menuItemTemplate?: template | (() => string | any) | undefined;
    name?: string | undefined;
    options?: any;
    showText?: ShowTextMode | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    widget?: ToolbarItemComponent | undefined;
    menuItemRender?: ((...params: any) => React.ReactNode) | undefined;
    menuItemComponent?: React.ComponentType<any> | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IChangeProps = React.PropsWithChildren<{
    data?: any;
    insertAfterKey?: any;
    insertBeforeKey?: any;
    key?: any;
    type?: DataChangeType;
}>;
declare const Change: ((props: IChangeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    data?: any;
    insertAfterKey?: any;
    insertBeforeKey?: any;
    key?: any;
    type?: DataChangeType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICollisionProps = React.PropsWithChildren<{
    x?: CollisionResolution;
    y?: CollisionResolution;
}>;
declare const Collision: ((props: ICollisionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: CollisionResolution | undefined;
    y?: CollisionResolution | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    allowEditing?: boolean;
    allowFiltering?: boolean;
    allowHeaderFiltering?: boolean;
    allowHiding?: boolean;
    allowReordering?: boolean;
    allowSearch?: boolean;
    allowSorting?: boolean;
    calculateDisplayValue?: ((cardData: any) => any);
    calculateFieldValue?: ((cardData: any) => any);
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | Array<any> | (() => void));
    calculateSortValue?: ((cardData: any) => any) | string;
    caption?: string | undefined;
    customizeText?: ((cellInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string);
    dataField?: string | undefined;
    dataType?: DataType | undefined;
    editorOptions?: any;
    falseText?: string;
    fieldCaptionTemplate?: ((data: FieldTemplateData, container: any) => string | any) | template;
    fieldTemplate?: ((data: FieldTemplateData, container: any) => string | any) | template;
    fieldValueTemplate?: ((data: FieldTemplateData, container: any) => string | any) | template;
    filterType?: FilterType;
    filterValue?: any | undefined;
    filterValues?: Array<any>;
    format?: LocalizationFormat;
    formItem?: dxFormSimpleItem;
    headerFilter?: Record<string, any>;
    headerItemCssClass?: string;
    headerItemTemplate?: ((data: ColumnTemplateData, container: any) => string | any) | template;
    name?: string | undefined;
    setFieldValue?: ((newData: any, value: any, currentCardData: any) => any);
    showInColumnChooser?: boolean;
    sortIndex?: number | undefined;
    sortingMethod?: ((value1: any, value2: any) => number) | undefined;
    sortOrder?: SortOrder | undefined;
    trueText?: string;
    validationRules?: Array<CommonTypes.ValidationRule>;
    visible?: boolean;
    visibleIndex?: number | undefined;
    defaultFilterValue?: any | undefined;
    onFilterValueChange?: (value: any | undefined) => void;
    defaultFilterValues?: Array<any>;
    onFilterValuesChange?: (value: Array<any>) => void;
    defaultSortIndex?: number | undefined;
    onSortIndexChange?: (value: number | undefined) => void;
    defaultSortOrder?: SortOrder | undefined;
    onSortOrderChange?: (value: SortOrder | undefined) => void;
    defaultVisible?: boolean;
    onVisibleChange?: (value: boolean) => void;
    defaultVisibleIndex?: number | undefined;
    onVisibleIndexChange?: (value: number | undefined) => void;
    fieldCaptionRender?: (...params: any) => React.ReactNode;
    fieldCaptionComponent?: React.ComponentType<any>;
    fieldRender?: (...params: any) => React.ReactNode;
    fieldComponent?: React.ComponentType<any>;
    fieldValueRender?: (...params: any) => React.ReactNode;
    fieldValueComponent?: React.ComponentType<any>;
    headerItemRender?: (...params: any) => React.ReactNode;
    headerItemComponent?: React.ComponentType<any>;
}>;
declare const Column: ((props: IColumnProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    allowEditing?: boolean | undefined;
    allowFiltering?: boolean | undefined;
    allowHeaderFiltering?: boolean | undefined;
    allowHiding?: boolean | undefined;
    allowReordering?: boolean | undefined;
    allowSearch?: boolean | undefined;
    allowSorting?: boolean | undefined;
    calculateDisplayValue?: ((cardData: any) => any) | undefined;
    calculateFieldValue?: ((cardData: any) => any) | undefined;
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | Array<any> | (() => void)) | undefined;
    calculateSortValue?: string | ((cardData: any) => any) | undefined;
    caption?: string | undefined;
    customizeText?: ((cellInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string) | undefined;
    dataField?: string | undefined;
    dataType?: DataType | undefined;
    editorOptions?: any;
    falseText?: string | undefined;
    fieldCaptionTemplate?: template | ((data: FieldTemplateData, container: any) => string | any) | undefined;
    fieldTemplate?: template | ((data: FieldTemplateData, container: any) => string | any) | undefined;
    fieldValueTemplate?: template | ((data: FieldTemplateData, container: any) => string | any) | undefined;
    filterType?: FilterType | undefined;
    filterValue?: any | undefined;
    filterValues?: any[] | undefined;
    format?: LocalizationFormat;
    formItem?: dxFormSimpleItem | undefined;
    headerFilter?: Record<string, any> | undefined;
    headerItemCssClass?: string | undefined;
    headerItemTemplate?: template | ((data: ColumnTemplateData, container: any) => string | any) | undefined;
    name?: string | undefined;
    setFieldValue?: ((newData: any, value: any, currentCardData: any) => any) | undefined;
    showInColumnChooser?: boolean | undefined;
    sortIndex?: number | undefined;
    sortingMethod?: ((value1: any, value2: any) => number) | undefined;
    sortOrder?: SortOrder | undefined;
    trueText?: string | undefined;
    validationRules?: CommonTypes.ValidationRule[] | undefined;
    visible?: boolean | undefined;
    visibleIndex?: number | undefined;
    defaultFilterValue?: any | undefined;
    onFilterValueChange?: ((value: any | undefined) => void) | undefined;
    defaultFilterValues?: any[] | undefined;
    onFilterValuesChange?: ((value: Array<any>) => void) | undefined;
    defaultSortIndex?: number | undefined;
    onSortIndexChange?: ((value: number | undefined) => void) | undefined;
    defaultSortOrder?: SortOrder | undefined;
    onSortOrderChange?: ((value: SortOrder | undefined) => void) | undefined;
    defaultVisible?: boolean | undefined;
    onVisibleChange?: ((value: boolean) => void) | undefined;
    defaultVisibleIndex?: number | undefined;
    onVisibleIndexChange?: ((value: number | undefined) => void) | undefined;
    fieldCaptionRender?: ((...params: any) => React.ReactNode) | undefined;
    fieldCaptionComponent?: React.ComponentType<any> | undefined;
    fieldRender?: ((...params: any) => React.ReactNode) | undefined;
    fieldComponent?: React.ComponentType<any> | undefined;
    fieldValueRender?: ((...params: any) => React.ReactNode) | undefined;
    fieldValueComponent?: React.ComponentType<any> | undefined;
    headerItemRender?: ((...params: any) => React.ReactNode) | undefined;
    headerItemComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICompareRuleProps = React.PropsWithChildren<{
    comparisonTarget?: (() => any);
    comparisonType?: ComparisonOperator;
    ignoreEmptyValue?: boolean;
    message?: string;
    type?: ValidationRuleType;
}>;
declare const CompareRule: ((props: ICompareRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    comparisonTarget?: (() => any) | undefined;
    comparisonType?: ComparisonOperator | undefined;
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICustomOperationProps = React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, field: dxFilterBuilderField) => string | (() => any) | Array<any>);
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string);
    dataTypes?: Array<DataType> | undefined;
    editorTemplate?: ((conditionInfo: {
        field: dxFilterBuilderField;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | template;
    hasValue?: boolean;
    icon?: string | undefined;
    name?: string | undefined;
    editorRender?: (...params: any) => React.ReactNode;
    editorComponent?: React.ComponentType<any>;
}>;
declare const CustomOperation: ((props: ICustomOperationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, field: dxFilterBuilderField) => string | (() => any) | Array<any>) | undefined;
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string) | undefined;
    dataTypes?: Array<DataType> | undefined;
    editorTemplate?: template | ((conditionInfo: {
        field: dxFilterBuilderField;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | undefined;
    hasValue?: boolean | undefined;
    icon?: string | undefined;
    name?: string | undefined;
    editorRender?: ((...params: any) => React.ReactNode) | undefined;
    editorComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICustomRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    reevaluate?: boolean;
    type?: ValidationRuleType;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: string | number;
    }) => boolean);
}>;
declare const CustomRule: ((props: ICustomRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    reevaluate?: boolean | undefined;
    type?: ValidationRuleType | undefined;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: string | number;
    }) => boolean) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IEditingProps = React.PropsWithChildren<{
    allowAdding?: boolean;
    allowDeleting?: boolean;
    allowUpdating?: boolean;
    changes?: Array<DataChange>;
    confirmDelete?: boolean;
    editCardKey?: any;
    form?: Record<string, any>;
    popup?: Record<string, any>;
}>;
declare const Editing: ((props: IEditingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowAdding?: boolean | undefined;
    allowDeleting?: boolean | undefined;
    allowUpdating?: boolean | undefined;
    changes?: DataChange<any, any>[] | undefined;
    confirmDelete?: boolean | undefined;
    editCardKey?: any;
    form?: Record<string, any> | undefined;
    popup?: Record<string, any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IEmailRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    type?: ValidationRuleType;
}>;
declare const EmailRule: ((props: IEmailRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFieldProps = React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string) => string | (() => any) | Array<any>);
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string);
    dataField?: string | undefined;
    dataType?: DataType;
    editorOptions?: any;
    editorTemplate?: ((conditionInfo: {
        field: dxFilterBuilderField;
        filterOperation: string;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | template;
    falseText?: string;
    filterOperations?: Array<FilterBuilderOperation | string>;
    format?: LocalizationFormat;
    lookup?: Record<string, any> | {
        allowClearing?: boolean;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
    };
    name?: string | undefined;
    trueText?: string;
    editorRender?: (...params: any) => React.ReactNode;
    editorComponent?: React.ComponentType<any>;
}>;
declare const Field: ((props: IFieldProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string) => string | (() => any) | Array<any>) | undefined;
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string) | undefined;
    dataField?: string | undefined;
    dataType?: DataType | undefined;
    editorOptions?: any;
    editorTemplate?: template | ((conditionInfo: {
        field: dxFilterBuilderField;
        filterOperation: string;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | undefined;
    falseText?: string | undefined;
    filterOperations?: string[] | undefined;
    format?: LocalizationFormat;
    lookup?: Record<string, any> | {
        allowClearing?: boolean | undefined;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: string | ((data: any) => string) | undefined;
        valueExpr?: string | ((data: any) => string | number | boolean) | undefined;
    } | undefined;
    name?: string | undefined;
    trueText?: string | undefined;
    editorRender?: ((...params: any) => React.ReactNode) | undefined;
    editorComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFilterBuilderProps = React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean;
    allowHierarchicalFields?: boolean;
    bindingOptions?: Record<string, any>;
    customOperations?: Array<dxFilterBuilderCustomOperation>;
    disabled?: boolean;
    elementAttr?: Record<string, any>;
    fields?: Array<dxFilterBuilderField>;
    filterOperationDescriptions?: Record<string, any> | {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        isBlank?: string;
        isNotBlank?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    };
    focusStateEnabled?: boolean;
    groupOperationDescriptions?: Record<string, any> | {
        and?: string;
        notAnd?: string;
        notOr?: string;
        or?: string;
    };
    groupOperations?: Array<GroupOperation>;
    height?: (() => number | string) | number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    maxGroupLevel?: number | undefined;
    onContentReady?: ((e: ContentReadyEvent) => void);
    onDisposing?: ((e: DisposingEvent) => void);
    onEditorPrepared?: ((e: EditorPreparedEvent) => void);
    onEditorPreparing?: ((e: EditorPreparingEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onOptionChanged?: ((e: OptionChangedEvent) => void);
    onValueChanged?: ((e: ValueChangedEvent) => void);
    rtlEnabled?: boolean;
    tabIndex?: number;
    value?: Array<any> | (() => any) | string;
    visible?: boolean;
    width?: (() => number | string) | number | string | undefined;
    defaultValue?: Array<any> | (() => any) | string;
    onValueChange?: (value: Array<any> | (() => any) | string) => void;
}>;
declare const FilterBuilder: ((props: IFilterBuilderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean | undefined;
    allowHierarchicalFields?: boolean | undefined;
    bindingOptions?: Record<string, any> | undefined;
    customOperations?: dxFilterBuilderCustomOperation[] | undefined;
    disabled?: boolean | undefined;
    elementAttr?: Record<string, any> | undefined;
    fields?: dxFilterBuilderField[] | undefined;
    filterOperationDescriptions?: Record<string, any> | {
        between?: string | undefined;
        contains?: string | undefined;
        endsWith?: string | undefined;
        equal?: string | undefined;
        greaterThan?: string | undefined;
        greaterThanOrEqual?: string | undefined;
        isBlank?: string | undefined;
        isNotBlank?: string | undefined;
        lessThan?: string | undefined;
        lessThanOrEqual?: string | undefined;
        notContains?: string | undefined;
        notEqual?: string | undefined;
        startsWith?: string | undefined;
    } | undefined;
    focusStateEnabled?: boolean | undefined;
    groupOperationDescriptions?: Record<string, any> | {
        and?: string | undefined;
        notAnd?: string | undefined;
        notOr?: string | undefined;
        or?: string | undefined;
    } | undefined;
    groupOperations?: GroupOperation[] | undefined;
    height?: (() => number | string) | number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    maxGroupLevel?: number | undefined;
    onContentReady?: ((e: ContentReadyEvent) => void) | undefined;
    onDisposing?: ((e: DisposingEvent) => void) | undefined;
    onEditorPrepared?: ((e: EditorPreparedEvent) => void) | undefined;
    onEditorPreparing?: ((e: EditorPreparingEvent) => void) | undefined;
    onInitialized?: ((e: InitializedEvent) => void) | undefined;
    onOptionChanged?: ((e: OptionChangedEvent) => void) | undefined;
    onValueChanged?: ((e: ValueChangedEvent) => void) | undefined;
    rtlEnabled?: boolean | undefined;
    tabIndex?: number | undefined;
    value?: string | any[] | (() => any) | undefined;
    visible?: boolean | undefined;
    width?: (() => number | string) | number | string | undefined;
    defaultValue?: string | any[] | (() => any) | undefined;
    onValueChange?: ((value: Array<any> | (() => any) | string) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFilterOperationDescriptionsProps = React.PropsWithChildren<{
    between?: string;
    contains?: string;
    endsWith?: string;
    equal?: string;
    greaterThan?: string;
    greaterThanOrEqual?: string;
    isBlank?: string;
    isNotBlank?: string;
    lessThan?: string;
    lessThanOrEqual?: string;
    notContains?: string;
    notEqual?: string;
    startsWith?: string;
}>;
declare const FilterOperationDescriptions: ((props: IFilterOperationDescriptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    between?: string | undefined;
    contains?: string | undefined;
    endsWith?: string | undefined;
    equal?: string | undefined;
    greaterThan?: string | undefined;
    greaterThanOrEqual?: string | undefined;
    isBlank?: string | undefined;
    isNotBlank?: string | undefined;
    lessThan?: string | undefined;
    lessThanOrEqual?: string | undefined;
    notContains?: string | undefined;
    notEqual?: string | undefined;
    startsWith?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const Format: ((props: IFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormItemProps = React.PropsWithChildren<{
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    dataField?: string | undefined;
    editorOptions?: any | undefined;
    editorType?: FormItemComponent;
    helpText?: string | undefined;
    isRequired?: boolean | undefined;
    itemType?: FormItemType;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: ((itemData: {
            component: dxForm;
            dataField: string;
            editorOptions: any;
            editorType: string;
            name: string;
            text: string;
        }, itemElement: any) => string | any) | template;
        text?: string | undefined;
        visible?: boolean;
    };
    name?: string | undefined;
    template?: ((data: {
        component: dxForm;
        dataField: string;
        editorOptions: Record<string, any>;
        editorType: string;
        name: string;
    }, itemElement: any) => string | any) | template;
    validationRules?: Array<CommonTypes.ValidationRule>;
    visible?: boolean;
    visibleIndex?: number | undefined;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const FormItem: ((props: IFormItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    dataField?: string | undefined;
    editorOptions?: any | undefined;
    editorType?: FormItemComponent | undefined;
    helpText?: string | undefined;
    isRequired?: boolean | undefined;
    itemType?: FormItemType | undefined;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        location?: LabelLocation | undefined;
        showColon?: boolean | undefined;
        template?: template | ((itemData: {
            component: dxForm;
            dataField: string;
            editorOptions: any;
            editorType: string;
            name: string;
            text: string;
        }, itemElement: any) => string | any) | undefined;
        text?: string | undefined;
        visible?: boolean | undefined;
    } | undefined;
    name?: string | undefined;
    template?: template | ((data: {
        component: dxForm;
        dataField: string;
        editorOptions: Record<string, any>;
        editorType: string;
        name: string;
    }, itemElement: any) => string | any) | undefined;
    validationRules?: CommonTypes.ValidationRule[] | undefined;
    visible?: boolean | undefined;
    visibleIndex?: number | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFromProps = React.PropsWithChildren<{
    left?: number;
    opacity?: number;
    position?: PositionConfig;
    scale?: number;
    top?: number;
}>;
declare const From: ((props: IFromProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    left?: number | undefined;
    opacity?: number | undefined;
    position?: PositionConfig | undefined;
    scale?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IGroupOperationDescriptionsProps = React.PropsWithChildren<{
    and?: string;
    notAnd?: string;
    notOr?: string;
    or?: string;
}>;
declare const GroupOperationDescriptions: ((props: IGroupOperationDescriptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    and?: string | undefined;
    notAnd?: string | undefined;
    notOr?: string | undefined;
    or?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHeaderPanelProps = React.PropsWithChildren<{
    dragging?: Record<string, any>;
    itemCssClass?: string;
    itemTemplate?: ((data: ColumnTemplateData, container: any) => string | any) | template;
    visible?: boolean;
    itemRender?: (...params: any) => React.ReactNode;
    itemComponent?: React.ComponentType<any>;
}>;
declare const HeaderPanel: ((props: IHeaderPanelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    dragging?: Record<string, any> | undefined;
    itemCssClass?: string | undefined;
    itemTemplate?: template | ((data: ColumnTemplateData, container: any) => string | any) | undefined;
    visible?: boolean | undefined;
    itemRender?: ((...params: any) => React.ReactNode) | undefined;
    itemComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHideProps = React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void);
    delay?: number;
    direction?: Direction | undefined;
    duration?: number;
    easing?: string;
    from?: AnimationState;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void);
    to?: AnimationState;
    type?: AnimationType;
}>;
declare const Hide: ((props: IHideProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void) | undefined;
    delay?: number | undefined;
    direction?: Direction | undefined;
    duration?: number | undefined;
    easing?: string | undefined;
    from?: AnimationState | undefined;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void) | undefined;
    to?: AnimationState | undefined;
    type?: AnimationType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IItemProps = React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean;
    html?: string;
    locateInMenu?: LocateInMenuMode;
    location?: ToolbarItemLocation;
    menuItemTemplate?: (() => string | any) | template;
    name?: CardHeaderPredefinedItem | string | PredefinedToolbarItem;
    options?: any;
    showText?: ShowTextMode;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    widget?: ToolbarItemComponent;
    menuItemRender?: (...params: any) => React.ReactNode;
    menuItemComponent?: React.ComponentType<any>;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const Item: ((props: IItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean | undefined;
    html?: string | undefined;
    locateInMenu?: LocateInMenuMode | undefined;
    location?: ToolbarItemLocation | undefined;
    menuItemTemplate?: template | (() => string | any) | undefined;
    name?: string | undefined;
    options?: any;
    showText?: ShowTextMode | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    widget?: ToolbarItemComponent | undefined;
    menuItemRender?: ((...params: any) => React.ReactNode) | undefined;
    menuItemComponent?: React.ComponentType<any> | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILabelProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment;
    location?: LabelLocation;
    showColon?: boolean;
    template?: ((itemData: {
        component: dxForm;
        dataField: string;
        editorOptions: any;
        editorType: string;
        name: string;
        text: string;
    }, itemElement: any) => string | any) | template;
    text?: string | undefined;
    visible?: boolean;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const Label: ((props: ILabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    location?: LabelLocation | undefined;
    showColon?: boolean | undefined;
    template?: template | ((itemData: {
        component: dxForm;
        dataField: string;
        editorOptions: any;
        editorType: string;
        name: string;
        text: string;
    }, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILoadPanelProps = React.PropsWithChildren<{
    animation?: Record<string, any> | {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    bindingOptions?: Record<string, any>;
    closeOnOutsideClick?: boolean | ((event: event) => boolean);
    container?: any | string | undefined;
    deferRendering?: boolean;
    delay?: number;
    focusStateEnabled?: boolean;
    height?: (() => number | string) | number | string;
    hideOnOutsideClick?: boolean | ((event: event) => boolean);
    hideOnParentScroll?: boolean;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    indicatorSrc?: string;
    maxHeight?: (() => number | string) | number | string;
    maxWidth?: (() => number | string) | number | string;
    message?: string;
    minHeight?: (() => number | string) | number | string;
    minWidth?: (() => number | string) | number | string;
    onContentReady?: ((e: LoadPanelContentReadyEvent) => void);
    onDisposing?: ((e: LoadPanelDisposingEvent) => void);
    onHidden?: ((e: HiddenEvent) => void);
    onHiding?: ((e: HidingEvent) => void);
    onInitialized?: ((e: LoadPanelInitializedEvent) => void);
    onOptionChanged?: ((e: LoadPanelOptionChangedEvent) => void);
    onShowing?: ((e: ShowingEvent) => void);
    onShown?: ((e: ShownEvent) => void);
    position?: (() => void) | PositionAlignment | PositionConfig;
    rtlEnabled?: boolean;
    shading?: boolean;
    shadingColor?: string;
    showIndicator?: boolean;
    showPane?: boolean;
    visible?: boolean;
    width?: (() => number | string) | number | string;
    wrapperAttr?: any;
    defaultPosition?: (() => void) | PositionAlignment | PositionConfig;
    onPositionChange?: (value: (() => void) | PositionAlignment | PositionConfig) => void;
    defaultVisible?: boolean;
    onVisibleChange?: (value: boolean) => void;
}>;
declare const LoadPanel: ((props: ILoadPanelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    animation?: Record<string, any> | {
        hide?: AnimationConfig | undefined;
        show?: AnimationConfig | undefined;
    } | undefined;
    bindingOptions?: Record<string, any> | undefined;
    closeOnOutsideClick?: boolean | ((event: event) => boolean) | undefined;
    container?: any | string | undefined;
    deferRendering?: boolean | undefined;
    delay?: number | undefined;
    focusStateEnabled?: boolean | undefined;
    height?: string | number | (() => number | string) | undefined;
    hideOnOutsideClick?: boolean | ((event: event) => boolean) | undefined;
    hideOnParentScroll?: boolean | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    indicatorSrc?: string | undefined;
    maxHeight?: string | number | (() => number | string) | undefined;
    maxWidth?: string | number | (() => number | string) | undefined;
    message?: string | undefined;
    minHeight?: string | number | (() => number | string) | undefined;
    minWidth?: string | number | (() => number | string) | undefined;
    onContentReady?: ((e: LoadPanelContentReadyEvent) => void) | undefined;
    onDisposing?: ((e: LoadPanelDisposingEvent) => void) | undefined;
    onHidden?: ((e: HiddenEvent) => void) | undefined;
    onHiding?: ((e: HidingEvent) => void) | undefined;
    onInitialized?: ((e: LoadPanelInitializedEvent) => void) | undefined;
    onOptionChanged?: ((e: LoadPanelOptionChangedEvent) => void) | undefined;
    onShowing?: ((e: ShowingEvent) => void) | undefined;
    onShown?: ((e: ShownEvent) => void) | undefined;
    position?: PositionAlignment | PositionConfig | (() => void) | undefined;
    rtlEnabled?: boolean | undefined;
    shading?: boolean | undefined;
    shadingColor?: string | undefined;
    showIndicator?: boolean | undefined;
    showPane?: boolean | undefined;
    visible?: boolean | undefined;
    width?: string | number | (() => number | string) | undefined;
    wrapperAttr?: any;
    defaultPosition?: PositionAlignment | PositionConfig | (() => void) | undefined;
    onPositionChange?: ((value: (() => void) | PositionAlignment | PositionConfig) => void) | undefined;
    defaultVisible?: boolean | undefined;
    onVisibleChange?: ((value: boolean) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILookupProps = React.PropsWithChildren<{
    allowClearing?: boolean;
    dataSource?: Array<any> | DataSourceOptions | Store | undefined;
    displayExpr?: ((data: any) => string) | string | undefined;
    valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
}>;
declare const Lookup: ((props: ILookupProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowClearing?: boolean | undefined;
    dataSource?: Array<any> | DataSourceOptions | Store | undefined;
    displayExpr?: string | ((data: any) => string) | undefined;
    valueExpr?: string | ((data: any) => string | number | boolean) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMyProps = React.PropsWithChildren<{
    x?: HorizontalAlignment;
    y?: VerticalAlignment;
}>;
declare const My: ((props: IMyProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: HorizontalAlignment | undefined;
    y?: VerticalAlignment | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type INumericRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    type?: ValidationRuleType;
}>;
declare const NumericRule: ((props: INumericRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IOffsetProps = React.PropsWithChildren<{
    x?: number;
    y?: number;
}>;
declare const Offset: ((props: IOffsetProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: number | undefined;
    y?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPagerProps = React.PropsWithChildren<{
    allowedPageSizes?: Array<number | PagerPageSize> | Mode;
    displayMode?: DisplayMode;
    infoText?: string;
    label?: string;
    showInfo?: boolean;
    showNavigationButtons?: boolean;
    showPageSizeSelector?: boolean;
    visible?: boolean | Mode;
}>;
declare const Pager: ((props: IPagerProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowedPageSizes?: "auto" | (number | PagerPageSize)[] | undefined;
    displayMode?: DisplayMode | undefined;
    infoText?: string | undefined;
    label?: string | undefined;
    showInfo?: boolean | undefined;
    showNavigationButtons?: boolean | undefined;
    showPageSizeSelector?: boolean | undefined;
    visible?: boolean | "auto" | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPagingProps = React.PropsWithChildren<{
    enabled?: boolean;
    pageIndex?: number;
    pageSize?: number;
    defaultPageIndex?: number;
    onPageIndexChange?: (value: number) => void;
    defaultPageSize?: number;
    onPageSizeChange?: (value: number) => void;
}>;
declare const Paging: ((props: IPagingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    enabled?: boolean | undefined;
    pageIndex?: number | undefined;
    pageSize?: number | undefined;
    defaultPageIndex?: number | undefined;
    onPageIndexChange?: ((value: number) => void) | undefined;
    defaultPageSize?: number | undefined;
    onPageSizeChange?: ((value: number) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPatternRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    pattern?: RegExp | string;
    type?: ValidationRuleType;
}>;
declare const PatternRule: ((props: IPatternRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    pattern?: string | RegExp | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPositionProps = React.PropsWithChildren<{
    at?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    boundary?: any | string;
    boundaryOffset?: Record<string, any> | string | {
        x?: number;
        y?: number;
    };
    collision?: CollisionResolutionCombination | Record<string, any> | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    };
    my?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    of?: any | string;
    offset?: Record<string, any> | string | {
        x?: number;
        y?: number;
    };
}>;
declare const Position: ((props: IPositionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    at?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment | undefined;
        y?: VerticalAlignment | undefined;
    } | undefined;
    boundary?: any | string;
    boundaryOffset?: string | Record<string, any> | {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
    collision?: Record<string, any> | CollisionResolutionCombination | {
        x?: CollisionResolution | undefined;
        y?: CollisionResolution | undefined;
    } | undefined;
    my?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment | undefined;
        y?: VerticalAlignment | undefined;
    } | undefined;
    of?: any | string;
    offset?: string | Record<string, any> | {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IRangeRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    max?: Date | number | string;
    message?: string;
    min?: Date | number | string;
    reevaluate?: boolean;
    type?: ValidationRuleType;
}>;
declare const RangeRule: ((props: IRangeRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    max?: string | number | Date | undefined;
    message?: string | undefined;
    min?: string | number | Date | undefined;
    reevaluate?: boolean | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IRemoteOperationsProps = React.PropsWithChildren<{
    filtering?: boolean;
    grouping?: boolean;
    paging?: boolean;
    sorting?: boolean;
}>;
declare const RemoteOperations: ((props: IRemoteOperationsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    filtering?: boolean | undefined;
    grouping?: boolean | undefined;
    paging?: boolean | undefined;
    sorting?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IRequiredRuleProps = React.PropsWithChildren<{
    message?: string;
    trim?: boolean;
    type?: ValidationRuleType;
}>;
declare const RequiredRule: ((props: IRequiredRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    message?: string | undefined;
    trim?: boolean | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISelectionProps = React.PropsWithChildren<{
    allowSelectAll?: boolean;
    mode?: SingleMultipleOrNone;
    selectAllMode?: SelectAllMode;
    showCheckBoxesMode?: SelectionColumnDisplayMode;
}>;
declare const Selection: ((props: ISelectionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSelectAll?: boolean | undefined;
    mode?: SingleMultipleOrNone | undefined;
    selectAllMode?: SelectAllMode | undefined;
    showCheckBoxesMode?: SelectionColumnDisplayMode | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShowProps = React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void);
    delay?: number;
    direction?: Direction | undefined;
    duration?: number;
    easing?: string;
    from?: AnimationState;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void);
    to?: AnimationState;
    type?: AnimationType;
}>;
declare const Show: ((props: IShowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void) | undefined;
    delay?: number | undefined;
    direction?: Direction | undefined;
    duration?: number | undefined;
    easing?: string | undefined;
    from?: AnimationState | undefined;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void) | undefined;
    to?: AnimationState | undefined;
    type?: AnimationType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IStringLengthRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    max?: number;
    message?: string;
    min?: number;
    trim?: boolean;
    type?: ValidationRuleType;
}>;
declare const StringLengthRule: ((props: IStringLengthRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    max?: number | undefined;
    message?: string | undefined;
    min?: number | undefined;
    trim?: boolean | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToProps = React.PropsWithChildren<{
    left?: number;
    opacity?: number;
    position?: PositionConfig;
    scale?: number;
    top?: number;
}>;
declare const To: ((props: IToProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    left?: number | undefined;
    opacity?: number | undefined;
    position?: PositionConfig | undefined;
    scale?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToolbarProps = React.PropsWithChildren<{
    disabled?: boolean;
    items?: Array<PredefinedToolbarItem | CardViewToolbarItem>;
    multiline?: boolean;
    visible?: boolean | undefined;
}>;
declare const Toolbar: ((props: IToolbarProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    disabled?: boolean | undefined;
    items?: (PredefinedToolbarItem | CardViewToolbarItem)[] | undefined;
    multiline?: boolean | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToolbarItemProps = React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean;
    html?: string;
    locateInMenu?: LocateInMenuMode;
    location?: ToolbarItemLocation;
    menuItemTemplate?: (() => string | any) | template;
    name?: PredefinedToolbarItem | string;
    options?: any;
    showText?: ShowTextMode;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    widget?: ToolbarItemComponent;
    menuItemRender?: (...params: any) => React.ReactNode;
    menuItemComponent?: React.ComponentType<any>;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const ToolbarItem: ((props: IToolbarItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean | undefined;
    html?: string | undefined;
    locateInMenu?: LocateInMenuMode | undefined;
    location?: ToolbarItemLocation | undefined;
    menuItemTemplate?: template | (() => string | any) | undefined;
    name?: string | undefined;
    options?: any;
    showText?: ShowTextMode | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    widget?: ToolbarItemComponent | undefined;
    menuItemRender?: ((...params: any) => React.ReactNode) | undefined;
    menuItemComponent?: React.ComponentType<any> | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IValidationRuleProps = React.PropsWithChildren<{
    message?: string;
    trim?: boolean;
    type?: ValidationRuleType;
    ignoreEmptyValue?: boolean;
    max?: Date | number | string;
    min?: Date | number | string;
    reevaluate?: boolean;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: string | number;
    }) => boolean);
    comparisonTarget?: (() => any);
    comparisonType?: ComparisonOperator;
    pattern?: RegExp | string;
}>;
declare const ValidationRule: ((props: IValidationRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    message?: string | undefined;
    trim?: boolean | undefined;
    type?: ValidationRuleType | undefined;
    ignoreEmptyValue?: boolean | undefined;
    max?: string | number | Date | undefined;
    min?: string | number | Date | undefined;
    reevaluate?: boolean | undefined;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: string | number;
    }) => boolean) | undefined;
    comparisonTarget?: (() => any) | undefined;
    comparisonType?: ComparisonOperator | undefined;
    pattern?: string | RegExp | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default CardView;
export { CardView, ICardViewOptions, CardViewRef, Animation, IAnimationProps, AsyncRule, IAsyncRuleProps, At, IAtProps, BoundaryOffset, IBoundaryOffsetProps, CardCover, ICardCoverProps, CardHeader, ICardHeaderProps, CardHeaderItem, ICardHeaderItemProps, Change, IChangeProps, Collision, ICollisionProps, Column, IColumnProps, CompareRule, ICompareRuleProps, CustomOperation, ICustomOperationProps, CustomRule, ICustomRuleProps, Editing, IEditingProps, EmailRule, IEmailRuleProps, Field, IFieldProps, FilterBuilder, IFilterBuilderProps, FilterOperationDescriptions, IFilterOperationDescriptionsProps, Format, IFormatProps, FormItem, IFormItemProps, From, IFromProps, GroupOperationDescriptions, IGroupOperationDescriptionsProps, HeaderPanel, IHeaderPanelProps, Hide, IHideProps, Item, IItemProps, Label, ILabelProps, LoadPanel, ILoadPanelProps, Lookup, ILookupProps, My, IMyProps, NumericRule, INumericRuleProps, Offset, IOffsetProps, Pager, IPagerProps, Paging, IPagingProps, PatternRule, IPatternRuleProps, Position, IPositionProps, RangeRule, IRangeRuleProps, RemoteOperations, IRemoteOperationsProps, RequiredRule, IRequiredRuleProps, Selection, ISelectionProps, Show, IShowProps, StringLengthRule, IStringLengthRuleProps, To, IToProps, Toolbar, IToolbarProps, ToolbarItem, IToolbarItemProps, ValidationRule, IValidationRuleProps };
import type * as CardViewTypes from 'devextreme/ui/card_view_types';
export { CardViewTypes };
