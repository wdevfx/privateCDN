/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxFilterBuilder, { Properties } from "devextreme/ui/filter_builder";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { ContentReadyEvent, DisposingEvent, EditorPreparedEvent, EditorPreparingEvent, InitializedEvent, ValueChangedEvent, dxFilterBuilderField, FieldInfo, FilterBuilderOperation } from "devextreme/ui/filter_builder";
import type { DataType, template, Format as CommonFormat } from "devextreme/common";
import type { Format as LocalizationFormat } from "devextreme/common/core/localization";
import type { DataSourceOptions } from "devextreme/data/data_source";
import type { Store } from "devextreme/data/store";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IFilterBuilderOptionsNarrowedEvents = {
    onContentReady?: ((e: ContentReadyEvent) => void);
    onDisposing?: ((e: DisposingEvent) => void);
    onEditorPrepared?: ((e: EditorPreparedEvent) => void);
    onEditorPreparing?: ((e: EditorPreparingEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onValueChanged?: ((e: ValueChangedEvent) => void);
};
type IFilterBuilderOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IFilterBuilderOptionsNarrowedEvents> & IHtmlOptions & {
    defaultValue?: Array<any> | (() => any) | string;
    onValueChange?: (value: Array<any> | (() => any) | string) => void;
}>;
interface FilterBuilderRef {
    instance: () => dxFilterBuilder;
}
declare const FilterBuilder: (props: React.PropsWithChildren<IFilterBuilderOptions> & {
    ref?: Ref<FilterBuilderRef>;
}) => ReactElement | null;
type ICustomOperationProps = React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, field: dxFilterBuilderField) => string | (() => any) | Array<any>);
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string);
    dataTypes?: Array<DataType> | undefined;
    editorTemplate?: ((conditionInfo: {
        field: dxFilterBuilderField;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | template;
    hasValue?: boolean;
    icon?: string | undefined;
    name?: string | undefined;
    editorRender?: (...params: any) => React.ReactNode;
    editorComponent?: React.ComponentType<any>;
}>;
declare const CustomOperation: ((props: ICustomOperationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, field: dxFilterBuilderField) => string | (() => any) | Array<any>) | undefined;
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string) | undefined;
    dataTypes?: Array<DataType> | undefined;
    editorTemplate?: template | ((conditionInfo: {
        field: dxFilterBuilderField;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | undefined;
    hasValue?: boolean | undefined;
    icon?: string | undefined;
    name?: string | undefined;
    editorRender?: ((...params: any) => React.ReactNode) | undefined;
    editorComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFieldProps = React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string) => string | (() => any) | Array<any>);
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string);
    dataField?: string | undefined;
    dataType?: DataType;
    editorOptions?: any;
    editorTemplate?: ((conditionInfo: {
        field: dxFilterBuilderField;
        filterOperation: string;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | template;
    falseText?: string;
    filterOperations?: Array<FilterBuilderOperation | string>;
    format?: LocalizationFormat;
    lookup?: Record<string, any> | {
        allowClearing?: boolean;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
    };
    name?: string | undefined;
    trueText?: string;
    editorRender?: (...params: any) => React.ReactNode;
    editorComponent?: React.ComponentType<any>;
}>;
declare const Field: ((props: IFieldProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string) => string | (() => any) | Array<any>) | undefined;
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string) | undefined;
    dataField?: string | undefined;
    dataType?: DataType | undefined;
    editorOptions?: any;
    editorTemplate?: template | ((conditionInfo: {
        field: dxFilterBuilderField;
        filterOperation: string;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | undefined;
    falseText?: string | undefined;
    filterOperations?: string[] | undefined;
    format?: LocalizationFormat;
    lookup?: Record<string, any> | {
        allowClearing?: boolean | undefined;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: string | ((data: any) => string) | undefined;
        valueExpr?: string | ((data: any) => string | number | boolean) | undefined;
    } | undefined;
    name?: string | undefined;
    trueText?: string | undefined;
    editorRender?: ((...params: any) => React.ReactNode) | undefined;
    editorComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFilterOperationDescriptionsProps = React.PropsWithChildren<{
    between?: string;
    contains?: string;
    endsWith?: string;
    equal?: string;
    greaterThan?: string;
    greaterThanOrEqual?: string;
    isBlank?: string;
    isNotBlank?: string;
    lessThan?: string;
    lessThanOrEqual?: string;
    notContains?: string;
    notEqual?: string;
    startsWith?: string;
}>;
declare const FilterOperationDescriptions: ((props: IFilterOperationDescriptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    between?: string | undefined;
    contains?: string | undefined;
    endsWith?: string | undefined;
    equal?: string | undefined;
    greaterThan?: string | undefined;
    greaterThanOrEqual?: string | undefined;
    isBlank?: string | undefined;
    isNotBlank?: string | undefined;
    lessThan?: string | undefined;
    lessThanOrEqual?: string | undefined;
    notContains?: string | undefined;
    notEqual?: string | undefined;
    startsWith?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const Format: ((props: IFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IGroupOperationDescriptionsProps = React.PropsWithChildren<{
    and?: string;
    notAnd?: string;
    notOr?: string;
    or?: string;
}>;
declare const GroupOperationDescriptions: ((props: IGroupOperationDescriptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    and?: string | undefined;
    notAnd?: string | undefined;
    notOr?: string | undefined;
    or?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILookupProps = React.PropsWithChildren<{
    allowClearing?: boolean;
    dataSource?: Array<any> | DataSourceOptions | Store | undefined;
    displayExpr?: ((data: any) => string) | string | undefined;
    valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
}>;
declare const Lookup: ((props: ILookupProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowClearing?: boolean | undefined;
    dataSource?: Array<any> | DataSourceOptions | Store | undefined;
    displayExpr?: string | ((data: any) => string) | undefined;
    valueExpr?: string | ((data: any) => string | number | boolean) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default FilterBuilder;
export { FilterBuilder, IFilterBuilderOptions, FilterBuilderRef, CustomOperation, ICustomOperationProps, Field, IFieldProps, FilterOperationDescriptions, IFilterOperationDescriptionsProps, Format, IFormatProps, GroupOperationDescriptions, IGroupOperationDescriptionsProps, Lookup, ILookupProps };
import type * as FilterBuilderTypes from 'devextreme/ui/filter_builder_types';
export { FilterBuilderTypes };
