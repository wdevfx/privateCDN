/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxChat, { Properties } from "devextreme/ui/chat";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { Message, DisposingEvent, InitializedEvent, MessageDeletedEvent, MessageDeletingEvent, MessageEditCanceledEvent, MessageEditingStartEvent, MessageEnteredEvent, MessageUpdatedEvent, MessageUpdatingEvent, TypingEndEvent, TypingStartEvent, User as ChatUser } from "devextreme/ui/chat";
import type { Format } from "devextreme/common";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IChatOptionsNarrowedEvents = {
    onDisposing?: ((e: DisposingEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onMessageDeleted?: ((e: MessageDeletedEvent) => void) | undefined;
    onMessageDeleting?: ((e: MessageDeletingEvent) => void) | undefined;
    onMessageEditCanceled?: ((e: MessageEditCanceledEvent) => void) | undefined;
    onMessageEditingStart?: ((e: MessageEditingStartEvent) => void) | undefined;
    onMessageEntered?: ((e: MessageEnteredEvent) => void) | undefined;
    onMessageUpdated?: ((e: MessageUpdatedEvent) => void) | undefined;
    onMessageUpdating?: ((e: MessageUpdatingEvent) => void) | undefined;
    onTypingEnd?: ((e: TypingEndEvent) => void) | undefined;
    onTypingStart?: ((e: TypingStartEvent) => void) | undefined;
};
type IChatOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IChatOptionsNarrowedEvents> & IHtmlOptions & {
    messageRender?: (...params: any) => React.ReactNode;
    messageComponent?: React.ComponentType<any>;
    defaultItems?: Array<Message>;
    onItemsChange?: (value: Array<Message>) => void;
}>;
interface ChatRef {
    instance: () => dxChat;
}
declare const Chat: (props: React.PropsWithChildren<IChatOptions> & {
    ref?: Ref<ChatRef>;
}) => ReactElement | null;
type IAlertProps = React.PropsWithChildren<{
    id?: number | string;
    message?: string;
}>;
declare const Alert: ((props: IAlertProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    id?: string | number | undefined;
    message?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAuthorProps = React.PropsWithChildren<{
    avatarAlt?: string;
    avatarUrl?: string;
    id?: number | string;
    name?: string;
}>;
declare const Author: ((props: IAuthorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    avatarAlt?: string | undefined;
    avatarUrl?: string | undefined;
    id?: string | number | undefined;
    name?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IDayHeaderFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: Format | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const DayHeaderFormat: ((props: IDayHeaderFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IEditingProps = React.PropsWithChildren<{
    allowDeleting?: boolean | ((options: {
        component: dxChat;
        message: Message;
    }) => boolean);
    allowUpdating?: boolean | ((options: {
        component: dxChat;
        message: Message;
    }) => boolean);
}>;
declare const Editing: ((props: IEditingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowDeleting?: boolean | ((options: {
        component: dxChat;
        message: Message;
    }) => boolean) | undefined;
    allowUpdating?: boolean | ((options: {
        component: dxChat;
        message: Message;
    }) => boolean) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IItemProps = React.PropsWithChildren<{
    alt?: string;
    author?: ChatUser;
    id?: number | string;
    isDeleted?: boolean;
    isEdited?: boolean;
    src?: string;
    text?: string;
    timestamp?: Date | number | string;
    type?: string | undefined;
}>;
declare const Item: ((props: IItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alt?: string | undefined;
    author?: ChatUser | undefined;
    id?: string | number | undefined;
    isDeleted?: boolean | undefined;
    isEdited?: boolean | undefined;
    src?: string | undefined;
    text?: string | undefined;
    timestamp?: string | number | Date | undefined;
    type?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMessageTimestampFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: Format | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const MessageTimestampFormat: ((props: IMessageTimestampFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITypingUserProps = React.PropsWithChildren<{
    avatarAlt?: string;
    avatarUrl?: string;
    id?: number | string;
    name?: string;
}>;
declare const TypingUser: ((props: ITypingUserProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    avatarAlt?: string | undefined;
    avatarUrl?: string | undefined;
    id?: string | number | undefined;
    name?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IUserProps = React.PropsWithChildren<{
    avatarAlt?: string;
    avatarUrl?: string;
    id?: number | string;
    name?: string;
}>;
declare const User: ((props: IUserProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    avatarAlt?: string | undefined;
    avatarUrl?: string | undefined;
    id?: string | number | undefined;
    name?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default Chat;
export { Chat, IChatOptions, ChatRef, Alert, IAlertProps, Author, IAuthorProps, DayHeaderFormat, IDayHeaderFormatProps, Editing, IEditingProps, Item, IItemProps, MessageTimestampFormat, IMessageTimestampFormatProps, TypingUser, ITypingUserProps, User, IUserProps };
import type * as ChatTypes from 'devextreme/ui/chat_types';
export { ChatTypes };
