/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxTreeMap, { Properties } from "devextreme/viz/tree_map";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { ClickEvent, DisposingEvent, DrawnEvent, DrillEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, NodesInitializedEvent, NodesRenderingEvent, TreeMapColorizerType, dxTreeMapNode } from "devextreme/viz/tree_map";
import type { DashStyle, Palette, PaletteExtensionMode, Font as ChartsFont, TextOverflow, WordWrap } from "devextreme/common/charts";
import type { ExportFormat, Format as CommonFormat, HorizontalAlignment, VerticalEdge, template } from "devextreme/common";
import type { Format as LocalizationFormat } from "devextreme/common/core/localization";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type ITreeMapOptionsNarrowedEvents = {
    onClick?: ((e: ClickEvent) => void);
    onDisposing?: ((e: DisposingEvent) => void);
    onDrawn?: ((e: DrawnEvent) => void);
    onDrill?: ((e: DrillEvent) => void);
    onExported?: ((e: ExportedEvent) => void);
    onExporting?: ((e: ExportingEvent) => void);
    onFileSaving?: ((e: FileSavingEvent) => void);
    onIncidentOccurred?: ((e: IncidentOccurredEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onNodesInitialized?: ((e: NodesInitializedEvent) => void);
    onNodesRendering?: ((e: NodesRenderingEvent) => void);
};
type ITreeMapOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, ITreeMapOptionsNarrowedEvents> & IHtmlOptions & {
    defaultLoadingIndicator?: Record<string, any>;
    onLoadingIndicatorChange?: (value: Record<string, any>) => void;
}>;
interface TreeMapRef {
    instance: () => dxTreeMap;
}
declare const TreeMap: (props: React.PropsWithChildren<ITreeMapOptions> & {
    ref?: Ref<TreeMapRef>;
}) => ReactElement | null;
type IBorderProps = React.PropsWithChildren<{
    color?: string | undefined;
    width?: number | undefined;
    dashStyle?: DashStyle;
    opacity?: number | undefined;
    visible?: boolean;
}>;
declare const Border: ((props: IBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    width?: number | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColorizerProps = React.PropsWithChildren<{
    colorCodeField?: string | undefined;
    colorizeGroups?: boolean;
    palette?: Array<string> | Palette;
    paletteExtensionMode?: PaletteExtensionMode;
    range?: Array<number>;
    type?: TreeMapColorizerType | undefined;
}>;
declare const Colorizer: ((props: IColorizerProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    colorCodeField?: string | undefined;
    colorizeGroups?: boolean | undefined;
    palette?: string[] | Palette | undefined;
    paletteExtensionMode?: PaletteExtensionMode | undefined;
    range?: number[] | undefined;
    type?: TreeMapColorizerType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IExportProps = React.PropsWithChildren<{
    backgroundColor?: string;
    enabled?: boolean;
    fileName?: string;
    formats?: Array<ExportFormat>;
    margin?: number;
    printingEnabled?: boolean;
    svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
}>;
declare const Export: ((props: IExportProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    enabled?: boolean | undefined;
    fileName?: string | undefined;
    formats?: ExportFormat[] | undefined;
    margin?: number | undefined;
    printingEnabled?: boolean | undefined;
    svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFontProps = React.PropsWithChildren<{
    color?: string;
    family?: string;
    opacity?: number;
    size?: number | string;
    weight?: number;
}>;
declare const Font: ((props: IFontProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    family?: string | undefined;
    opacity?: number | undefined;
    size?: string | number | undefined;
    weight?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const Format: ((props: IFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IGroupProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        width?: number | undefined;
    };
    color?: string;
    headerHeight?: number | undefined;
    hoverEnabled?: boolean | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    };
    label?: Record<string, any> | {
        font?: ChartsFont;
        textOverflow?: TextOverflow;
        visible?: boolean;
    };
    padding?: number;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    };
}>;
declare const Group: ((props: IGroupProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    headerHeight?: number | undefined;
    hoverEnabled?: boolean | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            width?: number | undefined;
        } | undefined;
        color?: string | undefined;
    } | undefined;
    label?: Record<string, any> | {
        font?: ChartsFont | undefined;
        textOverflow?: TextOverflow | undefined;
        visible?: boolean | undefined;
    } | undefined;
    padding?: number | undefined;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            width?: number | undefined;
        } | undefined;
        color?: string | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IGroupLabelProps = React.PropsWithChildren<{
    font?: ChartsFont;
    textOverflow?: TextOverflow;
    visible?: boolean;
}>;
declare const GroupLabel: ((props: IGroupLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    textOverflow?: TextOverflow | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHoverStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        width?: number | undefined;
    };
    color?: string | undefined;
}>;
declare const HoverStyle: ((props: IHoverStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILabelProps = React.PropsWithChildren<{
    font?: ChartsFont;
    textOverflow?: TextOverflow;
    visible?: boolean;
    wordWrap?: WordWrap;
}>;
declare const Label: ((props: ILabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    textOverflow?: TextOverflow | undefined;
    visible?: boolean | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILoadingIndicatorProps = React.PropsWithChildren<{
    backgroundColor?: string;
    enabled?: boolean;
    font?: ChartsFont;
    show?: boolean;
    text?: string;
    defaultShow?: boolean;
    onShowChange?: (value: boolean) => void;
}>;
declare const LoadingIndicator: ((props: ILoadingIndicatorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    enabled?: boolean | undefined;
    font?: ChartsFont | undefined;
    show?: boolean | undefined;
    text?: string | undefined;
    defaultShow?: boolean | undefined;
    onShowChange?: ((value: boolean) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMarginProps = React.PropsWithChildren<{
    bottom?: number;
    left?: number;
    right?: number;
    top?: number;
}>;
declare const Margin: ((props: IMarginProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    bottom?: number | undefined;
    left?: number | undefined;
    right?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISelectionStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        width?: number | undefined;
    };
    color?: string | undefined;
}>;
declare const SelectionStyle: ((props: ISelectionStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShadowProps = React.PropsWithChildren<{
    blur?: number;
    color?: string;
    offsetX?: number;
    offsetY?: number;
    opacity?: number;
}>;
declare const Shadow: ((props: IShadowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    blur?: number | undefined;
    color?: string | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISizeProps = React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
}>;
declare const Size: ((props: ISizeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISubtitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    offset?: number;
    text?: string;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const Subtitle: ((props: ISubtitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    offset?: number | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITileProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        width?: number | undefined;
    };
    color?: string;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    };
    label?: Record<string, any> | {
        font?: ChartsFont;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    };
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    };
}>;
declare const Tile: ((props: ITileProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            width?: number | undefined;
        } | undefined;
        color?: string | undefined;
    } | undefined;
    label?: Record<string, any> | {
        font?: ChartsFont | undefined;
        textOverflow?: TextOverflow | undefined;
        visible?: boolean | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            width?: number | undefined;
        } | undefined;
        color?: string | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITileLabelProps = React.PropsWithChildren<{
    font?: ChartsFont;
    textOverflow?: TextOverflow;
    visible?: boolean;
    wordWrap?: WordWrap;
}>;
declare const TileLabel: ((props: ITileLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    textOverflow?: TextOverflow | undefined;
    visible?: boolean | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    margin?: number | Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    placeholderSize?: number | undefined;
    subtitle?: Record<string, any> | string | {
        font?: ChartsFont;
        offset?: number;
        text?: string;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    text?: string;
    textOverflow?: TextOverflow;
    verticalAlignment?: VerticalEdge;
    wordWrap?: WordWrap;
}>;
declare const Title: ((props: ITitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    placeholderSize?: number | undefined;
    subtitle?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        offset?: number | undefined;
        text?: string | undefined;
        textOverflow?: TextOverflow | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    verticalAlignment?: VerticalEdge | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITooltipProps = React.PropsWithChildren<{
    arrowLength?: number;
    border?: Record<string, any> | {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: string;
    container?: any | string | undefined;
    contentTemplate?: ((info: {
        node: dxTreeMapNode;
        value: number;
        valueText: string;
    }, element: any) => string | any) | template | undefined;
    cornerRadius?: number;
    customizeTooltip?: ((info: {
        node: dxTreeMapNode;
        value: number;
        valueText: string;
    }) => Record<string, any>) | undefined;
    enabled?: boolean;
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    zIndex?: number | undefined;
    contentRender?: (...params: any) => React.ReactNode;
    contentComponent?: React.ComponentType<any>;
}>;
declare const Tooltip: ((props: ITooltipProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    arrowLength?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    container?: any | string | undefined;
    contentTemplate?: template | ((info: {
        node: dxTreeMapNode;
        value: number;
        valueText: string;
    }, element: any) => string | any) | undefined;
    cornerRadius?: number | undefined;
    customizeTooltip?: ((info: {
        node: dxTreeMapNode;
        value: number;
        valueText: string;
    }) => Record<string, any>) | undefined;
    enabled?: boolean | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    zIndex?: number | undefined;
    contentRender?: ((...params: any) => React.ReactNode) | undefined;
    contentComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITooltipBorderProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const TooltipBorder: ((props: ITooltipBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITreeMapborderProps = React.PropsWithChildren<{
    color?: string | undefined;
    width?: number | undefined;
}>;
declare const TreeMapborder: ((props: ITreeMapborderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default TreeMap;
export { TreeMap, ITreeMapOptions, TreeMapRef, Border, IBorderProps, Colorizer, IColorizerProps, Export, IExportProps, Font, IFontProps, Format, IFormatProps, Group, IGroupProps, GroupLabel, IGroupLabelProps, HoverStyle, IHoverStyleProps, Label, ILabelProps, LoadingIndicator, ILoadingIndicatorProps, Margin, IMarginProps, SelectionStyle, ISelectionStyleProps, Shadow, IShadowProps, Size, ISizeProps, Subtitle, ISubtitleProps, Tile, ITileProps, TileLabel, ITileLabelProps, Title, ITitleProps, Tooltip, ITooltipProps, TooltipBorder, ITooltipBorderProps, TreeMapborder, ITreeMapborderProps };
import type * as TreeMapTypes from 'devextreme/viz/tree_map_types';
export { TreeMapTypes };
