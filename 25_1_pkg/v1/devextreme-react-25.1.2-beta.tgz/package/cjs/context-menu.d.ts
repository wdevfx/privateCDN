/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

export { ExplicitTypes } from "devextreme/ui/context_menu";
import * as React from "react";
import { Ref, ReactElement } from "react";
import dxContextMenu, { Properties } from "devextreme/ui/context_menu";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { dxContextMenuItem, ContentReadyEvent, DisposingEvent, HiddenEvent, HidingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemRenderedEvent, PositioningEvent, ShowingEvent, ShownEvent } from "devextreme/ui/context_menu";
import type { AnimationConfig, CollisionResolution, PositionConfig, AnimationState, AnimationType, CollisionResolutionCombination } from "devextreme/common/core/animation";
import type { HorizontalAlignment, VerticalAlignment, Direction, template, PositionAlignment, SubmenuShowMode } from "devextreme/common";
import type { CollectionWidgetItem } from "devextreme/ui/collection/ui.collection_widget.base";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IContextMenuOptionsNarrowedEvents<TKey = any> = {
    onContentReady?: ((e: ContentReadyEvent<TKey>) => void);
    onDisposing?: ((e: DisposingEvent<TKey>) => void);
    onHidden?: ((e: HiddenEvent<TKey>) => void);
    onHiding?: ((e: HidingEvent<TKey>) => void);
    onInitialized?: ((e: InitializedEvent<TKey>) => void);
    onItemClick?: ((e: ItemClickEvent<TKey>) => void);
    onItemContextMenu?: ((e: ItemContextMenuEvent<TKey>) => void);
    onItemRendered?: ((e: ItemRenderedEvent<TKey>) => void);
    onPositioning?: ((e: PositioningEvent<TKey>) => void);
    onShowing?: ((e: ShowingEvent<TKey>) => void);
    onShown?: ((e: ShownEvent<TKey>) => void);
};
type IContextMenuOptions<TKey = any> = React.PropsWithChildren<ReplaceFieldTypes<Properties<TKey>, IContextMenuOptionsNarrowedEvents<TKey>> & IHtmlOptions & {
    dataSource?: Properties<TKey>["dataSource"];
    itemRender?: (...params: any) => React.ReactNode;
    itemComponent?: React.ComponentType<any>;
    defaultItems?: Array<dxContextMenuItem>;
    defaultSelectedItem?: any;
    defaultVisible?: boolean;
    onItemsChange?: (value: Array<dxContextMenuItem>) => void;
    onSelectedItemChange?: (value: any) => void;
    onVisibleChange?: (value: boolean) => void;
}>;
interface ContextMenuRef<TKey = any> {
    instance: () => dxContextMenu<TKey>;
}
declare const ContextMenu: <TKey = any>(props: ReplaceFieldTypes<Properties<TKey>, IContextMenuOptionsNarrowedEvents<TKey>> & IHtmlOptions & {
    dataSource?: import("devextreme/data/data_source").DataSourceLike<dxContextMenuItem, TKey> | null | undefined;
    itemRender?: ((...params: any) => React.ReactNode) | undefined;
    itemComponent?: React.ComponentType<any> | undefined;
    defaultItems?: dxContextMenuItem[] | undefined;
    defaultSelectedItem?: any;
    defaultVisible?: boolean | undefined;
    onItemsChange?: ((value: Array<dxContextMenuItem>) => void) | undefined;
    onSelectedItemChange?: ((value: any) => void) | undefined;
    onVisibleChange?: ((value: boolean) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    ref?: React.Ref<ContextMenuRef<TKey>> | undefined;
}) => ReactElement | null;
type IAnimationProps = React.PropsWithChildren<{
    hide?: AnimationConfig;
    show?: AnimationConfig;
}>;
declare const Animation: ((props: IAnimationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    hide?: AnimationConfig | undefined;
    show?: AnimationConfig | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAtProps = React.PropsWithChildren<{
    x?: HorizontalAlignment;
    y?: VerticalAlignment;
}>;
declare const At: ((props: IAtProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: HorizontalAlignment | undefined;
    y?: VerticalAlignment | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBoundaryOffsetProps = React.PropsWithChildren<{
    x?: number;
    y?: number;
}>;
declare const BoundaryOffset: ((props: IBoundaryOffsetProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: number | undefined;
    y?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICollisionProps = React.PropsWithChildren<{
    x?: CollisionResolution;
    y?: CollisionResolution;
}>;
declare const Collision: ((props: ICollisionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: CollisionResolution | undefined;
    y?: CollisionResolution | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IDelayProps = React.PropsWithChildren<{
    hide?: number;
    show?: number;
}>;
declare const Delay: ((props: IDelayProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    hide?: number | undefined;
    show?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFromProps = React.PropsWithChildren<{
    left?: number;
    opacity?: number;
    position?: PositionConfig;
    scale?: number;
    top?: number;
}>;
declare const From: ((props: IFromProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    left?: number | undefined;
    opacity?: number | undefined;
    position?: PositionConfig | undefined;
    scale?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHideProps = React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void);
    delay?: number;
    direction?: Direction | undefined;
    duration?: number;
    easing?: string;
    from?: AnimationState;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void);
    to?: AnimationState;
    type?: AnimationType;
}>;
declare const Hide: ((props: IHideProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void) | undefined;
    delay?: number | undefined;
    direction?: Direction | undefined;
    duration?: number | undefined;
    easing?: string | undefined;
    from?: AnimationState | undefined;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void) | undefined;
    to?: AnimationState | undefined;
    type?: AnimationType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IItemProps = React.PropsWithChildren<{
    beginGroup?: boolean;
    closeMenuOnClick?: boolean;
    disabled?: boolean;
    icon?: string;
    items?: Array<dxContextMenuItem>;
    selectable?: boolean;
    selected?: boolean;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const Item: ((props: IItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    beginGroup?: boolean | undefined;
    closeMenuOnClick?: boolean | undefined;
    disabled?: boolean | undefined;
    icon?: string | undefined;
    items?: dxContextMenuItem[] | undefined;
    selectable?: boolean | undefined;
    selected?: boolean | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMyProps = React.PropsWithChildren<{
    x?: HorizontalAlignment;
    y?: VerticalAlignment;
}>;
declare const My: ((props: IMyProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: HorizontalAlignment | undefined;
    y?: VerticalAlignment | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IOffsetProps = React.PropsWithChildren<{
    x?: number;
    y?: number;
}>;
declare const Offset: ((props: IOffsetProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: number | undefined;
    y?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPositionProps = React.PropsWithChildren<{
    at?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    boundary?: any | string;
    boundaryOffset?: Record<string, any> | string | {
        x?: number;
        y?: number;
    };
    collision?: CollisionResolutionCombination | Record<string, any> | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    };
    my?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    of?: any | string;
    offset?: Record<string, any> | string | {
        x?: number;
        y?: number;
    };
}>;
declare const Position: ((props: IPositionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    at?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment | undefined;
        y?: VerticalAlignment | undefined;
    } | undefined;
    boundary?: any | string;
    boundaryOffset?: string | Record<string, any> | {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
    collision?: Record<string, any> | CollisionResolutionCombination | {
        x?: CollisionResolution | undefined;
        y?: CollisionResolution | undefined;
    } | undefined;
    my?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment | undefined;
        y?: VerticalAlignment | undefined;
    } | undefined;
    of?: any | string;
    offset?: string | Record<string, any> | {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShowProps = React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void);
    delay?: number;
    direction?: Direction | undefined;
    duration?: number;
    easing?: string;
    from?: AnimationState;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void);
    to?: AnimationState;
    type?: AnimationType;
}>;
declare const Show: ((props: IShowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void) | undefined;
    delay?: number | undefined;
    direction?: Direction | undefined;
    duration?: number | undefined;
    easing?: string | undefined;
    from?: AnimationState | undefined;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void) | undefined;
    to?: AnimationState | undefined;
    type?: AnimationType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShowEventProps = React.PropsWithChildren<{
    delay?: number | undefined;
    name?: string | undefined;
}>;
declare const ShowEvent: ((props: IShowEventProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    delay?: number | undefined;
    name?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShowSubmenuModeProps = React.PropsWithChildren<{
    delay?: number | Record<string, any> | {
        hide?: number;
        show?: number;
    };
    name?: SubmenuShowMode;
}>;
declare const ShowSubmenuMode: ((props: IShowSubmenuModeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    delay?: number | Record<string, any> | {
        hide?: number | undefined;
        show?: number | undefined;
    } | undefined;
    name?: SubmenuShowMode | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToProps = React.PropsWithChildren<{
    left?: number;
    opacity?: number;
    position?: PositionConfig;
    scale?: number;
    top?: number;
}>;
declare const To: ((props: IToProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    left?: number | undefined;
    opacity?: number | undefined;
    position?: PositionConfig | undefined;
    scale?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default ContextMenu;
export { ContextMenu, IContextMenuOptions, ContextMenuRef, Animation, IAnimationProps, At, IAtProps, BoundaryOffset, IBoundaryOffsetProps, Collision, ICollisionProps, Delay, IDelayProps, From, IFromProps, Hide, IHideProps, Item, IItemProps, My, IMyProps, Offset, IOffsetProps, Position, IPositionProps, Show, IShowProps, ShowEvent, IShowEventProps, ShowSubmenuMode, IShowSubmenuModeProps, To, IToProps };
import type * as ContextMenuTypes from 'devextreme/ui/context_menu_types';
export { ContextMenuTypes };
