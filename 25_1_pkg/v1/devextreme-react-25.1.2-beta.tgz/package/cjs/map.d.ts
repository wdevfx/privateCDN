/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxMap, { Properties } from "devextreme/ui/map";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { ClickEvent, DisposingEvent, InitializedEvent, MarkerAddedEvent, MarkerRemovedEvent, ReadyEvent, RouteAddedEvent, RouteRemovedEvent, RouteMode } from "devextreme/ui/map";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IMapOptionsNarrowedEvents = {
    onClick?: ((e: ClickEvent) => void);
    onDisposing?: ((e: DisposingEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onMarkerAdded?: ((e: MarkerAddedEvent) => void);
    onMarkerRemoved?: ((e: MarkerRemovedEvent) => void);
    onReady?: ((e: ReadyEvent) => void);
    onRouteAdded?: ((e: RouteAddedEvent) => void);
    onRouteRemoved?: ((e: RouteRemovedEvent) => void);
};
type IMapOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IMapOptionsNarrowedEvents> & IHtmlOptions & {
    defaultCenter?: Array<number> | Record<string, any> | string;
    defaultMarkers?: Array<Record<string, any>>;
    defaultRoutes?: Array<Record<string, any>>;
    defaultZoom?: number;
    onCenterChange?: (value: Array<number> | Record<string, any> | string) => void;
    onMarkersChange?: (value: Array<Record<string, any>>) => void;
    onRoutesChange?: (value: Array<Record<string, any>>) => void;
    onZoomChange?: (value: number) => void;
}>;
interface MapRef {
    instance: () => dxMap;
}
declare const Map: (props: React.PropsWithChildren<IMapOptions> & {
    ref?: Ref<MapRef>;
}) => ReactElement | null;
type IApiKeyProps = React.PropsWithChildren<{
    azure?: string;
    bing?: string;
    google?: string;
    googleStatic?: string;
}>;
declare const ApiKey: ((props: IApiKeyProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    azure?: string | undefined;
    bing?: string | undefined;
    google?: string | undefined;
    googleStatic?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICenterProps = React.PropsWithChildren<{
    lat?: number;
    lng?: number;
}>;
declare const Center: ((props: ICenterProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    lat?: number | undefined;
    lng?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILocationProps = React.PropsWithChildren<{
    lat?: number;
    lng?: number;
}>;
declare const Location: ((props: ILocationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    lat?: number | undefined;
    lng?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMarkerProps = React.PropsWithChildren<{
    iconSrc?: string;
    location?: Array<number> | Record<string, any> | string | {
        lat?: number;
        lng?: number;
    }[];
    onClick?: (() => void);
    tooltip?: Record<string, any> | string | {
        isShown?: boolean;
        text?: string;
    };
}>;
declare const Marker: ((props: IMarkerProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    iconSrc?: string | undefined;
    location?: string | Record<string, any> | number[] | {
        lat?: number | undefined;
        lng?: number | undefined;
    }[] | undefined;
    onClick?: (() => void) | undefined;
    tooltip?: string | Record<string, any> | {
        isShown?: boolean | undefined;
        text?: string | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IProviderConfigProps = React.PropsWithChildren<{
    mapId?: string;
    useAdvancedMarkers?: boolean;
}>;
declare const ProviderConfig: ((props: IProviderConfigProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    mapId?: string | undefined;
    useAdvancedMarkers?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IRouteProps = React.PropsWithChildren<{
    color?: string;
    locations?: Array<Record<string, any>> | {
        lat?: number;
        lng?: number;
    }[];
    mode?: RouteMode | string;
    opacity?: number;
    weight?: number;
}>;
declare const Route: ((props: IRouteProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    locations?: Record<string, any>[] | {
        lat?: number | undefined;
        lng?: number | undefined;
    }[] | undefined;
    mode?: string | undefined;
    opacity?: number | undefined;
    weight?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITooltipProps = React.PropsWithChildren<{
    isShown?: boolean;
    text?: string;
}>;
declare const Tooltip: ((props: ITooltipProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    isShown?: boolean | undefined;
    text?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default Map;
export { Map, IMapOptions, MapRef, ApiKey, IApiKeyProps, Center, ICenterProps, Location, ILocationProps, Marker, IMarkerProps, ProviderConfig, IProviderConfigProps, Route, IRouteProps, Tooltip, ITooltipProps };
import type * as MapTypes from 'devextreme/ui/map_types';
export { MapTypes };
