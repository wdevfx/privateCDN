/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxSankey, { Properties } from "devextreme/viz/sankey";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { DisposingEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, LinkClickEvent, NodeClickEvent, dxSankeyNode, SankeyColorMode } from "devextreme/viz/sankey";
import type { DashStyle, HatchDirection, Font as ChartsFont, TextOverflow, WordWrap } from "devextreme/common/charts";
import type { ExportFormat, Format as CommonFormat, HorizontalAlignment, VerticalEdge, template } from "devextreme/common";
import type { Format as LocalizationFormat } from "devextreme/common/core/localization";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type ISankeyOptionsNarrowedEvents = {
    onDisposing?: ((e: DisposingEvent) => void);
    onDrawn?: ((e: DrawnEvent) => void);
    onExported?: ((e: ExportedEvent) => void);
    onExporting?: ((e: ExportingEvent) => void);
    onFileSaving?: ((e: FileSavingEvent) => void);
    onIncidentOccurred?: ((e: IncidentOccurredEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onLinkClick?: ((e: LinkClickEvent) => void);
    onNodeClick?: ((e: NodeClickEvent) => void);
};
type ISankeyOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, ISankeyOptionsNarrowedEvents> & IHtmlOptions & {
    defaultLoadingIndicator?: Record<string, any>;
    onLoadingIndicatorChange?: (value: Record<string, any>) => void;
}>;
interface SankeyRef {
    instance: () => dxSankey;
}
declare const Sankey: (props: React.PropsWithChildren<ISankeyOptions> & {
    ref?: Ref<SankeyRef>;
}) => ReactElement | null;
type IAdaptiveLayoutProps = React.PropsWithChildren<{
    height?: number;
    keepLabels?: boolean;
    width?: number;
}>;
declare const AdaptiveLayout: ((props: IAdaptiveLayoutProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    keepLabels?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBorderProps = React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
    dashStyle?: DashStyle;
    opacity?: number | undefined;
}>;
declare const Border: ((props: IBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IExportProps = React.PropsWithChildren<{
    backgroundColor?: string;
    enabled?: boolean;
    fileName?: string;
    formats?: Array<ExportFormat>;
    margin?: number;
    printingEnabled?: boolean;
    svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
}>;
declare const Export: ((props: IExportProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    enabled?: boolean | undefined;
    fileName?: string | undefined;
    formats?: ExportFormat[] | undefined;
    margin?: number | undefined;
    printingEnabled?: boolean | undefined;
    svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFontProps = React.PropsWithChildren<{
    color?: string;
    family?: string;
    opacity?: number;
    size?: number | string;
    weight?: number;
}>;
declare const Font: ((props: IFontProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    family?: string | undefined;
    opacity?: number | undefined;
    size?: string | number | undefined;
    weight?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const Format: ((props: IFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHatchingProps = React.PropsWithChildren<{
    direction?: HatchDirection;
    opacity?: number;
    step?: number;
    width?: number;
}>;
declare const Hatching: ((props: IHatchingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    direction?: HatchDirection | undefined;
    opacity?: number | undefined;
    step?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHoverStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    };
    color?: string | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    opacity?: number | undefined;
}>;
declare const HoverStyle: ((props: IHoverStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection | undefined;
        opacity?: number | undefined;
        step?: number | undefined;
        width?: number | undefined;
    } | undefined;
    opacity?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILabelProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    };
    customizeText?: ((itemInfo: dxSankeyNode) => string);
    font?: ChartsFont;
    horizontalOffset?: number;
    overlappingBehavior?: TextOverflow;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    useNodeColors?: boolean;
    verticalOffset?: number;
    visible?: boolean;
}>;
declare const Label: ((props: ILabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    customizeText?: ((itemInfo: dxSankeyNode) => string) | undefined;
    font?: ChartsFont | undefined;
    horizontalOffset?: number | undefined;
    overlappingBehavior?: TextOverflow | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    useNodeColors?: boolean | undefined;
    verticalOffset?: number | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILinkProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    };
    color?: string;
    colorMode?: SankeyColorMode;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        opacity?: number | undefined;
    };
    opacity?: number;
}>;
declare const Link: ((props: ILinkProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    colorMode?: SankeyColorMode | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: string | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
    } | undefined;
    opacity?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILoadingIndicatorProps = React.PropsWithChildren<{
    backgroundColor?: string;
    enabled?: boolean;
    font?: ChartsFont;
    show?: boolean;
    text?: string;
    defaultShow?: boolean;
    onShowChange?: (value: boolean) => void;
}>;
declare const LoadingIndicator: ((props: ILoadingIndicatorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    enabled?: boolean | undefined;
    font?: ChartsFont | undefined;
    show?: boolean | undefined;
    text?: string | undefined;
    defaultShow?: boolean | undefined;
    onShowChange?: ((value: boolean) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMarginProps = React.PropsWithChildren<{
    bottom?: number;
    left?: number;
    right?: number;
    top?: number;
}>;
declare const Margin: ((props: IMarginProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    bottom?: number | undefined;
    left?: number | undefined;
    right?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type INodeProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    };
    color?: string | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        opacity?: number | undefined;
    };
    opacity?: number;
    padding?: number;
    width?: number;
}>;
declare const Node: ((props: INodeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: string | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
    } | undefined;
    opacity?: number | undefined;
    padding?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISankeyborderProps = React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
}>;
declare const Sankeyborder: ((props: ISankeyborderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShadowProps = React.PropsWithChildren<{
    blur?: number;
    color?: string;
    offsetX?: number;
    offsetY?: number;
    opacity?: number;
}>;
declare const Shadow: ((props: IShadowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    blur?: number | undefined;
    color?: string | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISizeProps = React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
}>;
declare const Size: ((props: ISizeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISubtitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    offset?: number;
    text?: string;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const Subtitle: ((props: ISubtitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    offset?: number | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    margin?: number | Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    placeholderSize?: number | undefined;
    subtitle?: Record<string, any> | string | {
        font?: ChartsFont;
        offset?: number;
        text?: string;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    text?: string;
    textOverflow?: TextOverflow;
    verticalAlignment?: VerticalEdge;
    wordWrap?: WordWrap;
}>;
declare const Title: ((props: ITitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    placeholderSize?: number | undefined;
    subtitle?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        offset?: number | undefined;
        text?: string | undefined;
        textOverflow?: TextOverflow | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    verticalAlignment?: VerticalEdge | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITooltipProps = React.PropsWithChildren<{
    arrowLength?: number;
    border?: Record<string, any> | {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: string;
    container?: any | string | undefined;
    cornerRadius?: number;
    customizeLinkTooltip?: ((info: {
        source: string;
        target: string;
        weight: number;
    }) => Record<string, any>) | undefined;
    customizeNodeTooltip?: ((info: {
        label: string;
        title: string;
        weightIn: number;
        weightOut: number;
    }) => Record<string, any>) | undefined;
    enabled?: boolean;
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    linkTooltipTemplate?: ((info: {
        source: string;
        target: string;
        weight: number;
    }, element: any) => string | any) | template | undefined;
    nodeTooltipTemplate?: ((info: {
        label: string;
        weightIn: number;
        weightOut: number;
    }, element: any) => string | any) | template | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    zIndex?: number | undefined;
    linkTooltipRender?: (...params: any) => React.ReactNode;
    linkTooltipComponent?: React.ComponentType<any>;
    nodeTooltipRender?: (...params: any) => React.ReactNode;
    nodeTooltipComponent?: React.ComponentType<any>;
}>;
declare const Tooltip: ((props: ITooltipProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    arrowLength?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    container?: any | string | undefined;
    cornerRadius?: number | undefined;
    customizeLinkTooltip?: ((info: {
        source: string;
        target: string;
        weight: number;
    }) => Record<string, any>) | undefined;
    customizeNodeTooltip?: ((info: {
        label: string;
        title: string;
        weightIn: number;
        weightOut: number;
    }) => Record<string, any>) | undefined;
    enabled?: boolean | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    linkTooltipTemplate?: template | ((info: {
        source: string;
        target: string;
        weight: number;
    }, element: any) => string | any) | undefined;
    nodeTooltipTemplate?: template | ((info: {
        label: string;
        weightIn: number;
        weightOut: number;
    }, element: any) => string | any) | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    zIndex?: number | undefined;
    linkTooltipRender?: ((...params: any) => React.ReactNode) | undefined;
    linkTooltipComponent?: React.ComponentType<any> | undefined;
    nodeTooltipRender?: ((...params: any) => React.ReactNode) | undefined;
    nodeTooltipComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITooltipBorderProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const TooltipBorder: ((props: ITooltipBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default Sankey;
export { Sankey, ISankeyOptions, SankeyRef, AdaptiveLayout, IAdaptiveLayoutProps, Border, IBorderProps, Export, IExportProps, Font, IFontProps, Format, IFormatProps, Hatching, IHatchingProps, HoverStyle, IHoverStyleProps, Label, ILabelProps, Link, ILinkProps, LoadingIndicator, ILoadingIndicatorProps, Margin, IMarginProps, Node, INodeProps, Sankeyborder, ISankeyborderProps, Shadow, IShadowProps, Size, ISizeProps, Subtitle, ISubtitleProps, Title, ITitleProps, Tooltip, ITooltipProps, TooltipBorder, ITooltipBorderProps };
import type * as SankeyTypes from 'devextreme/viz/sankey_types';
export { SankeyTypes };
