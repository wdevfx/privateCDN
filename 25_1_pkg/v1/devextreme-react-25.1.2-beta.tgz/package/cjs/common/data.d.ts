/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

export { applyChanges, ArrayStore, ArrayStoreOptions, base64_encode, compileGetter, compileSetter, CustomStore, CustomStoreOptions, DataSource, DataSourceOptions, EdmLiteral, EndpointSelector, errorHandler, FilterDescriptor, GroupDescriptor, GroupingInterval, GroupItem, isGroupItemsArray, isItemsArray, isLoadResultObject, keyConverters, LangParams, LoadOptions, LoadResult, LoadResultObject, LocalStore, LocalStoreOptions, ODataContext, ODataContextOptions, ODataStore, ODataStoreOptions, query, Query, ResolvedData, SearchOperation, SelectDescriptor, setErrorHandler, SortDescriptor, Store, StoreOptions, SummaryDescriptor, } from "devextreme/common/data";
