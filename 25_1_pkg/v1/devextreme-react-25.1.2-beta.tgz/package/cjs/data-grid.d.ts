/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

export { ExplicitTypes } from "devextreme/ui/data_grid";
import * as React from "react";
import { Ref, ReactElement } from "react";
import dxDataGrid, { Properties } from "devextreme/ui/data_grid";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { dxDataGridColumn, AdaptiveDetailRowPreparingEvent, CellClickEvent, CellDblClickEvent, CellPreparedEvent, ContentReadyEvent, ContextMenuPreparingEvent, DataErrorOccurredEvent, DisposingEvent, EditCanceledEvent, EditCancelingEvent, EditingStartEvent, EditorPreparedEvent, EditorPreparingEvent, ExportingEvent, FocusedCellChangingEvent, FocusedRowChangingEvent, InitializedEvent, InitNewRowEvent, KeyDownEvent, RowClickEvent, RowCollapsedEvent, RowCollapsingEvent, RowDblClickEvent, RowExpandedEvent, RowExpandingEvent, RowInsertedEvent, RowInsertingEvent, RowPreparedEvent, RowRemovedEvent, RowRemovingEvent, RowUpdatedEvent, RowUpdatingEvent, RowValidatingEvent, SavedEvent, SavingEvent, ToolbarPreparingEvent, dxDataGridRowObject, DataGridPredefinedColumnButton, ColumnButtonClickEvent, dxDataGridColumnButton, DataGridCommandColumnType, SelectionSensitivity, DataGridExportFormat, DataGridPredefinedToolbarItem, DataGridScrollMode, dxDataGridToolbarItem } from "devextreme/ui/data_grid";
import type { DataChange, DataChangeType, FilterOperation, FilterType, FixedPosition, HeaderFilterGroupInterval, ColumnHeaderFilterSearchConfig, SelectedFilterOperation, ColumnChooserMode, ColumnChooserSearchConfig, ColumnChooserSelectionConfig, HeaderFilterSearchConfig, SelectionColumnDisplayMode, GridsEditMode, NewRowPosition, GridsEditRefreshMode, StartEditAction, GridBase, ApplyFilterMode, GroupExpandMode, SummaryType, EnterKeyAction, EnterKeyDirection, PagerPageSize, DataRenderMode, StateStoreType } from "devextreme/common/grids";
import type { Mode, ValidationRuleType, HorizontalAlignment, VerticalAlignment, template, DataType, Format as CommonFormat, SearchMode, SortOrder, ComparisonOperator, SingleMultipleOrNone, SelectAllMode, PositionAlignment, Direction, ToolbarItemLocation, ToolbarItemComponent, DisplayMode, DragDirection, DragHighlight, ScrollbarMode } from "devextreme/common";
import type { ContentReadyEvent as FilterBuilderContentReadyEvent, DisposingEvent as FilterBuilderDisposingEvent, EditorPreparedEvent as FilterBuilderEditorPreparedEvent, EditorPreparingEvent as FilterBuilderEditorPreparingEvent, InitializedEvent as FilterBuilderInitializedEvent, dxFilterBuilderField, FieldInfo, FilterBuilderOperation, dxFilterBuilderCustomOperation, GroupOperation, OptionChangedEvent, ValueChangedEvent } from "devextreme/ui/filter_builder";
import type { ContentReadyEvent as FormContentReadyEvent, DisposingEvent as FormDisposingEvent, InitializedEvent as FormInitializedEvent, dxFormSimpleItem, dxFormOptions, OptionChangedEvent as FormOptionChangedEvent, dxFormGroupItem, dxFormTabbedItem, dxFormEmptyItem, dxFormButtonItem, LabelLocation, FormLabelMode, EditorEnterKeyEvent, FieldDataChangedEvent, FormItemComponent, FormItemType } from "devextreme/ui/form";
import type { AnimationConfig, CollisionResolution, PositionConfig, AnimationState, AnimationType, CollisionResolutionCombination } from "devextreme/common/core/animation";
import type { Format as LocalizationFormat } from "devextreme/common/core/localization";
import type { DataSourceOptions } from "devextreme/data/data_source";
import type { Store } from "devextreme/data/store";
import type { dxPopupOptions, dxPopupToolbarItem, ToolbarLocation } from "devextreme/ui/popup";
import type { event } from "devextreme/events/events.types";
import type { EventInfo } from "devextreme/common/core/events";
import type { Component } from "devextreme/core/component";
import type { LocateInMenuMode, ShowTextMode } from "devextreme/ui/toolbar";
import type { CollectionWidgetItem } from "devextreme/ui/collection/ui.collection_widget.base";
import type dxOverlay from "devextreme/ui/overlay";
import type DOMComponent from "devextreme/core/dom_component";
import type dxPopup from "devextreme/ui/popup";
import type dxForm from "devextreme/ui/form";
import type dxSortable from "devextreme/ui/sortable";
import type dxDraggable from "devextreme/ui/draggable";
import type * as CommonTypes from "devextreme/common";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IDataGridOptionsNarrowedEvents<TRowData = any, TKey = any> = {
    onAdaptiveDetailRowPreparing?: ((e: AdaptiveDetailRowPreparingEvent<TRowData, TKey>) => void);
    onCellClick?: ((e: CellClickEvent<TRowData, TKey>) => void);
    onCellDblClick?: ((e: CellDblClickEvent<TRowData, TKey>) => void);
    onCellPrepared?: ((e: CellPreparedEvent<TRowData, TKey>) => void);
    onContentReady?: ((e: ContentReadyEvent<TRowData, TKey>) => void);
    onContextMenuPreparing?: ((e: ContextMenuPreparingEvent<TRowData, TKey>) => void);
    onDataErrorOccurred?: ((e: DataErrorOccurredEvent<TRowData, TKey>) => void);
    onDisposing?: ((e: DisposingEvent<TRowData, TKey>) => void);
    onEditCanceled?: ((e: EditCanceledEvent<TRowData, TKey>) => void);
    onEditCanceling?: ((e: EditCancelingEvent<TRowData, TKey>) => void);
    onEditingStart?: ((e: EditingStartEvent<TRowData, TKey>) => void);
    onEditorPrepared?: ((e: EditorPreparedEvent<TRowData, TKey>) => void);
    onEditorPreparing?: ((e: EditorPreparingEvent<TRowData, TKey>) => void);
    onExporting?: ((e: ExportingEvent<TRowData, TKey>) => void);
    onFocusedCellChanging?: ((e: FocusedCellChangingEvent<TRowData, TKey>) => void);
    onFocusedRowChanging?: ((e: FocusedRowChangingEvent<TRowData, TKey>) => void);
    onInitialized?: ((e: InitializedEvent<TRowData, TKey>) => void);
    onInitNewRow?: ((e: InitNewRowEvent<TRowData, TKey>) => void);
    onKeyDown?: ((e: KeyDownEvent<TRowData, TKey>) => void);
    onRowClick?: ((e: RowClickEvent<TRowData, TKey>) => void);
    onRowCollapsed?: ((e: RowCollapsedEvent<TRowData, TKey>) => void);
    onRowCollapsing?: ((e: RowCollapsingEvent<TRowData, TKey>) => void);
    onRowDblClick?: ((e: RowDblClickEvent<TRowData, TKey>) => void);
    onRowExpanded?: ((e: RowExpandedEvent<TRowData, TKey>) => void);
    onRowExpanding?: ((e: RowExpandingEvent<TRowData, TKey>) => void);
    onRowInserted?: ((e: RowInsertedEvent<TRowData, TKey>) => void);
    onRowInserting?: ((e: RowInsertingEvent<TRowData, TKey>) => void);
    onRowPrepared?: ((e: RowPreparedEvent<TRowData, TKey>) => void);
    onRowRemoved?: ((e: RowRemovedEvent<TRowData, TKey>) => void);
    onRowRemoving?: ((e: RowRemovingEvent<TRowData, TKey>) => void);
    onRowUpdated?: ((e: RowUpdatedEvent<TRowData, TKey>) => void);
    onRowUpdating?: ((e: RowUpdatingEvent<TRowData, TKey>) => void);
    onRowValidating?: ((e: RowValidatingEvent<TRowData, TKey>) => void);
    onSaved?: ((e: SavedEvent<TRowData, TKey>) => void);
    onSaving?: ((e: SavingEvent<TRowData, TKey>) => void);
    onToolbarPreparing?: ((e: ToolbarPreparingEvent<TRowData, TKey>) => void);
};
type IDataGridOptions<TRowData = any, TKey = any> = React.PropsWithChildren<ReplaceFieldTypes<Properties<TRowData, TKey>, IDataGridOptionsNarrowedEvents<TRowData, TKey>> & IHtmlOptions & {
    dataSource?: Properties<TRowData, TKey>["dataSource"];
    dataRowRender?: (...params: any) => React.ReactNode;
    dataRowComponent?: React.ComponentType<any>;
    rowRender?: (...params: any) => React.ReactNode;
    rowComponent?: React.ComponentType<any>;
    defaultColumns?: Array<dxDataGridColumn | string>;
    defaultEditing?: Record<string, any>;
    defaultFilterPanel?: Record<string, any>;
    defaultFilterValue?: Array<any> | (() => any) | string;
    defaultFocusedColumnIndex?: number;
    defaultFocusedRowIndex?: number;
    defaultFocusedRowKey?: any | undefined;
    defaultGroupPanel?: Record<string, any>;
    defaultPaging?: Record<string, any>;
    defaultSearchPanel?: Record<string, any>;
    defaultSelectedRowKeys?: Array<any>;
    defaultSelectionFilter?: Array<any> | (() => any) | string;
    onColumnsChange?: (value: Array<dxDataGridColumn | string>) => void;
    onEditingChange?: (value: Record<string, any>) => void;
    onFilterPanelChange?: (value: Record<string, any>) => void;
    onFilterValueChange?: (value: Array<any> | (() => any) | string) => void;
    onFocusedColumnIndexChange?: (value: number) => void;
    onFocusedRowIndexChange?: (value: number) => void;
    onFocusedRowKeyChange?: (value: any | undefined) => void;
    onGroupPanelChange?: (value: Record<string, any>) => void;
    onPagingChange?: (value: Record<string, any>) => void;
    onSearchPanelChange?: (value: Record<string, any>) => void;
    onSelectedRowKeysChange?: (value: Array<any>) => void;
    onSelectionFilterChange?: (value: Array<any> | (() => any) | string) => void;
}>;
interface DataGridRef<TRowData = any, TKey = any> {
    instance: () => dxDataGrid<TRowData, TKey>;
}
declare const DataGrid: <TRowData = any, TKey = any>(props: ReplaceFieldTypes<Properties<TRowData, TKey>, IDataGridOptionsNarrowedEvents<TRowData, TKey>> & IHtmlOptions & {
    dataSource?: import("devextreme/data/data_source").DataSourceLike<TRowData, TKey> | null | undefined;
    dataRowRender?: ((...params: any) => React.ReactNode) | undefined;
    dataRowComponent?: React.ComponentType<any> | undefined;
    rowRender?: ((...params: any) => React.ReactNode) | undefined;
    rowComponent?: React.ComponentType<any> | undefined;
    defaultColumns?: (string | dxDataGridColumn<any, any>)[] | undefined;
    defaultEditing?: Record<string, any> | undefined;
    defaultFilterPanel?: Record<string, any> | undefined;
    defaultFilterValue?: string | any[] | (() => any) | undefined;
    defaultFocusedColumnIndex?: number | undefined;
    defaultFocusedRowIndex?: number | undefined;
    defaultFocusedRowKey?: any | undefined;
    defaultGroupPanel?: Record<string, any> | undefined;
    defaultPaging?: Record<string, any> | undefined;
    defaultSearchPanel?: Record<string, any> | undefined;
    defaultSelectedRowKeys?: any[] | undefined;
    defaultSelectionFilter?: string | any[] | (() => any) | undefined;
    onColumnsChange?: ((value: Array<dxDataGridColumn | string>) => void) | undefined;
    onEditingChange?: ((value: Record<string, any>) => void) | undefined;
    onFilterPanelChange?: ((value: Record<string, any>) => void) | undefined;
    onFilterValueChange?: ((value: Array<any> | (() => any) | string) => void) | undefined;
    onFocusedColumnIndexChange?: ((value: number) => void) | undefined;
    onFocusedRowIndexChange?: ((value: number) => void) | undefined;
    onFocusedRowKeyChange?: ((value: any | undefined) => void) | undefined;
    onGroupPanelChange?: ((value: Record<string, any>) => void) | undefined;
    onPagingChange?: ((value: Record<string, any>) => void) | undefined;
    onSearchPanelChange?: ((value: Record<string, any>) => void) | undefined;
    onSelectedRowKeysChange?: ((value: Array<any>) => void) | undefined;
    onSelectionFilterChange?: ((value: Array<any> | (() => any) | string) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    ref?: React.Ref<DataGridRef<TRowData, TKey>> | undefined;
}) => ReactElement | null;
type IAnimationProps = React.PropsWithChildren<{
    hide?: AnimationConfig;
    show?: AnimationConfig;
}>;
declare const Animation: ((props: IAnimationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    hide?: AnimationConfig | undefined;
    show?: AnimationConfig | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAsyncRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    reevaluate?: boolean;
    type?: ValidationRuleType;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: string | number;
    }) => any);
}>;
declare const AsyncRule: ((props: IAsyncRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    reevaluate?: boolean | undefined;
    type?: ValidationRuleType | undefined;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: string | number;
    }) => any) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAtProps = React.PropsWithChildren<{
    x?: HorizontalAlignment;
    y?: VerticalAlignment;
}>;
declare const At: ((props: IAtProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: HorizontalAlignment | undefined;
    y?: VerticalAlignment | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBoundaryOffsetProps = React.PropsWithChildren<{
    x?: number;
    y?: number;
}>;
declare const BoundaryOffset: ((props: IBoundaryOffsetProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: number | undefined;
    y?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IButtonProps = React.PropsWithChildren<{
    cssClass?: string;
    disabled?: boolean | ((options: {
        column: dxDataGridColumn;
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean);
    hint?: string;
    icon?: string;
    name?: DataGridPredefinedColumnButton | string;
    onClick?: ((e: ColumnButtonClickEvent) => void);
    template?: ((cellElement: any, cellInfo: {
        column: dxDataGridColumn;
        columnIndex: number;
        component: dxDataGrid;
        data: Record<string, any>;
        key: any;
        row: dxDataGridRowObject;
        rowIndex: number;
        rowType: string;
    }) => string | any) | template;
    text?: string;
    visible?: boolean | ((options: {
        column: dxDataGridColumn;
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean);
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const Button: ((props: IButtonProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean | ((options: {
        column: dxDataGridColumn;
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean) | undefined;
    hint?: string | undefined;
    icon?: string | undefined;
    name?: string | undefined;
    onClick?: ((e: ColumnButtonClickEvent) => void) | undefined;
    template?: template | ((cellElement: any, cellInfo: {
        column: dxDataGridColumn;
        columnIndex: number;
        component: dxDataGrid;
        data: Record<string, any>;
        key: any;
        row: dxDataGridRowObject;
        rowIndex: number;
        rowType: string;
    }) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | ((options: {
        column: dxDataGridColumn;
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean) | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IChangeProps = React.PropsWithChildren<{
    data?: any;
    insertAfterKey?: any;
    insertBeforeKey?: any;
    key?: any;
    type?: DataChangeType;
}>;
declare const Change: ((props: IChangeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    data?: any;
    insertAfterKey?: any;
    insertBeforeKey?: any;
    key?: any;
    type?: DataChangeType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColCountByScreenProps = React.PropsWithChildren<{
    lg?: number | undefined;
    md?: number | undefined;
    sm?: number | undefined;
    xs?: number | undefined;
}>;
declare const ColCountByScreen: ((props: IColCountByScreenProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    lg?: number | undefined;
    md?: number | undefined;
    sm?: number | undefined;
    xs?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICollisionProps = React.PropsWithChildren<{
    x?: CollisionResolution;
    y?: CollisionResolution;
}>;
declare const Collision: ((props: ICollisionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: CollisionResolution | undefined;
    y?: CollisionResolution | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    allowEditing?: boolean;
    allowExporting?: boolean;
    allowFiltering?: boolean;
    allowFixing?: boolean;
    allowGrouping?: boolean;
    allowHeaderFiltering?: boolean;
    allowHiding?: boolean;
    allowReordering?: boolean;
    allowResizing?: boolean;
    allowSearch?: boolean;
    allowSorting?: boolean;
    autoExpandGroup?: boolean;
    buttons?: Array<DataGridPredefinedColumnButton | dxDataGridColumnButton>;
    calculateCellValue?: ((rowData: any) => any);
    calculateDisplayValue?: ((rowData: any) => any) | string;
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | (() => any) | Array<any>);
    calculateGroupValue?: ((rowData: any) => any) | string;
    calculateSortValue?: ((rowData: any) => any) | string;
    caption?: string | undefined;
    cellTemplate?: ((cellElement: any, cellInfo: {
        column: dxDataGridColumn;
        columnIndex: number;
        component: dxDataGrid;
        data: Record<string, any>;
        displayValue: any;
        oldValue: any;
        row: dxDataGridRowObject;
        rowIndex: number;
        rowType: string;
        text: string;
        value: any;
        watch: (() => void);
    }) => any) | template;
    columns?: Array<dxDataGridColumn | string>;
    cssClass?: string | undefined;
    customizeText?: ((cellInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string);
    dataField?: string | undefined;
    dataType?: DataType | undefined;
    editCellTemplate?: ((cellElement: any, cellInfo: {
        column: dxDataGridColumn;
        columnIndex: number;
        component: dxDataGrid;
        data: Record<string, any>;
        displayValue: any;
        row: dxDataGridRowObject;
        rowIndex: number;
        rowType: string;
        setValue(newValue: any, newText: any): any;
        text: string;
        value: any;
        watch: (() => void);
    }) => any) | template;
    editorOptions?: any;
    encodeHtml?: boolean;
    falseText?: string;
    filterOperations?: Array<FilterOperation | string>;
    filterType?: FilterType;
    filterValue?: any | undefined;
    filterValues?: Array<any>;
    fixed?: boolean;
    fixedPosition?: FixedPosition | undefined;
    format?: LocalizationFormat;
    formItem?: dxFormSimpleItem;
    groupCellTemplate?: ((cellElement: any, cellInfo: {
        column: dxDataGridColumn;
        columnIndex: number;
        component: dxDataGrid;
        data: Record<string, any>;
        displayValue: any;
        groupContinuedMessage: string;
        groupContinuesMessage: string;
        row: dxDataGridRowObject;
        rowIndex: number;
        summaryItems: Array<any>;
        text: string;
        value: any;
    }) => any) | template;
    groupIndex?: number | undefined;
    headerCellTemplate?: ((columnHeader: any, headerInfo: {
        column: dxDataGridColumn;
        columnIndex: number;
        component: dxDataGrid;
    }) => any) | template;
    headerFilter?: Record<string, any> | {
        allowSearch?: boolean;
        allowSelectAll?: boolean;
        dataSource?: Array<any> | DataSourceOptions | ((options: {
            component: Record<string, any>;
            dataSource: DataSourceOptions | null;
        }) => void) | null | Store | undefined;
        groupInterval?: HeaderFilterGroupInterval | number | undefined;
        height?: number | string | undefined;
        search?: ColumnHeaderFilterSearchConfig;
        searchMode?: SearchMode;
        width?: number | string | undefined;
    };
    hidingPriority?: number | undefined;
    isBand?: boolean | undefined;
    lookup?: Record<string, any> | {
        allowClearing?: boolean;
        calculateCellValue?: ((rowData: any) => any);
        dataSource?: Array<any> | DataSourceOptions | ((options: {
            data: Record<string, any>;
            key: any;
        }) => Array<any> | Store | DataSourceOptions) | null | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: string | undefined;
    };
    minWidth?: number | undefined;
    name?: string | undefined;
    ownerBand?: number | undefined;
    renderAsync?: boolean;
    selectedFilterOperation?: SelectedFilterOperation | undefined;
    setCellValue?: ((newData: any, value: any, currentRowData: any) => any);
    showEditorAlways?: boolean;
    showInColumnChooser?: boolean;
    showWhenGrouped?: boolean;
    sortIndex?: number | undefined;
    sortingMethod?: ((value1: any, value2: any) => number) | undefined;
    sortOrder?: SortOrder | undefined;
    trueText?: string;
    type?: DataGridCommandColumnType;
    validationRules?: Array<CommonTypes.ValidationRule>;
    visible?: boolean;
    visibleIndex?: number | undefined;
    width?: number | string | undefined;
    defaultFilterValue?: any | undefined;
    onFilterValueChange?: (value: any | undefined) => void;
    defaultFilterValues?: Array<any>;
    onFilterValuesChange?: (value: Array<any>) => void;
    defaultGroupIndex?: number | undefined;
    onGroupIndexChange?: (value: number | undefined) => void;
    defaultSelectedFilterOperation?: SelectedFilterOperation | undefined;
    onSelectedFilterOperationChange?: (value: SelectedFilterOperation | undefined) => void;
    defaultSortIndex?: number | undefined;
    onSortIndexChange?: (value: number | undefined) => void;
    defaultSortOrder?: SortOrder | undefined;
    onSortOrderChange?: (value: SortOrder | undefined) => void;
    defaultVisible?: boolean;
    onVisibleChange?: (value: boolean) => void;
    defaultVisibleIndex?: number | undefined;
    onVisibleIndexChange?: (value: number | undefined) => void;
    cellRender?: (...params: any) => React.ReactNode;
    cellComponent?: React.ComponentType<any>;
    editCellRender?: (...params: any) => React.ReactNode;
    editCellComponent?: React.ComponentType<any>;
    groupCellRender?: (...params: any) => React.ReactNode;
    groupCellComponent?: React.ComponentType<any>;
    headerCellRender?: (...params: any) => React.ReactNode;
    headerCellComponent?: React.ComponentType<any>;
}>;
declare const Column: ((props: IColumnProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    allowEditing?: boolean | undefined;
    allowExporting?: boolean | undefined;
    allowFiltering?: boolean | undefined;
    allowFixing?: boolean | undefined;
    allowGrouping?: boolean | undefined;
    allowHeaderFiltering?: boolean | undefined;
    allowHiding?: boolean | undefined;
    allowReordering?: boolean | undefined;
    allowResizing?: boolean | undefined;
    allowSearch?: boolean | undefined;
    allowSorting?: boolean | undefined;
    autoExpandGroup?: boolean | undefined;
    buttons?: (DataGridPredefinedColumnButton | dxDataGridColumnButton<any, any>)[] | undefined;
    calculateCellValue?: ((rowData: any) => any) | undefined;
    calculateDisplayValue?: string | ((rowData: any) => any) | undefined;
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | (() => any) | Array<any>) | undefined;
    calculateGroupValue?: string | ((rowData: any) => any) | undefined;
    calculateSortValue?: string | ((rowData: any) => any) | undefined;
    caption?: string | undefined;
    cellTemplate?: template | ((cellElement: any, cellInfo: {
        column: dxDataGridColumn;
        columnIndex: number;
        component: dxDataGrid;
        data: Record<string, any>;
        displayValue: any;
        oldValue: any;
        row: dxDataGridRowObject;
        rowIndex: number;
        rowType: string;
        text: string;
        value: any;
        watch: (() => void);
    }) => any) | undefined;
    columns?: (string | dxDataGridColumn<any, any>)[] | undefined;
    cssClass?: string | undefined;
    customizeText?: ((cellInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string) | undefined;
    dataField?: string | undefined;
    dataType?: DataType | undefined;
    editCellTemplate?: template | ((cellElement: any, cellInfo: {
        column: dxDataGridColumn;
        columnIndex: number;
        component: dxDataGrid;
        data: Record<string, any>;
        displayValue: any;
        row: dxDataGridRowObject;
        rowIndex: number;
        rowType: string;
        setValue(newValue: any, newText: any): any;
        text: string;
        value: any;
        watch: (() => void);
    }) => any) | undefined;
    editorOptions?: any;
    encodeHtml?: boolean | undefined;
    falseText?: string | undefined;
    filterOperations?: string[] | undefined;
    filterType?: FilterType | undefined;
    filterValue?: any | undefined;
    filterValues?: any[] | undefined;
    fixed?: boolean | undefined;
    fixedPosition?: FixedPosition | undefined;
    format?: LocalizationFormat;
    formItem?: dxFormSimpleItem | undefined;
    groupCellTemplate?: template | ((cellElement: any, cellInfo: {
        column: dxDataGridColumn;
        columnIndex: number;
        component: dxDataGrid;
        data: Record<string, any>;
        displayValue: any;
        groupContinuedMessage: string;
        groupContinuesMessage: string;
        row: dxDataGridRowObject;
        rowIndex: number;
        summaryItems: Array<any>;
        text: string;
        value: any;
    }) => any) | undefined;
    groupIndex?: number | undefined;
    headerCellTemplate?: template | ((columnHeader: any, headerInfo: {
        column: dxDataGridColumn;
        columnIndex: number;
        component: dxDataGrid;
    }) => any) | undefined;
    headerFilter?: Record<string, any> | {
        allowSearch?: boolean | undefined;
        allowSelectAll?: boolean | undefined;
        dataSource?: any[] | DataSourceOptions<any, any, any, any> | Store<any, any> | ((options: {
            component: Record<string, any>;
            dataSource: DataSourceOptions | null;
        }) => void) | null | undefined;
        groupInterval?: HeaderFilterGroupInterval | number | undefined;
        height?: number | string | undefined;
        search?: ColumnHeaderFilterSearchConfig | undefined;
        searchMode?: SearchMode | undefined;
        width?: number | string | undefined;
    } | undefined;
    hidingPriority?: number | undefined;
    isBand?: boolean | undefined;
    lookup?: Record<string, any> | {
        allowClearing?: boolean | undefined;
        calculateCellValue?: ((rowData: any) => any) | undefined;
        dataSource?: any[] | DataSourceOptions<any, any, any, any> | Store<any, any> | ((options: {
            data: Record<string, any>;
            key: any;
        }) => Array<any> | Store | DataSourceOptions) | null | undefined;
        displayExpr?: string | ((data: any) => string) | undefined;
        valueExpr?: string | undefined;
    } | undefined;
    minWidth?: number | undefined;
    name?: string | undefined;
    ownerBand?: number | undefined;
    renderAsync?: boolean | undefined;
    selectedFilterOperation?: SelectedFilterOperation | undefined;
    setCellValue?: ((newData: any, value: any, currentRowData: any) => any) | undefined;
    showEditorAlways?: boolean | undefined;
    showInColumnChooser?: boolean | undefined;
    showWhenGrouped?: boolean | undefined;
    sortIndex?: number | undefined;
    sortingMethod?: ((value1: any, value2: any) => number) | undefined;
    sortOrder?: SortOrder | undefined;
    trueText?: string | undefined;
    type?: DataGridCommandColumnType | undefined;
    validationRules?: CommonTypes.ValidationRule[] | undefined;
    visible?: boolean | undefined;
    visibleIndex?: number | undefined;
    width?: number | string | undefined;
    defaultFilterValue?: any | undefined;
    onFilterValueChange?: ((value: any | undefined) => void) | undefined;
    defaultFilterValues?: any[] | undefined;
    onFilterValuesChange?: ((value: Array<any>) => void) | undefined;
    defaultGroupIndex?: number | undefined;
    onGroupIndexChange?: ((value: number | undefined) => void) | undefined;
    defaultSelectedFilterOperation?: SelectedFilterOperation | undefined;
    onSelectedFilterOperationChange?: ((value: SelectedFilterOperation | undefined) => void) | undefined;
    defaultSortIndex?: number | undefined;
    onSortIndexChange?: ((value: number | undefined) => void) | undefined;
    defaultSortOrder?: SortOrder | undefined;
    onSortOrderChange?: ((value: SortOrder | undefined) => void) | undefined;
    defaultVisible?: boolean | undefined;
    onVisibleChange?: ((value: boolean) => void) | undefined;
    defaultVisibleIndex?: number | undefined;
    onVisibleIndexChange?: ((value: number | undefined) => void) | undefined;
    cellRender?: ((...params: any) => React.ReactNode) | undefined;
    cellComponent?: React.ComponentType<any> | undefined;
    editCellRender?: ((...params: any) => React.ReactNode) | undefined;
    editCellComponent?: React.ComponentType<any> | undefined;
    groupCellRender?: ((...params: any) => React.ReactNode) | undefined;
    groupCellComponent?: React.ComponentType<any> | undefined;
    headerCellRender?: ((...params: any) => React.ReactNode) | undefined;
    headerCellComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnChooserProps = React.PropsWithChildren<{
    allowSearch?: boolean;
    container?: any | string | undefined;
    emptyPanelText?: string;
    enabled?: boolean;
    height?: number | string;
    mode?: ColumnChooserMode;
    position?: PositionConfig | undefined;
    search?: ColumnChooserSearchConfig;
    searchTimeout?: number;
    selection?: ColumnChooserSelectionConfig;
    sortOrder?: SortOrder | undefined;
    title?: string;
    width?: number | string;
}>;
declare const ColumnChooser: ((props: IColumnChooserProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSearch?: boolean | undefined;
    container?: any | string | undefined;
    emptyPanelText?: string | undefined;
    enabled?: boolean | undefined;
    height?: string | number | undefined;
    mode?: ColumnChooserMode | undefined;
    position?: PositionConfig | undefined;
    search?: ColumnChooserSearchConfig | undefined;
    searchTimeout?: number | undefined;
    selection?: ColumnChooserSelectionConfig | undefined;
    sortOrder?: SortOrder | undefined;
    title?: string | undefined;
    width?: string | number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnChooserSearchProps = React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean;
    timeout?: number;
}>;
declare const ColumnChooserSearch: ((props: IColumnChooserSearchProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean | undefined;
    timeout?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnChooserSelectionProps = React.PropsWithChildren<{
    allowSelectAll?: boolean;
    recursive?: boolean;
    selectByClick?: boolean;
}>;
declare const ColumnChooserSelection: ((props: IColumnChooserSelectionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSelectAll?: boolean | undefined;
    recursive?: boolean | undefined;
    selectByClick?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnFixingProps = React.PropsWithChildren<{
    enabled?: boolean;
    icons?: Record<string, any> | {
        fix?: string;
        leftPosition?: string;
        rightPosition?: string;
        stickyPosition?: string;
        unfix?: string;
    };
    texts?: Record<string, any> | {
        fix?: string;
        leftPosition?: string;
        rightPosition?: string;
        stickyPosition?: string;
        unfix?: string;
    };
}>;
declare const ColumnFixing: ((props: IColumnFixingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    enabled?: boolean | undefined;
    icons?: Record<string, any> | {
        fix?: string | undefined;
        leftPosition?: string | undefined;
        rightPosition?: string | undefined;
        stickyPosition?: string | undefined;
        unfix?: string | undefined;
    } | undefined;
    texts?: Record<string, any> | {
        fix?: string | undefined;
        leftPosition?: string | undefined;
        rightPosition?: string | undefined;
        stickyPosition?: string | undefined;
        unfix?: string | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnFixingTextsProps = React.PropsWithChildren<{
    fix?: string;
    leftPosition?: string;
    rightPosition?: string;
    stickyPosition?: string;
    unfix?: string;
}>;
declare const ColumnFixingTexts: ((props: IColumnFixingTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    fix?: string | undefined;
    leftPosition?: string | undefined;
    rightPosition?: string | undefined;
    stickyPosition?: string | undefined;
    unfix?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnHeaderFilterProps = React.PropsWithChildren<{
    allowSearch?: boolean;
    allowSelectAll?: boolean;
    dataSource?: Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined;
    groupInterval?: HeaderFilterGroupInterval | number | undefined;
    height?: number | string | undefined;
    search?: ColumnHeaderFilterSearchConfig;
    searchMode?: SearchMode;
    width?: number | string | undefined;
}>;
declare const ColumnHeaderFilter: ((props: IColumnHeaderFilterProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSearch?: boolean | undefined;
    allowSelectAll?: boolean | undefined;
    dataSource?: any[] | DataSourceOptions<any, any, any, any> | Store<any, any> | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | undefined;
    groupInterval?: HeaderFilterGroupInterval | number | undefined;
    height?: number | string | undefined;
    search?: ColumnHeaderFilterSearchConfig | undefined;
    searchMode?: SearchMode | undefined;
    width?: number | string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnHeaderFilterSearchProps = React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean;
    mode?: SearchMode;
    searchExpr?: Array<(() => any) | string> | (() => any) | string | undefined;
    timeout?: number;
}>;
declare const ColumnHeaderFilterSearch: ((props: IColumnHeaderFilterSearchProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean | undefined;
    mode?: SearchMode | undefined;
    searchExpr?: Array<(() => any) | string> | (() => any) | string | undefined;
    timeout?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColumnLookupProps = React.PropsWithChildren<{
    allowClearing?: boolean;
    calculateCellValue?: ((rowData: any) => any);
    dataSource?: Array<any> | DataSourceOptions | ((options: {
        data: Record<string, any>;
        key: any;
    }) => Array<any> | Store | DataSourceOptions) | null | Store | undefined;
    displayExpr?: ((data: any) => string) | string | undefined;
    valueExpr?: string | undefined;
}>;
declare const ColumnLookup: ((props: IColumnLookupProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowClearing?: boolean | undefined;
    calculateCellValue?: ((rowData: any) => any) | undefined;
    dataSource?: any[] | DataSourceOptions<any, any, any, any> | Store<any, any> | ((options: {
        data: Record<string, any>;
        key: any;
    }) => Array<any> | Store | DataSourceOptions) | null | undefined;
    displayExpr?: string | ((data: any) => string) | undefined;
    valueExpr?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICompareRuleProps = React.PropsWithChildren<{
    comparisonTarget?: (() => any);
    comparisonType?: ComparisonOperator;
    ignoreEmptyValue?: boolean;
    message?: string;
    type?: ValidationRuleType;
}>;
declare const CompareRule: ((props: ICompareRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    comparisonTarget?: (() => any) | undefined;
    comparisonType?: ComparisonOperator | undefined;
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICursorOffsetProps = React.PropsWithChildren<{
    x?: number;
    y?: number;
}>;
declare const CursorOffset: ((props: ICursorOffsetProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: number | undefined;
    y?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICustomOperationProps = React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, field: dxFilterBuilderField) => string | (() => any) | Array<any>);
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string);
    dataTypes?: Array<DataType> | undefined;
    editorTemplate?: ((conditionInfo: {
        field: dxFilterBuilderField;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | template;
    hasValue?: boolean;
    icon?: string | undefined;
    name?: string | undefined;
    editorRender?: (...params: any) => React.ReactNode;
    editorComponent?: React.ComponentType<any>;
}>;
declare const CustomOperation: ((props: ICustomOperationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, field: dxFilterBuilderField) => string | (() => any) | Array<any>) | undefined;
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string) | undefined;
    dataTypes?: Array<DataType> | undefined;
    editorTemplate?: template | ((conditionInfo: {
        field: dxFilterBuilderField;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | undefined;
    hasValue?: boolean | undefined;
    icon?: string | undefined;
    name?: string | undefined;
    editorRender?: ((...params: any) => React.ReactNode) | undefined;
    editorComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICustomRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    reevaluate?: boolean;
    type?: ValidationRuleType;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: string | number;
    }) => boolean);
}>;
declare const CustomRule: ((props: ICustomRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    reevaluate?: boolean | undefined;
    type?: ValidationRuleType | undefined;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: string | number;
    }) => boolean) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IDataGridHeaderFilterProps = React.PropsWithChildren<{
    allowSearch?: boolean;
    allowSelectAll?: boolean;
    height?: number | string;
    search?: HeaderFilterSearchConfig;
    searchTimeout?: number;
    texts?: Record<string, any> | {
        cancel?: string;
        emptyValue?: string;
        ok?: string;
    };
    visible?: boolean;
    width?: number | string;
}>;
declare const DataGridHeaderFilter: ((props: IDataGridHeaderFilterProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSearch?: boolean | undefined;
    allowSelectAll?: boolean | undefined;
    height?: string | number | undefined;
    search?: HeaderFilterSearchConfig | undefined;
    searchTimeout?: number | undefined;
    texts?: Record<string, any> | {
        cancel?: string | undefined;
        emptyValue?: string | undefined;
        ok?: string | undefined;
    } | undefined;
    visible?: boolean | undefined;
    width?: string | number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IDataGridHeaderFilterSearchProps = React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean;
    mode?: SearchMode;
    timeout?: number;
}>;
declare const DataGridHeaderFilterSearch: ((props: IDataGridHeaderFilterSearchProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean | undefined;
    mode?: SearchMode | undefined;
    timeout?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IDataGridHeaderFilterTextsProps = React.PropsWithChildren<{
    cancel?: string;
    emptyValue?: string;
    ok?: string;
}>;
declare const DataGridHeaderFilterTexts: ((props: IDataGridHeaderFilterTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cancel?: string | undefined;
    emptyValue?: string | undefined;
    ok?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IDataGridSelectionProps = React.PropsWithChildren<{
    allowSelectAll?: boolean;
    deferred?: boolean;
    mode?: SingleMultipleOrNone;
    selectAllMode?: SelectAllMode;
    sensitivity?: SelectionSensitivity;
    showCheckBoxesMode?: SelectionColumnDisplayMode;
}>;
declare const DataGridSelection: ((props: IDataGridSelectionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSelectAll?: boolean | undefined;
    deferred?: boolean | undefined;
    mode?: SingleMultipleOrNone | undefined;
    selectAllMode?: SelectAllMode | undefined;
    sensitivity?: SelectionSensitivity | undefined;
    showCheckBoxesMode?: SelectionColumnDisplayMode | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IEditingProps = React.PropsWithChildren<{
    allowAdding?: boolean;
    allowDeleting?: boolean | ((options: {
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean);
    allowUpdating?: boolean | ((options: {
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean);
    changes?: Array<DataChange>;
    confirmDelete?: boolean;
    editColumnName?: string;
    editRowKey?: any;
    form?: dxFormOptions;
    mode?: GridsEditMode;
    newRowPosition?: NewRowPosition;
    popup?: dxPopupOptions<any>;
    refreshMode?: GridsEditRefreshMode;
    selectTextOnEditStart?: boolean;
    startEditAction?: StartEditAction;
    texts?: any | {
        addRow?: string;
        cancelAllChanges?: string;
        cancelRowChanges?: string;
        confirmDeleteMessage?: string;
        confirmDeleteTitle?: string;
        deleteRow?: string;
        editRow?: string;
        saveAllChanges?: string;
        saveRowChanges?: string;
        undeleteRow?: string;
        validationCancelChanges?: string;
    };
    useIcons?: boolean;
    defaultChanges?: Array<DataChange>;
    onChangesChange?: (value: Array<DataChange>) => void;
    defaultEditColumnName?: string;
    onEditColumnNameChange?: (value: string) => void;
    defaultEditRowKey?: any;
    onEditRowKeyChange?: (value: any) => void;
}>;
declare const Editing: ((props: IEditingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowAdding?: boolean | undefined;
    allowDeleting?: boolean | ((options: {
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean) | undefined;
    allowUpdating?: boolean | ((options: {
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean) | undefined;
    changes?: DataChange<any, any>[] | undefined;
    confirmDelete?: boolean | undefined;
    editColumnName?: string | undefined;
    editRowKey?: any;
    form?: dxFormOptions | undefined;
    mode?: GridsEditMode | undefined;
    newRowPosition?: NewRowPosition | undefined;
    popup?: dxPopupOptions<any> | undefined;
    refreshMode?: GridsEditRefreshMode | undefined;
    selectTextOnEditStart?: boolean | undefined;
    startEditAction?: StartEditAction | undefined;
    texts?: any | {
        addRow?: string;
        cancelAllChanges?: string;
        cancelRowChanges?: string;
        confirmDeleteMessage?: string;
        confirmDeleteTitle?: string;
        deleteRow?: string;
        editRow?: string;
        saveAllChanges?: string;
        saveRowChanges?: string;
        undeleteRow?: string;
        validationCancelChanges?: string;
    };
    useIcons?: boolean | undefined;
    defaultChanges?: DataChange<any, any>[] | undefined;
    onChangesChange?: ((value: Array<DataChange>) => void) | undefined;
    defaultEditColumnName?: string | undefined;
    onEditColumnNameChange?: ((value: string) => void) | undefined;
    defaultEditRowKey?: any;
    onEditRowKeyChange?: ((value: any) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IEditingTextsProps = React.PropsWithChildren<{
    addRow?: string;
    cancelAllChanges?: string;
    cancelRowChanges?: string;
    confirmDeleteMessage?: string;
    confirmDeleteTitle?: string;
    deleteRow?: string;
    editRow?: string;
    saveAllChanges?: string;
    saveRowChanges?: string;
    undeleteRow?: string;
    validationCancelChanges?: string;
}>;
declare const EditingTexts: ((props: IEditingTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    addRow?: string | undefined;
    cancelAllChanges?: string | undefined;
    cancelRowChanges?: string | undefined;
    confirmDeleteMessage?: string | undefined;
    confirmDeleteTitle?: string | undefined;
    deleteRow?: string | undefined;
    editRow?: string | undefined;
    saveAllChanges?: string | undefined;
    saveRowChanges?: string | undefined;
    undeleteRow?: string | undefined;
    validationCancelChanges?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IEmailRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    type?: ValidationRuleType;
}>;
declare const EmailRule: ((props: IEmailRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IExportProps = React.PropsWithChildren<{
    allowExportSelectedData?: boolean;
    enabled?: boolean;
    formats?: Array<DataGridExportFormat | string>;
    texts?: Record<string, any> | {
        exportAll?: string;
        exportSelectedRows?: string;
        exportTo?: string;
    };
}>;
declare const Export: ((props: IExportProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowExportSelectedData?: boolean | undefined;
    enabled?: boolean | undefined;
    formats?: string[] | undefined;
    texts?: Record<string, any> | {
        exportAll?: string | undefined;
        exportSelectedRows?: string | undefined;
        exportTo?: string | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IExportTextsProps = React.PropsWithChildren<{
    exportAll?: string;
    exportSelectedRows?: string;
    exportTo?: string;
}>;
declare const ExportTexts: ((props: IExportTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    exportAll?: string | undefined;
    exportSelectedRows?: string | undefined;
    exportTo?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFieldProps = React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string) => string | (() => any) | Array<any>);
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string);
    dataField?: string | undefined;
    dataType?: DataType;
    editorOptions?: any;
    editorTemplate?: ((conditionInfo: {
        field: dxFilterBuilderField;
        filterOperation: string;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | template;
    falseText?: string;
    filterOperations?: Array<FilterBuilderOperation | string>;
    format?: LocalizationFormat;
    lookup?: Record<string, any> | {
        allowClearing?: boolean;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
    };
    name?: string | undefined;
    trueText?: string;
    editorRender?: (...params: any) => React.ReactNode;
    editorComponent?: React.ComponentType<any>;
}>;
declare const Field: ((props: IFieldProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    calculateFilterExpression?: ((filterValue: any, selectedFilterOperation: string) => string | (() => any) | Array<any>) | undefined;
    caption?: string | undefined;
    customizeText?: ((fieldInfo: FieldInfo) => string) | undefined;
    dataField?: string | undefined;
    dataType?: DataType | undefined;
    editorOptions?: any;
    editorTemplate?: template | ((conditionInfo: {
        field: dxFilterBuilderField;
        filterOperation: string;
        setValue: (() => void);
        value: string | number | Date;
    }, container: any) => string | any) | undefined;
    falseText?: string | undefined;
    filterOperations?: string[] | undefined;
    format?: LocalizationFormat;
    lookup?: Record<string, any> | {
        allowClearing?: boolean | undefined;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: string | ((data: any) => string) | undefined;
        valueExpr?: string | ((data: any) => string | number | boolean) | undefined;
    } | undefined;
    name?: string | undefined;
    trueText?: string | undefined;
    editorRender?: ((...params: any) => React.ReactNode) | undefined;
    editorComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFieldLookupProps = React.PropsWithChildren<{
    allowClearing?: boolean;
    dataSource?: Array<any> | DataSourceOptions | Store | undefined;
    displayExpr?: ((data: any) => string) | string | undefined;
    valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
}>;
declare const FieldLookup: ((props: IFieldLookupProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowClearing?: boolean | undefined;
    dataSource?: Array<any> | DataSourceOptions | Store | undefined;
    displayExpr?: string | ((data: any) => string) | undefined;
    valueExpr?: string | ((data: any) => string | number | boolean) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFilterBuilderProps = React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean;
    allowHierarchicalFields?: boolean;
    bindingOptions?: Record<string, any>;
    customOperations?: Array<dxFilterBuilderCustomOperation>;
    disabled?: boolean;
    elementAttr?: Record<string, any>;
    fields?: Array<dxFilterBuilderField>;
    filterOperationDescriptions?: Record<string, any> | {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        isBlank?: string;
        isNotBlank?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    };
    focusStateEnabled?: boolean;
    groupOperationDescriptions?: Record<string, any> | {
        and?: string;
        notAnd?: string;
        notOr?: string;
        or?: string;
    };
    groupOperations?: Array<GroupOperation>;
    height?: (() => number | string) | number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    maxGroupLevel?: number | undefined;
    onContentReady?: ((e: FilterBuilderContentReadyEvent) => void);
    onDisposing?: ((e: FilterBuilderDisposingEvent) => void);
    onEditorPrepared?: ((e: FilterBuilderEditorPreparedEvent) => void);
    onEditorPreparing?: ((e: FilterBuilderEditorPreparingEvent) => void);
    onInitialized?: ((e: FilterBuilderInitializedEvent) => void);
    onOptionChanged?: ((e: OptionChangedEvent) => void);
    onValueChanged?: ((e: ValueChangedEvent) => void);
    rtlEnabled?: boolean;
    tabIndex?: number;
    value?: Array<any> | (() => any) | string;
    visible?: boolean;
    width?: (() => number | string) | number | string | undefined;
    defaultValue?: Array<any> | (() => any) | string;
    onValueChange?: (value: Array<any> | (() => any) | string) => void;
}>;
declare const FilterBuilder: ((props: IFilterBuilderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean | undefined;
    allowHierarchicalFields?: boolean | undefined;
    bindingOptions?: Record<string, any> | undefined;
    customOperations?: dxFilterBuilderCustomOperation[] | undefined;
    disabled?: boolean | undefined;
    elementAttr?: Record<string, any> | undefined;
    fields?: dxFilterBuilderField[] | undefined;
    filterOperationDescriptions?: Record<string, any> | {
        between?: string | undefined;
        contains?: string | undefined;
        endsWith?: string | undefined;
        equal?: string | undefined;
        greaterThan?: string | undefined;
        greaterThanOrEqual?: string | undefined;
        isBlank?: string | undefined;
        isNotBlank?: string | undefined;
        lessThan?: string | undefined;
        lessThanOrEqual?: string | undefined;
        notContains?: string | undefined;
        notEqual?: string | undefined;
        startsWith?: string | undefined;
    } | undefined;
    focusStateEnabled?: boolean | undefined;
    groupOperationDescriptions?: Record<string, any> | {
        and?: string | undefined;
        notAnd?: string | undefined;
        notOr?: string | undefined;
        or?: string | undefined;
    } | undefined;
    groupOperations?: GroupOperation[] | undefined;
    height?: (() => number | string) | number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    maxGroupLevel?: number | undefined;
    onContentReady?: ((e: FilterBuilderContentReadyEvent) => void) | undefined;
    onDisposing?: ((e: FilterBuilderDisposingEvent) => void) | undefined;
    onEditorPrepared?: ((e: FilterBuilderEditorPreparedEvent) => void) | undefined;
    onEditorPreparing?: ((e: FilterBuilderEditorPreparingEvent) => void) | undefined;
    onInitialized?: ((e: FilterBuilderInitializedEvent) => void) | undefined;
    onOptionChanged?: ((e: OptionChangedEvent) => void) | undefined;
    onValueChanged?: ((e: ValueChangedEvent) => void) | undefined;
    rtlEnabled?: boolean | undefined;
    tabIndex?: number | undefined;
    value?: string | any[] | (() => any) | undefined;
    visible?: boolean | undefined;
    width?: (() => number | string) | number | string | undefined;
    defaultValue?: string | any[] | (() => any) | undefined;
    onValueChange?: ((value: Array<any> | (() => any) | string) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFilterBuilderPopupProps = React.PropsWithChildren<{
    accessKey?: string | undefined;
    animation?: Record<string, any> | {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    bindingOptions?: Record<string, any>;
    closeOnOutsideClick?: boolean | ((event: event) => boolean);
    container?: any | string | undefined;
    contentTemplate?: ((contentElement: any) => string | any) | template;
    deferRendering?: boolean;
    disabled?: boolean;
    dragAndResizeArea?: any | string | undefined;
    dragEnabled?: boolean;
    dragOutsideBoundary?: boolean;
    enableBodyScroll?: boolean;
    focusStateEnabled?: boolean;
    fullScreen?: boolean;
    height?: (() => number | string) | number | string;
    hideOnOutsideClick?: boolean | ((event: event) => boolean);
    hideOnParentScroll?: boolean;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    maxHeight?: (() => number | string) | number | string;
    maxWidth?: (() => number | string) | number | string;
    minHeight?: (() => number | string) | number | string;
    minWidth?: (() => number | string) | number | string;
    onContentReady?: ((e: EventInfo<any>) => void);
    onDisposing?: ((e: EventInfo<any>) => void);
    onHidden?: ((e: EventInfo<any>) => void);
    onHiding?: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void);
    onInitialized?: ((e: {
        component: Component<any>;
        element: any;
    }) => void);
    onOptionChanged?: ((e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void);
    onResize?: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void);
    onResizeEnd?: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void);
    onResizeStart?: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void);
    onShowing?: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void);
    onShown?: ((e: EventInfo<any>) => void);
    onTitleRendered?: ((e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void);
    position?: (() => void) | PositionAlignment | PositionConfig;
    resizeEnabled?: boolean;
    restorePosition?: boolean;
    rtlEnabled?: boolean;
    shading?: boolean;
    shadingColor?: string;
    showCloseButton?: boolean;
    showTitle?: boolean;
    tabIndex?: number;
    title?: string;
    titleTemplate?: ((titleElement: any) => string | any) | template;
    toolbarItems?: Array<dxPopupToolbarItem>;
    visible?: boolean;
    width?: (() => number | string) | number | string;
    wrapperAttr?: any;
    defaultHeight?: (() => number | string) | number | string;
    onHeightChange?: (value: (() => number | string) | number | string) => void;
    defaultPosition?: (() => void) | PositionAlignment | PositionConfig;
    onPositionChange?: (value: (() => void) | PositionAlignment | PositionConfig) => void;
    defaultVisible?: boolean;
    onVisibleChange?: (value: boolean) => void;
    defaultWidth?: (() => number | string) | number | string;
    onWidthChange?: (value: (() => number | string) | number | string) => void;
    contentRender?: (...params: any) => React.ReactNode;
    contentComponent?: React.ComponentType<any>;
    titleRender?: (...params: any) => React.ReactNode;
    titleComponent?: React.ComponentType<any>;
}>;
declare const FilterBuilderPopup: ((props: IFilterBuilderPopupProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    accessKey?: string | undefined;
    animation?: Record<string, any> | {
        hide?: AnimationConfig | undefined;
        show?: AnimationConfig | undefined;
    } | undefined;
    bindingOptions?: Record<string, any> | undefined;
    closeOnOutsideClick?: boolean | ((event: event) => boolean) | undefined;
    container?: any | string | undefined;
    contentTemplate?: template | ((contentElement: any) => string | any) | undefined;
    deferRendering?: boolean | undefined;
    disabled?: boolean | undefined;
    dragAndResizeArea?: any | string | undefined;
    dragEnabled?: boolean | undefined;
    dragOutsideBoundary?: boolean | undefined;
    enableBodyScroll?: boolean | undefined;
    focusStateEnabled?: boolean | undefined;
    fullScreen?: boolean | undefined;
    height?: string | number | (() => number | string) | undefined;
    hideOnOutsideClick?: boolean | ((event: event) => boolean) | undefined;
    hideOnParentScroll?: boolean | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    maxHeight?: string | number | (() => number | string) | undefined;
    maxWidth?: string | number | (() => number | string) | undefined;
    minHeight?: string | number | (() => number | string) | undefined;
    minWidth?: string | number | (() => number | string) | undefined;
    onContentReady?: ((e: EventInfo<any>) => void) | undefined;
    onDisposing?: ((e: EventInfo<any>) => void) | undefined;
    onHidden?: ((e: EventInfo<any>) => void) | undefined;
    onHiding?: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void) | undefined;
    onInitialized?: ((e: {
        component: Component<any>;
        element: any;
    }) => void) | undefined;
    onOptionChanged?: ((e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void) | undefined;
    onResize?: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    onResizeEnd?: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    onResizeStart?: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    onShowing?: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void) | undefined;
    onShown?: ((e: EventInfo<any>) => void) | undefined;
    onTitleRendered?: ((e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void) | undefined;
    position?: PositionAlignment | PositionConfig | (() => void) | undefined;
    resizeEnabled?: boolean | undefined;
    restorePosition?: boolean | undefined;
    rtlEnabled?: boolean | undefined;
    shading?: boolean | undefined;
    shadingColor?: string | undefined;
    showCloseButton?: boolean | undefined;
    showTitle?: boolean | undefined;
    tabIndex?: number | undefined;
    title?: string | undefined;
    titleTemplate?: template | ((titleElement: any) => string | any) | undefined;
    toolbarItems?: import("devextreme/ui/popup").ToolbarItem[] | undefined;
    visible?: boolean | undefined;
    width?: string | number | (() => number | string) | undefined;
    wrapperAttr?: any;
    defaultHeight?: string | number | (() => number | string) | undefined;
    onHeightChange?: ((value: (() => number | string) | number | string) => void) | undefined;
    defaultPosition?: PositionAlignment | PositionConfig | (() => void) | undefined;
    onPositionChange?: ((value: (() => void) | PositionAlignment | PositionConfig) => void) | undefined;
    defaultVisible?: boolean | undefined;
    onVisibleChange?: ((value: boolean) => void) | undefined;
    defaultWidth?: string | number | (() => number | string) | undefined;
    onWidthChange?: ((value: (() => number | string) | number | string) => void) | undefined;
    contentRender?: ((...params: any) => React.ReactNode) | undefined;
    contentComponent?: React.ComponentType<any> | undefined;
    titleRender?: ((...params: any) => React.ReactNode) | undefined;
    titleComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFilterOperationDescriptionsProps = React.PropsWithChildren<{
    between?: string;
    contains?: string;
    endsWith?: string;
    equal?: string;
    greaterThan?: string;
    greaterThanOrEqual?: string;
    isBlank?: string;
    isNotBlank?: string;
    lessThan?: string;
    lessThanOrEqual?: string;
    notContains?: string;
    notEqual?: string;
    startsWith?: string;
}>;
declare const FilterOperationDescriptions: ((props: IFilterOperationDescriptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    between?: string | undefined;
    contains?: string | undefined;
    endsWith?: string | undefined;
    equal?: string | undefined;
    greaterThan?: string | undefined;
    greaterThanOrEqual?: string | undefined;
    isBlank?: string | undefined;
    isNotBlank?: string | undefined;
    lessThan?: string | undefined;
    lessThanOrEqual?: string | undefined;
    notContains?: string | undefined;
    notEqual?: string | undefined;
    startsWith?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFilterPanelProps = React.PropsWithChildren<{
    customizeText?: ((e: {
        component: GridBase;
        filterValue: Record<string, any>;
        text: string;
    }) => string);
    filterEnabled?: boolean;
    texts?: Record<string, any> | {
        clearFilter?: string;
        createFilter?: string;
        filterEnabledHint?: string;
    };
    visible?: boolean;
    defaultFilterEnabled?: boolean;
    onFilterEnabledChange?: (value: boolean) => void;
}>;
declare const FilterPanel: ((props: IFilterPanelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    customizeText?: ((e: {
        component: GridBase;
        filterValue: Record<string, any>;
        text: string;
    }) => string) | undefined;
    filterEnabled?: boolean | undefined;
    texts?: Record<string, any> | {
        clearFilter?: string | undefined;
        createFilter?: string | undefined;
        filterEnabledHint?: string | undefined;
    } | undefined;
    visible?: boolean | undefined;
    defaultFilterEnabled?: boolean | undefined;
    onFilterEnabledChange?: ((value: boolean) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFilterPanelTextsProps = React.PropsWithChildren<{
    clearFilter?: string;
    createFilter?: string;
    filterEnabledHint?: string;
}>;
declare const FilterPanelTexts: ((props: IFilterPanelTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    clearFilter?: string | undefined;
    createFilter?: string | undefined;
    filterEnabledHint?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFilterRowProps = React.PropsWithChildren<{
    applyFilter?: ApplyFilterMode;
    applyFilterText?: string;
    betweenEndText?: string;
    betweenStartText?: string;
    operationDescriptions?: Record<string, any> | {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    };
    resetOperationText?: string;
    showAllText?: string;
    showOperationChooser?: boolean;
    visible?: boolean;
}>;
declare const FilterRow: ((props: IFilterRowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    applyFilter?: ApplyFilterMode | undefined;
    applyFilterText?: string | undefined;
    betweenEndText?: string | undefined;
    betweenStartText?: string | undefined;
    operationDescriptions?: Record<string, any> | {
        between?: string | undefined;
        contains?: string | undefined;
        endsWith?: string | undefined;
        equal?: string | undefined;
        greaterThan?: string | undefined;
        greaterThanOrEqual?: string | undefined;
        lessThan?: string | undefined;
        lessThanOrEqual?: string | undefined;
        notContains?: string | undefined;
        notEqual?: string | undefined;
        startsWith?: string | undefined;
    } | undefined;
    resetOperationText?: string | undefined;
    showAllText?: string | undefined;
    showOperationChooser?: boolean | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormProps = React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean;
    alignItemLabels?: boolean;
    alignItemLabelsInAllGroups?: boolean;
    bindingOptions?: Record<string, any>;
    colCount?: Mode | number;
    colCountByScreen?: Record<string, any> | {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    customizeItem?: ((item: dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem) => void);
    disabled?: boolean;
    elementAttr?: Record<string, any>;
    focusStateEnabled?: boolean;
    formData?: any;
    height?: (() => number | string) | number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    isDirty?: boolean;
    items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    labelLocation?: LabelLocation;
    labelMode?: FormLabelMode;
    minColWidth?: number;
    onContentReady?: ((e: FormContentReadyEvent) => void);
    onDisposing?: ((e: FormDisposingEvent) => void);
    onEditorEnterKey?: ((e: EditorEnterKeyEvent) => void);
    onFieldDataChanged?: ((e: FieldDataChangedEvent) => void);
    onInitialized?: ((e: FormInitializedEvent) => void);
    onOptionChanged?: ((e: FormOptionChangedEvent) => void);
    optionalMark?: string;
    readOnly?: boolean;
    requiredMark?: string;
    requiredMessage?: string;
    rtlEnabled?: boolean;
    screenByWidth?: (() => void);
    scrollingEnabled?: boolean;
    showColonAfterLabel?: boolean;
    showOptionalMark?: boolean;
    showRequiredMark?: boolean;
    showValidationSummary?: boolean;
    tabIndex?: number;
    validationGroup?: string | undefined;
    visible?: boolean;
    width?: (() => number | string) | number | string | undefined;
    defaultFormData?: any;
    onFormDataChange?: (value: any) => void;
}>;
declare const Form: ((props: IFormProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean | undefined;
    alignItemLabels?: boolean | undefined;
    alignItemLabelsInAllGroups?: boolean | undefined;
    bindingOptions?: Record<string, any> | undefined;
    colCount?: number | "auto" | undefined;
    colCountByScreen?: Record<string, any> | {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    } | undefined;
    customizeItem?: ((item: dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem) => void) | undefined;
    disabled?: boolean | undefined;
    elementAttr?: Record<string, any> | undefined;
    focusStateEnabled?: boolean | undefined;
    formData?: any;
    height?: (() => number | string) | number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    isDirty?: boolean | undefined;
    items?: (dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem)[] | undefined;
    labelLocation?: LabelLocation | undefined;
    labelMode?: FormLabelMode | undefined;
    minColWidth?: number | undefined;
    onContentReady?: ((e: FormContentReadyEvent) => void) | undefined;
    onDisposing?: ((e: FormDisposingEvent) => void) | undefined;
    onEditorEnterKey?: ((e: EditorEnterKeyEvent) => void) | undefined;
    onFieldDataChanged?: ((e: FieldDataChangedEvent) => void) | undefined;
    onInitialized?: ((e: FormInitializedEvent) => void) | undefined;
    onOptionChanged?: ((e: FormOptionChangedEvent) => void) | undefined;
    optionalMark?: string | undefined;
    readOnly?: boolean | undefined;
    requiredMark?: string | undefined;
    requiredMessage?: string | undefined;
    rtlEnabled?: boolean | undefined;
    screenByWidth?: (() => void) | undefined;
    scrollingEnabled?: boolean | undefined;
    showColonAfterLabel?: boolean | undefined;
    showOptionalMark?: boolean | undefined;
    showRequiredMark?: boolean | undefined;
    showValidationSummary?: boolean | undefined;
    tabIndex?: number | undefined;
    validationGroup?: string | undefined;
    visible?: boolean | undefined;
    width?: (() => number | string) | number | string | undefined;
    defaultFormData?: any;
    onFormDataChange?: ((value: any) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const Format: ((props: IFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormItemProps = React.PropsWithChildren<{
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    dataField?: string | undefined;
    editorOptions?: any | undefined;
    editorType?: FormItemComponent;
    helpText?: string | undefined;
    isRequired?: boolean | undefined;
    itemType?: FormItemType;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: ((itemData: {
            component: dxForm;
            dataField: string;
            editorOptions: any;
            editorType: string;
            name: string;
            text: string;
        }, itemElement: any) => string | any) | template;
        text?: string | undefined;
        visible?: boolean;
    };
    name?: string | undefined;
    template?: ((data: {
        component: dxForm;
        dataField: string;
        editorOptions: Record<string, any>;
        editorType: string;
        name: string;
    }, itemElement: any) => string | any) | template;
    validationRules?: Array<CommonTypes.ValidationRule>;
    visible?: boolean;
    visibleIndex?: number | undefined;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const FormItem: ((props: IFormItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    colSpan?: number | undefined;
    cssClass?: string | undefined;
    dataField?: string | undefined;
    editorOptions?: any | undefined;
    editorType?: FormItemComponent | undefined;
    helpText?: string | undefined;
    isRequired?: boolean | undefined;
    itemType?: FormItemType | undefined;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        location?: LabelLocation | undefined;
        showColon?: boolean | undefined;
        template?: template | ((itemData: {
            component: dxForm;
            dataField: string;
            editorOptions: any;
            editorType: string;
            name: string;
            text: string;
        }, itemElement: any) => string | any) | undefined;
        text?: string | undefined;
        visible?: boolean | undefined;
    } | undefined;
    name?: string | undefined;
    template?: template | ((data: {
        component: dxForm;
        dataField: string;
        editorOptions: Record<string, any>;
        editorType: string;
        name: string;
    }, itemElement: any) => string | any) | undefined;
    validationRules?: CommonTypes.ValidationRule[] | undefined;
    visible?: boolean | undefined;
    visibleIndex?: number | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFromProps = React.PropsWithChildren<{
    left?: number;
    opacity?: number;
    position?: PositionConfig;
    scale?: number;
    top?: number;
}>;
declare const From: ((props: IFromProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    left?: number | undefined;
    opacity?: number | undefined;
    position?: PositionConfig | undefined;
    scale?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IGroupingProps = React.PropsWithChildren<{
    allowCollapsing?: boolean;
    autoExpandAll?: boolean;
    contextMenuEnabled?: boolean;
    expandMode?: GroupExpandMode;
    texts?: Record<string, any> | {
        groupByThisColumn?: string;
        groupContinuedMessage?: string;
        groupContinuesMessage?: string;
        ungroup?: string;
        ungroupAll?: string;
    };
}>;
declare const Grouping: ((props: IGroupingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowCollapsing?: boolean | undefined;
    autoExpandAll?: boolean | undefined;
    contextMenuEnabled?: boolean | undefined;
    expandMode?: GroupExpandMode | undefined;
    texts?: Record<string, any> | {
        groupByThisColumn?: string | undefined;
        groupContinuedMessage?: string | undefined;
        groupContinuesMessage?: string | undefined;
        ungroup?: string | undefined;
        ungroupAll?: string | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IGroupingTextsProps = React.PropsWithChildren<{
    groupByThisColumn?: string;
    groupContinuedMessage?: string;
    groupContinuesMessage?: string;
    ungroup?: string;
    ungroupAll?: string;
}>;
declare const GroupingTexts: ((props: IGroupingTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    groupByThisColumn?: string | undefined;
    groupContinuedMessage?: string | undefined;
    groupContinuesMessage?: string | undefined;
    ungroup?: string | undefined;
    ungroupAll?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IGroupItemProps = React.PropsWithChildren<{
    alignByColumn?: boolean;
    column?: string | undefined;
    customizeText?: ((itemInfo: {
        value: string | number | Date;
        valueText: string;
    }) => string);
    displayFormat?: string | undefined;
    name?: string | undefined;
    showInColumn?: string | undefined;
    showInGroupFooter?: boolean;
    skipEmptyValues?: boolean;
    summaryType?: string | SummaryType | undefined;
    valueFormat?: LocalizationFormat | undefined;
}>;
declare const GroupItem: ((props: IGroupItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignByColumn?: boolean | undefined;
    column?: string | undefined;
    customizeText?: ((itemInfo: {
        value: string | number | Date;
        valueText: string;
    }) => string) | undefined;
    displayFormat?: string | undefined;
    name?: string | undefined;
    showInColumn?: string | undefined;
    showInGroupFooter?: boolean | undefined;
    skipEmptyValues?: boolean | undefined;
    summaryType?: string | SummaryType | undefined;
    valueFormat?: LocalizationFormat | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IGroupOperationDescriptionsProps = React.PropsWithChildren<{
    and?: string;
    notAnd?: string;
    notOr?: string;
    or?: string;
}>;
declare const GroupOperationDescriptions: ((props: IGroupOperationDescriptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    and?: string | undefined;
    notAnd?: string | undefined;
    notOr?: string | undefined;
    or?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IGroupPanelProps = React.PropsWithChildren<{
    allowColumnDragging?: boolean;
    emptyPanelText?: string;
    visible?: boolean | Mode;
    defaultVisible?: boolean | Mode;
    onVisibleChange?: (value: boolean | Mode) => void;
}>;
declare const GroupPanel: ((props: IGroupPanelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowColumnDragging?: boolean | undefined;
    emptyPanelText?: string | undefined;
    visible?: boolean | "auto" | undefined;
    defaultVisible?: boolean | "auto" | undefined;
    onVisibleChange?: ((value: boolean | Mode) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHeaderFilterProps = React.PropsWithChildren<{
    allowSearch?: boolean;
    allowSelectAll?: boolean;
    dataSource?: Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined;
    groupInterval?: HeaderFilterGroupInterval | number | undefined;
    height?: number | string | undefined;
    search?: ColumnHeaderFilterSearchConfig | HeaderFilterSearchConfig;
    searchMode?: SearchMode;
    width?: number | string | undefined;
    searchTimeout?: number;
    texts?: Record<string, any> | {
        cancel?: string;
        emptyValue?: string;
        ok?: string;
    };
    visible?: boolean;
}>;
declare const HeaderFilter: ((props: IHeaderFilterProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSearch?: boolean | undefined;
    allowSelectAll?: boolean | undefined;
    dataSource?: any[] | DataSourceOptions<any, any, any, any> | Store<any, any> | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | undefined;
    groupInterval?: HeaderFilterGroupInterval | number | undefined;
    height?: number | string | undefined;
    search?: HeaderFilterSearchConfig | ColumnHeaderFilterSearchConfig | undefined;
    searchMode?: SearchMode | undefined;
    width?: number | string | undefined;
    searchTimeout?: number | undefined;
    texts?: Record<string, any> | {
        cancel?: string | undefined;
        emptyValue?: string | undefined;
        ok?: string | undefined;
    } | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHideProps = React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void);
    delay?: number;
    direction?: Direction | undefined;
    duration?: number;
    easing?: string;
    from?: AnimationState;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void);
    to?: AnimationState;
    type?: AnimationType;
}>;
declare const Hide: ((props: IHideProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void) | undefined;
    delay?: number | undefined;
    direction?: Direction | undefined;
    duration?: number | undefined;
    easing?: string | undefined;
    from?: AnimationState | undefined;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void) | undefined;
    to?: AnimationState | undefined;
    type?: AnimationType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IIconsProps = React.PropsWithChildren<{
    fix?: string;
    leftPosition?: string;
    rightPosition?: string;
    stickyPosition?: string;
    unfix?: string;
}>;
declare const Icons: ((props: IIconsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    fix?: string | undefined;
    leftPosition?: string | undefined;
    rightPosition?: string | undefined;
    stickyPosition?: string | undefined;
    unfix?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IItemProps = React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean;
    html?: string;
    locateInMenu?: LocateInMenuMode;
    location?: ToolbarItemLocation;
    menuItemTemplate?: (() => string | any) | template;
    name?: DataGridPredefinedToolbarItem | string;
    options?: any;
    showText?: ShowTextMode;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    widget?: ToolbarItemComponent;
    menuItemRender?: (...params: any) => React.ReactNode;
    menuItemComponent?: React.ComponentType<any>;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const Item: ((props: IItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean | undefined;
    html?: string | undefined;
    locateInMenu?: LocateInMenuMode | undefined;
    location?: ToolbarItemLocation | undefined;
    menuItemTemplate?: template | (() => string | any) | undefined;
    name?: string | undefined;
    options?: any;
    showText?: ShowTextMode | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    widget?: ToolbarItemComponent | undefined;
    menuItemRender?: ((...params: any) => React.ReactNode) | undefined;
    menuItemComponent?: React.ComponentType<any> | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IKeyboardNavigationProps = React.PropsWithChildren<{
    editOnKeyPress?: boolean;
    enabled?: boolean;
    enterKeyAction?: EnterKeyAction;
    enterKeyDirection?: EnterKeyDirection;
}>;
declare const KeyboardNavigation: ((props: IKeyboardNavigationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    editOnKeyPress?: boolean | undefined;
    enabled?: boolean | undefined;
    enterKeyAction?: EnterKeyAction | undefined;
    enterKeyDirection?: EnterKeyDirection | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILabelProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment;
    location?: LabelLocation;
    showColon?: boolean;
    template?: ((itemData: {
        component: dxForm;
        dataField: string;
        editorOptions: any;
        editorType: string;
        name: string;
        text: string;
    }, itemElement: any) => string | any) | template;
    text?: string | undefined;
    visible?: boolean;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const Label: ((props: ILabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    location?: LabelLocation | undefined;
    showColon?: boolean | undefined;
    template?: template | ((itemData: {
        component: dxForm;
        dataField: string;
        editorOptions: any;
        editorType: string;
        name: string;
        text: string;
    }, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILoadPanelProps = React.PropsWithChildren<{
    enabled?: boolean | Mode;
    height?: number | string;
    indicatorSrc?: string;
    shading?: boolean;
    shadingColor?: string;
    showIndicator?: boolean;
    showPane?: boolean;
    text?: string;
    width?: number | string;
}>;
declare const LoadPanel: ((props: ILoadPanelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    enabled?: boolean | "auto" | undefined;
    height?: string | number | undefined;
    indicatorSrc?: string | undefined;
    shading?: boolean | undefined;
    shadingColor?: string | undefined;
    showIndicator?: boolean | undefined;
    showPane?: boolean | undefined;
    text?: string | undefined;
    width?: string | number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILookupProps = React.PropsWithChildren<{
    allowClearing?: boolean;
    calculateCellValue?: ((rowData: any) => any);
    dataSource?: Array<any> | DataSourceOptions | ((options: {
        data: Record<string, any>;
        key: any;
    }) => Array<any> | Store | DataSourceOptions) | null | Store | undefined;
    displayExpr?: ((data: any) => string) | string | undefined;
    valueExpr?: string | undefined | ((data: any) => string | number | boolean);
}>;
declare const Lookup: ((props: ILookupProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowClearing?: boolean | undefined;
    calculateCellValue?: ((rowData: any) => any) | undefined;
    dataSource?: any[] | DataSourceOptions<any, any, any, any> | Store<any, any> | ((options: {
        data: Record<string, any>;
        key: any;
    }) => Array<any> | Store | DataSourceOptions) | null | undefined;
    displayExpr?: string | ((data: any) => string) | undefined;
    valueExpr?: string | ((data: any) => string | number | boolean) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMasterDetailProps = React.PropsWithChildren<{
    autoExpandAll?: boolean;
    enabled?: boolean;
    template?: ((detailElement: any, detailInfo: {
        data: Record<string, any>;
        key: any;
        watch: (() => void);
    }) => any) | template;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const MasterDetail: ((props: IMasterDetailProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    autoExpandAll?: boolean | undefined;
    enabled?: boolean | undefined;
    template?: template | ((detailElement: any, detailInfo: {
        data: Record<string, any>;
        key: any;
        watch: (() => void);
    }) => any) | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMyProps = React.PropsWithChildren<{
    x?: HorizontalAlignment;
    y?: VerticalAlignment;
}>;
declare const My: ((props: IMyProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: HorizontalAlignment | undefined;
    y?: VerticalAlignment | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type INumericRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    type?: ValidationRuleType;
}>;
declare const NumericRule: ((props: INumericRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IOffsetProps = React.PropsWithChildren<{
    x?: number;
    y?: number;
}>;
declare const Offset: ((props: IOffsetProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    x?: number | undefined;
    y?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IOperationDescriptionsProps = React.PropsWithChildren<{
    between?: string;
    contains?: string;
    endsWith?: string;
    equal?: string;
    greaterThan?: string;
    greaterThanOrEqual?: string;
    lessThan?: string;
    lessThanOrEqual?: string;
    notContains?: string;
    notEqual?: string;
    startsWith?: string;
}>;
declare const OperationDescriptions: ((props: IOperationDescriptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    between?: string | undefined;
    contains?: string | undefined;
    endsWith?: string | undefined;
    equal?: string | undefined;
    greaterThan?: string | undefined;
    greaterThanOrEqual?: string | undefined;
    lessThan?: string | undefined;
    lessThanOrEqual?: string | undefined;
    notContains?: string | undefined;
    notEqual?: string | undefined;
    startsWith?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPagerProps = React.PropsWithChildren<{
    allowedPageSizes?: Array<number | PagerPageSize> | Mode;
    displayMode?: DisplayMode;
    infoText?: string;
    label?: string;
    showInfo?: boolean;
    showNavigationButtons?: boolean;
    showPageSizeSelector?: boolean;
    visible?: boolean | Mode;
}>;
declare const Pager: ((props: IPagerProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowedPageSizes?: "auto" | (number | PagerPageSize)[] | undefined;
    displayMode?: DisplayMode | undefined;
    infoText?: string | undefined;
    label?: string | undefined;
    showInfo?: boolean | undefined;
    showNavigationButtons?: boolean | undefined;
    showPageSizeSelector?: boolean | undefined;
    visible?: boolean | "auto" | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPagingProps = React.PropsWithChildren<{
    enabled?: boolean;
    pageIndex?: number;
    pageSize?: number;
    defaultPageIndex?: number;
    onPageIndexChange?: (value: number) => void;
    defaultPageSize?: number;
    onPageSizeChange?: (value: number) => void;
}>;
declare const Paging: ((props: IPagingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    enabled?: boolean | undefined;
    pageIndex?: number | undefined;
    pageSize?: number | undefined;
    defaultPageIndex?: number | undefined;
    onPageIndexChange?: ((value: number) => void) | undefined;
    defaultPageSize?: number | undefined;
    onPageSizeChange?: ((value: number) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPatternRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    message?: string;
    pattern?: RegExp | string;
    type?: ValidationRuleType;
}>;
declare const PatternRule: ((props: IPatternRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    message?: string | undefined;
    pattern?: string | RegExp | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPopupProps = React.PropsWithChildren<{
    accessKey?: string | undefined;
    animation?: Record<string, any> | {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    bindingOptions?: Record<string, any>;
    closeOnOutsideClick?: boolean | ((event: event) => boolean);
    container?: any | string | undefined;
    contentTemplate?: ((contentElement: any) => string | any) | template;
    deferRendering?: boolean;
    disabled?: boolean;
    dragAndResizeArea?: any | string | undefined;
    dragEnabled?: boolean;
    dragOutsideBoundary?: boolean;
    enableBodyScroll?: boolean;
    focusStateEnabled?: boolean;
    fullScreen?: boolean;
    height?: (() => number | string) | number | string;
    hideOnOutsideClick?: boolean | ((event: event) => boolean);
    hideOnParentScroll?: boolean;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    maxHeight?: (() => number | string) | number | string;
    maxWidth?: (() => number | string) | number | string;
    minHeight?: (() => number | string) | number | string;
    minWidth?: (() => number | string) | number | string;
    onContentReady?: ((e: EventInfo<any>) => void);
    onDisposing?: ((e: EventInfo<any>) => void);
    onHidden?: ((e: EventInfo<any>) => void);
    onHiding?: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void);
    onInitialized?: ((e: {
        component: Component<any>;
        element: any;
    }) => void);
    onOptionChanged?: ((e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void);
    onResize?: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void);
    onResizeEnd?: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void);
    onResizeStart?: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void);
    onShowing?: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void);
    onShown?: ((e: EventInfo<any>) => void);
    onTitleRendered?: ((e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void);
    position?: (() => void) | PositionAlignment | PositionConfig;
    resizeEnabled?: boolean;
    restorePosition?: boolean;
    rtlEnabled?: boolean;
    shading?: boolean;
    shadingColor?: string;
    showCloseButton?: boolean;
    showTitle?: boolean;
    tabIndex?: number;
    title?: string;
    titleTemplate?: ((titleElement: any) => string | any) | template;
    toolbarItems?: Array<dxPopupToolbarItem>;
    visible?: boolean;
    width?: (() => number | string) | number | string;
    wrapperAttr?: any;
    defaultHeight?: (() => number | string) | number | string;
    onHeightChange?: (value: (() => number | string) | number | string) => void;
    defaultPosition?: (() => void) | PositionAlignment | PositionConfig;
    onPositionChange?: (value: (() => void) | PositionAlignment | PositionConfig) => void;
    defaultVisible?: boolean;
    onVisibleChange?: (value: boolean) => void;
    defaultWidth?: (() => number | string) | number | string;
    onWidthChange?: (value: (() => number | string) | number | string) => void;
    contentRender?: (...params: any) => React.ReactNode;
    contentComponent?: React.ComponentType<any>;
    titleRender?: (...params: any) => React.ReactNode;
    titleComponent?: React.ComponentType<any>;
}>;
declare const Popup: ((props: IPopupProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    accessKey?: string | undefined;
    animation?: Record<string, any> | {
        hide?: AnimationConfig | undefined;
        show?: AnimationConfig | undefined;
    } | undefined;
    bindingOptions?: Record<string, any> | undefined;
    closeOnOutsideClick?: boolean | ((event: event) => boolean) | undefined;
    container?: any | string | undefined;
    contentTemplate?: template | ((contentElement: any) => string | any) | undefined;
    deferRendering?: boolean | undefined;
    disabled?: boolean | undefined;
    dragAndResizeArea?: any | string | undefined;
    dragEnabled?: boolean | undefined;
    dragOutsideBoundary?: boolean | undefined;
    enableBodyScroll?: boolean | undefined;
    focusStateEnabled?: boolean | undefined;
    fullScreen?: boolean | undefined;
    height?: string | number | (() => number | string) | undefined;
    hideOnOutsideClick?: boolean | ((event: event) => boolean) | undefined;
    hideOnParentScroll?: boolean | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    maxHeight?: string | number | (() => number | string) | undefined;
    maxWidth?: string | number | (() => number | string) | undefined;
    minHeight?: string | number | (() => number | string) | undefined;
    minWidth?: string | number | (() => number | string) | undefined;
    onContentReady?: ((e: EventInfo<any>) => void) | undefined;
    onDisposing?: ((e: EventInfo<any>) => void) | undefined;
    onHidden?: ((e: EventInfo<any>) => void) | undefined;
    onHiding?: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void) | undefined;
    onInitialized?: ((e: {
        component: Component<any>;
        element: any;
    }) => void) | undefined;
    onOptionChanged?: ((e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void) | undefined;
    onResize?: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    onResizeEnd?: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    onResizeStart?: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    onShowing?: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void) | undefined;
    onShown?: ((e: EventInfo<any>) => void) | undefined;
    onTitleRendered?: ((e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void) | undefined;
    position?: PositionAlignment | PositionConfig | (() => void) | undefined;
    resizeEnabled?: boolean | undefined;
    restorePosition?: boolean | undefined;
    rtlEnabled?: boolean | undefined;
    shading?: boolean | undefined;
    shadingColor?: string | undefined;
    showCloseButton?: boolean | undefined;
    showTitle?: boolean | undefined;
    tabIndex?: number | undefined;
    title?: string | undefined;
    titleTemplate?: template | ((titleElement: any) => string | any) | undefined;
    toolbarItems?: import("devextreme/ui/popup").ToolbarItem[] | undefined;
    visible?: boolean | undefined;
    width?: string | number | (() => number | string) | undefined;
    wrapperAttr?: any;
    defaultHeight?: string | number | (() => number | string) | undefined;
    onHeightChange?: ((value: (() => number | string) | number | string) => void) | undefined;
    defaultPosition?: PositionAlignment | PositionConfig | (() => void) | undefined;
    onPositionChange?: ((value: (() => void) | PositionAlignment | PositionConfig) => void) | undefined;
    defaultVisible?: boolean | undefined;
    onVisibleChange?: ((value: boolean) => void) | undefined;
    defaultWidth?: string | number | (() => number | string) | undefined;
    onWidthChange?: ((value: (() => number | string) | number | string) => void) | undefined;
    contentRender?: ((...params: any) => React.ReactNode) | undefined;
    contentComponent?: React.ComponentType<any> | undefined;
    titleRender?: ((...params: any) => React.ReactNode) | undefined;
    titleComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPositionProps = React.PropsWithChildren<{
    at?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    boundary?: any | string;
    boundaryOffset?: Record<string, any> | string | {
        x?: number;
        y?: number;
    };
    collision?: CollisionResolutionCombination | Record<string, any> | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    };
    my?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    of?: any | string;
    offset?: Record<string, any> | string | {
        x?: number;
        y?: number;
    };
}>;
declare const Position: ((props: IPositionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    at?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment | undefined;
        y?: VerticalAlignment | undefined;
    } | undefined;
    boundary?: any | string;
    boundaryOffset?: string | Record<string, any> | {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
    collision?: Record<string, any> | CollisionResolutionCombination | {
        x?: CollisionResolution | undefined;
        y?: CollisionResolution | undefined;
    } | undefined;
    my?: Record<string, any> | PositionAlignment | {
        x?: HorizontalAlignment | undefined;
        y?: VerticalAlignment | undefined;
    } | undefined;
    of?: any | string;
    offset?: string | Record<string, any> | {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IRangeRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    max?: Date | number | string;
    message?: string;
    min?: Date | number | string;
    reevaluate?: boolean;
    type?: ValidationRuleType;
}>;
declare const RangeRule: ((props: IRangeRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    max?: string | number | Date | undefined;
    message?: string | undefined;
    min?: string | number | Date | undefined;
    reevaluate?: boolean | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IRemoteOperationsProps = React.PropsWithChildren<{
    filtering?: boolean;
    grouping?: boolean;
    groupPaging?: boolean;
    paging?: boolean;
    sorting?: boolean;
    summary?: boolean;
}>;
declare const RemoteOperations: ((props: IRemoteOperationsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    filtering?: boolean | undefined;
    grouping?: boolean | undefined;
    groupPaging?: boolean | undefined;
    paging?: boolean | undefined;
    sorting?: boolean | undefined;
    summary?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IRequiredRuleProps = React.PropsWithChildren<{
    message?: string;
    trim?: boolean;
    type?: ValidationRuleType;
}>;
declare const RequiredRule: ((props: IRequiredRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    message?: string | undefined;
    trim?: boolean | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IRowDraggingProps = React.PropsWithChildren<{
    allowDropInsideItem?: boolean;
    allowReordering?: boolean;
    autoScroll?: boolean;
    boundary?: any | string | undefined;
    container?: any | string | undefined;
    cursorOffset?: Record<string, any> | string | {
        x?: number;
        y?: number;
    };
    data?: any | undefined;
    dragDirection?: DragDirection;
    dragTemplate?: ((dragInfo: {
        itemData: any;
        itemElement: any;
    }, containerElement: any) => string | any) | template | undefined;
    dropFeedbackMode?: DragHighlight;
    filter?: string;
    group?: string | undefined;
    handle?: string;
    onAdd?: ((e: {
        component: GridBase;
        dropInsideItem: boolean;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        fromIndex: number;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
        toIndex: number;
    }) => void);
    onDragChange?: ((e: {
        cancel: boolean;
        component: GridBase;
        dropInsideItem: boolean;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        fromIndex: number;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
        toIndex: number;
    }) => void);
    onDragEnd?: ((e: {
        cancel: boolean;
        component: GridBase;
        dropInsideItem: boolean;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        fromIndex: number;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
        toIndex: number;
    }) => void);
    onDragMove?: ((e: {
        cancel: boolean;
        component: GridBase;
        dropInsideItem: boolean;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        fromIndex: number;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
        toIndex: number;
    }) => void);
    onDragStart?: ((e: {
        cancel: boolean;
        component: GridBase;
        event: event;
        fromData: any;
        fromIndex: number;
        itemData: any;
        itemElement: any;
    }) => void);
    onRemove?: ((e: {
        component: GridBase;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        fromIndex: number;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
        toIndex: number;
    }) => void);
    onReorder?: ((e: {
        component: GridBase;
        dropInsideItem: boolean;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        fromIndex: number;
        itemData: any;
        itemElement: any;
        promise: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
        toIndex: number;
    }) => void);
    scrollSensitivity?: number;
    scrollSpeed?: number;
    showDragIcons?: boolean;
    dragRender?: (...params: any) => React.ReactNode;
    dragComponent?: React.ComponentType<any>;
}>;
declare const RowDragging: ((props: IRowDraggingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowDropInsideItem?: boolean | undefined;
    allowReordering?: boolean | undefined;
    autoScroll?: boolean | undefined;
    boundary?: any | string | undefined;
    container?: any | string | undefined;
    cursorOffset?: string | Record<string, any> | {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
    data?: any | undefined;
    dragDirection?: DragDirection | undefined;
    dragTemplate?: template | ((dragInfo: {
        itemData: any;
        itemElement: any;
    }, containerElement: any) => string | any) | undefined;
    dropFeedbackMode?: DragHighlight | undefined;
    filter?: string | undefined;
    group?: string | undefined;
    handle?: string | undefined;
    onAdd?: ((e: {
        component: GridBase;
        dropInsideItem: boolean;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        fromIndex: number;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
        toIndex: number;
    }) => void) | undefined;
    onDragChange?: ((e: {
        cancel: boolean;
        component: GridBase;
        dropInsideItem: boolean;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        fromIndex: number;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
        toIndex: number;
    }) => void) | undefined;
    onDragEnd?: ((e: {
        cancel: boolean;
        component: GridBase;
        dropInsideItem: boolean;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        fromIndex: number;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
        toIndex: number;
    }) => void) | undefined;
    onDragMove?: ((e: {
        cancel: boolean;
        component: GridBase;
        dropInsideItem: boolean;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        fromIndex: number;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
        toIndex: number;
    }) => void) | undefined;
    onDragStart?: ((e: {
        cancel: boolean;
        component: GridBase;
        event: event;
        fromData: any;
        fromIndex: number;
        itemData: any;
        itemElement: any;
    }) => void) | undefined;
    onRemove?: ((e: {
        component: GridBase;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        fromIndex: number;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
        toIndex: number;
    }) => void) | undefined;
    onReorder?: ((e: {
        component: GridBase;
        dropInsideItem: boolean;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        fromIndex: number;
        itemData: any;
        itemElement: any;
        promise: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
        toIndex: number;
    }) => void) | undefined;
    scrollSensitivity?: number | undefined;
    scrollSpeed?: number | undefined;
    showDragIcons?: boolean | undefined;
    dragRender?: ((...params: any) => React.ReactNode) | undefined;
    dragComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IScrollingProps = React.PropsWithChildren<{
    columnRenderingMode?: DataRenderMode;
    mode?: DataGridScrollMode;
    preloadEnabled?: boolean;
    renderAsync?: boolean | undefined;
    rowRenderingMode?: DataRenderMode;
    scrollByContent?: boolean;
    scrollByThumb?: boolean;
    showScrollbar?: ScrollbarMode;
    useNative?: boolean | Mode;
}>;
declare const Scrolling: ((props: IScrollingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    columnRenderingMode?: DataRenderMode | undefined;
    mode?: DataGridScrollMode | undefined;
    preloadEnabled?: boolean | undefined;
    renderAsync?: boolean | undefined;
    rowRenderingMode?: DataRenderMode | undefined;
    scrollByContent?: boolean | undefined;
    scrollByThumb?: boolean | undefined;
    showScrollbar?: ScrollbarMode | undefined;
    useNative?: boolean | "auto" | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISearchProps = React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean;
    mode?: SearchMode;
    searchExpr?: Array<(() => any) | string> | (() => any) | string | undefined;
    timeout?: number;
}>;
declare const Search: ((props: ISearchProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    editorOptions?: any;
    enabled?: boolean | undefined;
    mode?: SearchMode | undefined;
    searchExpr?: Array<(() => any) | string> | (() => any) | string | undefined;
    timeout?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISearchPanelProps = React.PropsWithChildren<{
    highlightCaseSensitive?: boolean;
    highlightSearchText?: boolean;
    placeholder?: string;
    searchVisibleColumnsOnly?: boolean;
    text?: string;
    visible?: boolean;
    width?: number | string;
    defaultText?: string;
    onTextChange?: (value: string) => void;
}>;
declare const SearchPanel: ((props: ISearchPanelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    highlightCaseSensitive?: boolean | undefined;
    highlightSearchText?: boolean | undefined;
    placeholder?: string | undefined;
    searchVisibleColumnsOnly?: boolean | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    width?: string | number | undefined;
    defaultText?: string | undefined;
    onTextChange?: ((value: string) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISelectionProps = React.PropsWithChildren<{
    allowSelectAll?: boolean;
    deferred?: boolean;
    mode?: SingleMultipleOrNone;
    selectAllMode?: SelectAllMode;
    sensitivity?: SelectionSensitivity;
    showCheckBoxesMode?: SelectionColumnDisplayMode;
    recursive?: boolean;
    selectByClick?: boolean;
}>;
declare const Selection: ((props: ISelectionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSelectAll?: boolean | undefined;
    deferred?: boolean | undefined;
    mode?: SingleMultipleOrNone | undefined;
    selectAllMode?: SelectAllMode | undefined;
    sensitivity?: SelectionSensitivity | undefined;
    showCheckBoxesMode?: SelectionColumnDisplayMode | undefined;
    recursive?: boolean | undefined;
    selectByClick?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShowProps = React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void);
    delay?: number;
    direction?: Direction | undefined;
    duration?: number;
    easing?: string;
    from?: AnimationState;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void);
    to?: AnimationState;
    type?: AnimationType;
}>;
declare const Show: ((props: IShowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    complete?: (($element: any, config: AnimationConfig) => void) | undefined;
    delay?: number | undefined;
    direction?: Direction | undefined;
    duration?: number | undefined;
    easing?: string | undefined;
    from?: AnimationState | undefined;
    staggerDelay?: number | undefined;
    start?: (($element: any, config: AnimationConfig) => void) | undefined;
    to?: AnimationState | undefined;
    type?: AnimationType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISortByGroupSummaryInfoProps = React.PropsWithChildren<{
    groupColumn?: string | undefined;
    sortOrder?: SortOrder | undefined;
    summaryItem?: number | string | undefined;
}>;
declare const SortByGroupSummaryInfo: ((props: ISortByGroupSummaryInfoProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    groupColumn?: string | undefined;
    sortOrder?: SortOrder | undefined;
    summaryItem?: number | string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISortingProps = React.PropsWithChildren<{
    ascendingText?: string;
    clearText?: string;
    descendingText?: string;
    mode?: SingleMultipleOrNone;
    showSortIndexes?: boolean;
}>;
declare const Sorting: ((props: ISortingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ascendingText?: string | undefined;
    clearText?: string | undefined;
    descendingText?: string | undefined;
    mode?: SingleMultipleOrNone | undefined;
    showSortIndexes?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IStateStoringProps = React.PropsWithChildren<{
    customLoad?: (() => any);
    customSave?: ((gridState: any) => void);
    enabled?: boolean;
    savingTimeout?: number;
    storageKey?: string;
    type?: StateStoreType;
}>;
declare const StateStoring: ((props: IStateStoringProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    customLoad?: (() => any) | undefined;
    customSave?: ((gridState: any) => void) | undefined;
    enabled?: boolean | undefined;
    savingTimeout?: number | undefined;
    storageKey?: string | undefined;
    type?: StateStoreType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IStringLengthRuleProps = React.PropsWithChildren<{
    ignoreEmptyValue?: boolean;
    max?: number;
    message?: string;
    min?: number;
    trim?: boolean;
    type?: ValidationRuleType;
}>;
declare const StringLengthRule: ((props: IStringLengthRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    ignoreEmptyValue?: boolean | undefined;
    max?: number | undefined;
    message?: string | undefined;
    min?: number | undefined;
    trim?: boolean | undefined;
    type?: ValidationRuleType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISummaryProps = React.PropsWithChildren<{
    calculateCustomSummary?: ((options: {
        component: dxDataGrid;
        groupIndex: number;
        name: string;
        summaryProcess: string;
        totalValue: any;
        value: any;
    }) => void);
    groupItems?: Array<Record<string, any>> | {
        alignByColumn?: boolean;
        column?: string | undefined;
        customizeText?: ((itemInfo: {
            value: string | number | Date;
            valueText: string;
        }) => string);
        displayFormat?: string | undefined;
        name?: string | undefined;
        showInColumn?: string | undefined;
        showInGroupFooter?: boolean;
        skipEmptyValues?: boolean;
        summaryType?: string | SummaryType | undefined;
        valueFormat?: LocalizationFormat | undefined;
    }[];
    recalculateWhileEditing?: boolean;
    skipEmptyValues?: boolean;
    texts?: Record<string, any> | {
        avg?: string;
        avgOtherColumn?: string;
        count?: string;
        max?: string;
        maxOtherColumn?: string;
        min?: string;
        minOtherColumn?: string;
        sum?: string;
        sumOtherColumn?: string;
    };
    totalItems?: Array<Record<string, any>> | {
        alignment?: HorizontalAlignment | undefined;
        column?: string | undefined;
        cssClass?: string | undefined;
        customizeText?: ((itemInfo: {
            value: string | number | Date;
            valueText: string;
        }) => string);
        displayFormat?: string | undefined;
        name?: string | undefined;
        showInColumn?: string | undefined;
        skipEmptyValues?: boolean;
        summaryType?: string | SummaryType | undefined;
        valueFormat?: LocalizationFormat | undefined;
    }[];
}>;
declare const Summary: ((props: ISummaryProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    calculateCustomSummary?: ((options: {
        component: dxDataGrid;
        groupIndex: number;
        name: string;
        summaryProcess: string;
        totalValue: any;
        value: any;
    }) => void) | undefined;
    groupItems?: Record<string, any>[] | {
        alignByColumn?: boolean | undefined;
        column?: string | undefined;
        customizeText?: ((itemInfo: {
            value: string | number | Date;
            valueText: string;
        }) => string) | undefined;
        displayFormat?: string | undefined;
        name?: string | undefined;
        showInColumn?: string | undefined;
        showInGroupFooter?: boolean | undefined;
        skipEmptyValues?: boolean | undefined;
        summaryType?: string | SummaryType | undefined;
        valueFormat?: LocalizationFormat | undefined;
    }[] | undefined;
    recalculateWhileEditing?: boolean | undefined;
    skipEmptyValues?: boolean | undefined;
    texts?: Record<string, any> | {
        avg?: string | undefined;
        avgOtherColumn?: string | undefined;
        count?: string | undefined;
        max?: string | undefined;
        maxOtherColumn?: string | undefined;
        min?: string | undefined;
        minOtherColumn?: string | undefined;
        sum?: string | undefined;
        sumOtherColumn?: string | undefined;
    } | undefined;
    totalItems?: Record<string, any>[] | {
        alignment?: HorizontalAlignment | undefined;
        column?: string | undefined;
        cssClass?: string | undefined;
        customizeText?: ((itemInfo: {
            value: string | number | Date;
            valueText: string;
        }) => string) | undefined;
        displayFormat?: string | undefined;
        name?: string | undefined;
        showInColumn?: string | undefined;
        skipEmptyValues?: boolean | undefined;
        summaryType?: string | SummaryType | undefined;
        valueFormat?: LocalizationFormat | undefined;
    }[] | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISummaryTextsProps = React.PropsWithChildren<{
    avg?: string;
    avgOtherColumn?: string;
    count?: string;
    max?: string;
    maxOtherColumn?: string;
    min?: string;
    minOtherColumn?: string;
    sum?: string;
    sumOtherColumn?: string;
}>;
declare const SummaryTexts: ((props: ISummaryTextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    avg?: string | undefined;
    avgOtherColumn?: string | undefined;
    count?: string | undefined;
    max?: string | undefined;
    maxOtherColumn?: string | undefined;
    min?: string | undefined;
    minOtherColumn?: string | undefined;
    sum?: string | undefined;
    sumOtherColumn?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITextsProps = React.PropsWithChildren<{
    addRow?: string;
    cancelAllChanges?: string;
    cancelRowChanges?: string;
    confirmDeleteMessage?: string;
    confirmDeleteTitle?: string;
    deleteRow?: string;
    editRow?: string;
    saveAllChanges?: string;
    saveRowChanges?: string;
    undeleteRow?: string;
    validationCancelChanges?: string;
    exportAll?: string;
    exportSelectedRows?: string;
    exportTo?: string;
    groupByThisColumn?: string;
    groupContinuedMessage?: string;
    groupContinuesMessage?: string;
    ungroup?: string;
    ungroupAll?: string;
    avg?: string;
    avgOtherColumn?: string;
    count?: string;
    max?: string;
    maxOtherColumn?: string;
    min?: string;
    minOtherColumn?: string;
    sum?: string;
    sumOtherColumn?: string;
    fix?: string;
    leftPosition?: string;
    rightPosition?: string;
    stickyPosition?: string;
    unfix?: string;
    clearFilter?: string;
    createFilter?: string;
    filterEnabledHint?: string;
    cancel?: string;
    emptyValue?: string;
    ok?: string;
}>;
declare const Texts: ((props: ITextsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    addRow?: string | undefined;
    cancelAllChanges?: string | undefined;
    cancelRowChanges?: string | undefined;
    confirmDeleteMessage?: string | undefined;
    confirmDeleteTitle?: string | undefined;
    deleteRow?: string | undefined;
    editRow?: string | undefined;
    saveAllChanges?: string | undefined;
    saveRowChanges?: string | undefined;
    undeleteRow?: string | undefined;
    validationCancelChanges?: string | undefined;
    exportAll?: string | undefined;
    exportSelectedRows?: string | undefined;
    exportTo?: string | undefined;
    groupByThisColumn?: string | undefined;
    groupContinuedMessage?: string | undefined;
    groupContinuesMessage?: string | undefined;
    ungroup?: string | undefined;
    ungroupAll?: string | undefined;
    avg?: string | undefined;
    avgOtherColumn?: string | undefined;
    count?: string | undefined;
    max?: string | undefined;
    maxOtherColumn?: string | undefined;
    min?: string | undefined;
    minOtherColumn?: string | undefined;
    sum?: string | undefined;
    sumOtherColumn?: string | undefined;
    fix?: string | undefined;
    leftPosition?: string | undefined;
    rightPosition?: string | undefined;
    stickyPosition?: string | undefined;
    unfix?: string | undefined;
    clearFilter?: string | undefined;
    createFilter?: string | undefined;
    filterEnabledHint?: string | undefined;
    cancel?: string | undefined;
    emptyValue?: string | undefined;
    ok?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToProps = React.PropsWithChildren<{
    left?: number;
    opacity?: number;
    position?: PositionConfig;
    scale?: number;
    top?: number;
}>;
declare const To: ((props: IToProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    left?: number | undefined;
    opacity?: number | undefined;
    position?: PositionConfig | undefined;
    scale?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToolbarProps = React.PropsWithChildren<{
    disabled?: boolean;
    items?: Array<DataGridPredefinedToolbarItem | dxDataGridToolbarItem>;
    visible?: boolean | undefined;
}>;
declare const Toolbar: ((props: IToolbarProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    disabled?: boolean | undefined;
    items?: (DataGridPredefinedToolbarItem | DataGridTypes.ToolbarItem)[] | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IToolbarItemProps = React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean;
    html?: string;
    locateInMenu?: LocateInMenuMode;
    location?: ToolbarItemLocation;
    menuItemTemplate?: (() => string | any) | template;
    options?: any;
    showText?: ShowTextMode;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    toolbar?: ToolbarLocation;
    visible?: boolean;
    widget?: ToolbarItemComponent;
    menuItemRender?: (...params: any) => React.ReactNode;
    menuItemComponent?: React.ComponentType<any>;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const ToolbarItem: ((props: IToolbarItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    cssClass?: string | undefined;
    disabled?: boolean | undefined;
    html?: string | undefined;
    locateInMenu?: LocateInMenuMode | undefined;
    location?: ToolbarItemLocation | undefined;
    menuItemTemplate?: template | (() => string | any) | undefined;
    options?: any;
    showText?: ShowTextMode | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    toolbar?: ToolbarLocation | undefined;
    visible?: boolean | undefined;
    widget?: ToolbarItemComponent | undefined;
    menuItemRender?: ((...params: any) => React.ReactNode) | undefined;
    menuItemComponent?: React.ComponentType<any> | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITotalItemProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    column?: string | undefined;
    cssClass?: string | undefined;
    customizeText?: ((itemInfo: {
        value: string | number | Date;
        valueText: string;
    }) => string);
    displayFormat?: string | undefined;
    name?: string | undefined;
    showInColumn?: string | undefined;
    skipEmptyValues?: boolean;
    summaryType?: string | SummaryType | undefined;
    valueFormat?: LocalizationFormat | undefined;
}>;
declare const TotalItem: ((props: ITotalItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    column?: string | undefined;
    cssClass?: string | undefined;
    customizeText?: ((itemInfo: {
        value: string | number | Date;
        valueText: string;
    }) => string) | undefined;
    displayFormat?: string | undefined;
    name?: string | undefined;
    showInColumn?: string | undefined;
    skipEmptyValues?: boolean | undefined;
    summaryType?: string | SummaryType | undefined;
    valueFormat?: LocalizationFormat | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IValidationRuleProps = React.PropsWithChildren<{
    message?: string;
    trim?: boolean;
    type?: ValidationRuleType;
    ignoreEmptyValue?: boolean;
    max?: Date | number | string;
    min?: Date | number | string;
    reevaluate?: boolean;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: string | number;
    }) => boolean);
    comparisonTarget?: (() => any);
    comparisonType?: ComparisonOperator;
    pattern?: RegExp | string;
}>;
declare const ValidationRule: ((props: IValidationRuleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    message?: string | undefined;
    trim?: boolean | undefined;
    type?: ValidationRuleType | undefined;
    ignoreEmptyValue?: boolean | undefined;
    max?: string | number | Date | undefined;
    min?: string | number | Date | undefined;
    reevaluate?: boolean | undefined;
    validationCallback?: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: string | number;
    }) => boolean) | undefined;
    comparisonTarget?: (() => any) | undefined;
    comparisonType?: ComparisonOperator | undefined;
    pattern?: string | RegExp | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IValueFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const ValueFormat: ((props: IValueFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default DataGrid;
export { DataGrid, IDataGridOptions, DataGridRef, Animation, IAnimationProps, AsyncRule, IAsyncRuleProps, At, IAtProps, BoundaryOffset, IBoundaryOffsetProps, Button, IButtonProps, Change, IChangeProps, ColCountByScreen, IColCountByScreenProps, Collision, ICollisionProps, Column, IColumnProps, ColumnChooser, IColumnChooserProps, ColumnChooserSearch, IColumnChooserSearchProps, ColumnChooserSelection, IColumnChooserSelectionProps, ColumnFixing, IColumnFixingProps, ColumnFixingTexts, IColumnFixingTextsProps, ColumnHeaderFilter, IColumnHeaderFilterProps, ColumnHeaderFilterSearch, IColumnHeaderFilterSearchProps, ColumnLookup, IColumnLookupProps, CompareRule, ICompareRuleProps, CursorOffset, ICursorOffsetProps, CustomOperation, ICustomOperationProps, CustomRule, ICustomRuleProps, DataGridHeaderFilter, IDataGridHeaderFilterProps, DataGridHeaderFilterSearch, IDataGridHeaderFilterSearchProps, DataGridHeaderFilterTexts, IDataGridHeaderFilterTextsProps, DataGridSelection, IDataGridSelectionProps, Editing, IEditingProps, EditingTexts, IEditingTextsProps, EmailRule, IEmailRuleProps, Export, IExportProps, ExportTexts, IExportTextsProps, Field, IFieldProps, FieldLookup, IFieldLookupProps, FilterBuilder, IFilterBuilderProps, FilterBuilderPopup, IFilterBuilderPopupProps, FilterOperationDescriptions, IFilterOperationDescriptionsProps, FilterPanel, IFilterPanelProps, FilterPanelTexts, IFilterPanelTextsProps, FilterRow, IFilterRowProps, Form, IFormProps, Format, IFormatProps, FormItem, IFormItemProps, From, IFromProps, Grouping, IGroupingProps, GroupingTexts, IGroupingTextsProps, GroupItem, IGroupItemProps, GroupOperationDescriptions, IGroupOperationDescriptionsProps, GroupPanel, IGroupPanelProps, HeaderFilter, IHeaderFilterProps, Hide, IHideProps, Icons, IIconsProps, Item, IItemProps, KeyboardNavigation, IKeyboardNavigationProps, Label, ILabelProps, LoadPanel, ILoadPanelProps, Lookup, ILookupProps, MasterDetail, IMasterDetailProps, My, IMyProps, NumericRule, INumericRuleProps, Offset, IOffsetProps, OperationDescriptions, IOperationDescriptionsProps, Pager, IPagerProps, Paging, IPagingProps, PatternRule, IPatternRuleProps, Popup, IPopupProps, Position, IPositionProps, RangeRule, IRangeRuleProps, RemoteOperations, IRemoteOperationsProps, RequiredRule, IRequiredRuleProps, RowDragging, IRowDraggingProps, Scrolling, IScrollingProps, Search, ISearchProps, SearchPanel, ISearchPanelProps, Selection, ISelectionProps, Show, IShowProps, SortByGroupSummaryInfo, ISortByGroupSummaryInfoProps, Sorting, ISortingProps, StateStoring, IStateStoringProps, StringLengthRule, IStringLengthRuleProps, Summary, ISummaryProps, SummaryTexts, ISummaryTextsProps, Texts, ITextsProps, To, IToProps, Toolbar, IToolbarProps, ToolbarItem, IToolbarItemProps, TotalItem, ITotalItemProps, ValidationRule, IValidationRuleProps, ValueFormat, IValueFormatProps };
import type * as DataGridTypes from 'devextreme/ui/data_grid_types';
export { DataGridTypes };
