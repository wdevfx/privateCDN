/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxPieChart, { Properties } from "devextreme/viz/pie_chart";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { DisposingEvent, DoneEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, LegendClickEvent, PointClickEvent, TooltipHiddenEvent, TooltipShownEvent, dxPieChartAnnotationConfig, PieChartAnnotationLocation, dxPieChartCommonAnnotationConfig, PieChartSeriesInteractionMode, SmallValuesGroupingMode, PieChartLegendItem, PieChartLegendHoverMode, PieChartSeries } from "devextreme/viz/pie_chart";
import type { AnimationEaseMode, DashStyle, Font as ChartsFont, TextOverflow, AnnotationType, WordWrap, ChartsDataType, ChartsColor, HatchDirection, LabelPosition } from "devextreme/common/charts";
import type { template, Format as CommonFormat, ExportFormat, HorizontalAlignment, Position, Orientation, VerticalEdge } from "devextreme/common";
import type { Format as LocalizationFormat } from "devextreme/common/core/localization";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IPieChartOptionsNarrowedEvents = {
    onDisposing?: ((e: DisposingEvent) => void);
    onDone?: ((e: DoneEvent) => void);
    onDrawn?: ((e: DrawnEvent) => void);
    onExported?: ((e: ExportedEvent) => void);
    onExporting?: ((e: ExportingEvent) => void);
    onFileSaving?: ((e: FileSavingEvent) => void);
    onIncidentOccurred?: ((e: IncidentOccurredEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onLegendClick?: ((e: LegendClickEvent) => void);
    onPointClick?: ((e: PointClickEvent) => void);
    onTooltipHidden?: ((e: TooltipHiddenEvent) => void);
    onTooltipShown?: ((e: TooltipShownEvent) => void);
};
type IPieChartOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IPieChartOptionsNarrowedEvents> & IHtmlOptions & {
    centerRender?: (...params: any) => React.ReactNode;
    centerComponent?: React.ComponentType<any>;
    defaultLoadingIndicator?: Record<string, any>;
    onLoadingIndicatorChange?: (value: Record<string, any>) => void;
}>;
interface PieChartRef {
    instance: () => dxPieChart;
}
declare const PieChart: (props: React.PropsWithChildren<IPieChartOptions> & {
    ref?: Ref<PieChartRef>;
}) => ReactElement | null;
type IAdaptiveLayoutProps = React.PropsWithChildren<{
    height?: number;
    keepLabels?: boolean;
    width?: number;
}>;
declare const AdaptiveLayout: ((props: IAdaptiveLayoutProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    keepLabels?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAnimationProps = React.PropsWithChildren<{
    duration?: number;
    easing?: AnimationEaseMode;
    enabled?: boolean;
    maxPointCountSupported?: number;
}>;
declare const Animation: ((props: IAnimationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    duration?: number | undefined;
    easing?: AnimationEaseMode | undefined;
    enabled?: boolean | undefined;
    maxPointCountSupported?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAnnotationProps = React.PropsWithChildren<{
    allowDragging?: boolean;
    argument?: Date | number | string | undefined;
    arrowLength?: number;
    arrowWidth?: number;
    border?: Record<string, any> | {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: string;
    customizeTooltip?: ((annotation: dxPieChartAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont;
    height?: number | undefined;
    image?: Record<string, any> | string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    location?: PieChartAnnotationLocation;
    name?: string | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    series?: string | undefined;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    template?: ((annotation: dxPieChartCommonAnnotationConfig | any, element: any) => string | any) | template | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow;
    tooltipEnabled?: boolean;
    tooltipTemplate?: ((annotation: dxPieChartAnnotationConfig | any, element: any) => string | any) | template | undefined;
    type?: AnnotationType | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap;
    x?: number | undefined;
    y?: number | undefined;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
    tooltipRender?: (...params: any) => React.ReactNode;
    tooltipComponent?: React.ComponentType<any>;
}>;
declare const Annotation: ((props: IAnnotationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowDragging?: boolean | undefined;
    argument?: Date | number | string | undefined;
    arrowLength?: number | undefined;
    arrowWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        cornerRadius?: number | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    customizeTooltip?: ((annotation: dxPieChartAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont | undefined;
    height?: number | undefined;
    image?: string | Record<string, any> | {
        height?: number | undefined;
        url?: string | undefined;
        width?: number | undefined;
    } | undefined;
    location?: PieChartAnnotationLocation | undefined;
    name?: string | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    series?: string | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    template?: template | ((annotation: dxPieChartCommonAnnotationConfig | any, element: any) => string | any) | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    tooltipEnabled?: boolean | undefined;
    tooltipTemplate?: template | ((annotation: dxPieChartAnnotationConfig | any, element: any) => string | any) | undefined;
    type?: AnnotationType | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap | undefined;
    x?: number | undefined;
    y?: number | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
    tooltipRender?: ((...params: any) => React.ReactNode) | undefined;
    tooltipComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAnnotationBorderProps = React.PropsWithChildren<{
    color?: string;
    cornerRadius?: number;
    dashStyle?: DashStyle;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const AnnotationBorder: ((props: IAnnotationBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    cornerRadius?: number | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IArgumentFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const ArgumentFormat: ((props: IArgumentFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBorderProps = React.PropsWithChildren<{
    color?: string | undefined;
    cornerRadius?: number;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const Border: ((props: IBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    cornerRadius?: number | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColorProps = React.PropsWithChildren<{
    base?: string | undefined;
    fillId?: string | undefined;
}>;
declare const Color: ((props: IColorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    base?: string | undefined;
    fillId?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonAnnotationSettingsProps = React.PropsWithChildren<{
    allowDragging?: boolean;
    argument?: Date | number | string | undefined;
    arrowLength?: number;
    arrowWidth?: number;
    border?: Record<string, any> | {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: string;
    customizeTooltip?: ((annotation: dxPieChartAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont;
    height?: number | undefined;
    image?: Record<string, any> | string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    location?: PieChartAnnotationLocation;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    series?: string | undefined;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    template?: ((annotation: dxPieChartCommonAnnotationConfig | any, element: any) => string | any) | template | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow;
    tooltipEnabled?: boolean;
    tooltipTemplate?: ((annotation: dxPieChartAnnotationConfig | any, element: any) => string | any) | template | undefined;
    type?: AnnotationType | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap;
    x?: number | undefined;
    y?: number | undefined;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
    tooltipRender?: (...params: any) => React.ReactNode;
    tooltipComponent?: React.ComponentType<any>;
}>;
declare const CommonAnnotationSettings: ((props: ICommonAnnotationSettingsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowDragging?: boolean | undefined;
    argument?: Date | number | string | undefined;
    arrowLength?: number | undefined;
    arrowWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        cornerRadius?: number | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    customizeTooltip?: ((annotation: dxPieChartAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont | undefined;
    height?: number | undefined;
    image?: string | Record<string, any> | {
        height?: number | undefined;
        url?: string | undefined;
        width?: number | undefined;
    } | undefined;
    location?: PieChartAnnotationLocation | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    series?: string | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    template?: template | ((annotation: dxPieChartCommonAnnotationConfig | any, element: any) => string | any) | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    tooltipEnabled?: boolean | undefined;
    tooltipTemplate?: template | ((annotation: dxPieChartAnnotationConfig | any, element: any) => string | any) | undefined;
    type?: AnnotationType | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap | undefined;
    x?: number | undefined;
    y?: number | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
    tooltipRender?: ((...params: any) => React.ReactNode) | undefined;
    tooltipComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonSeriesSettingsProps = React.PropsWithChildren<{
    argumentField?: string;
    argumentType?: ChartsDataType | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    hoverMode?: PieChartSeriesInteractionMode;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    };
    label?: Record<string, any> | {
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        position?: LabelPosition;
        radialOffset?: number;
        rotationAngle?: number;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    };
    maxLabelCount?: number | undefined;
    minSegmentSize?: number | undefined;
    selectionMode?: PieChartSeriesInteractionMode;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    };
    smallValuesGrouping?: Record<string, any> | {
        groupName?: string;
        mode?: SmallValuesGroupingMode;
        threshold?: number | undefined;
        topCount?: number | undefined;
    };
    tagField?: string;
    valueField?: string;
}>;
declare const CommonSeriesSettings: ((props: ICommonSeriesSettingsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    argumentField?: string | undefined;
    argumentType?: ChartsDataType | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    hoverMode?: PieChartSeriesInteractionMode | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
    } | undefined;
    label?: Record<string, any> | {
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        customizeText?: ((pointInfo: any) => string) | undefined;
        displayFormat?: string | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        position?: LabelPosition | undefined;
        radialOffset?: number | undefined;
        rotationAngle?: number | undefined;
        textOverflow?: TextOverflow | undefined;
        visible?: boolean | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    maxLabelCount?: number | undefined;
    minSegmentSize?: number | undefined;
    selectionMode?: PieChartSeriesInteractionMode | undefined;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
    } | undefined;
    smallValuesGrouping?: Record<string, any> | {
        groupName?: string | undefined;
        mode?: SmallValuesGroupingMode | undefined;
        threshold?: number | undefined;
        topCount?: number | undefined;
    } | undefined;
    tagField?: string | undefined;
    valueField?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IConnectorProps = React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const Connector: ((props: IConnectorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IExportProps = React.PropsWithChildren<{
    backgroundColor?: string;
    enabled?: boolean;
    fileName?: string;
    formats?: Array<ExportFormat>;
    margin?: number;
    printingEnabled?: boolean;
    svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
}>;
declare const Export: ((props: IExportProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    enabled?: boolean | undefined;
    fileName?: string | undefined;
    formats?: ExportFormat[] | undefined;
    margin?: number | undefined;
    printingEnabled?: boolean | undefined;
    svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFontProps = React.PropsWithChildren<{
    color?: string;
    family?: string;
    opacity?: number;
    size?: number | string;
    weight?: number;
}>;
declare const Font: ((props: IFontProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    family?: string | undefined;
    opacity?: number | undefined;
    size?: string | number | undefined;
    weight?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const Format: ((props: IFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHatchingProps = React.PropsWithChildren<{
    direction?: HatchDirection;
    opacity?: number;
    step?: number;
    width?: number;
}>;
declare const Hatching: ((props: IHatchingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    direction?: HatchDirection | undefined;
    opacity?: number | undefined;
    step?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHoverStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    highlight?: boolean;
}>;
declare const HoverStyle: ((props: IHoverStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection | undefined;
        opacity?: number | undefined;
        step?: number | undefined;
        width?: number | undefined;
    } | undefined;
    highlight?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IImageProps = React.PropsWithChildren<{
    height?: number;
    url?: string | undefined;
    width?: number;
}>;
declare const Image: ((props: IImageProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    url?: string | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILabelProps = React.PropsWithChildren<{
    argumentFormat?: LocalizationFormat | undefined;
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    connector?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    customizeText?: ((pointInfo: any) => string);
    displayFormat?: string | undefined;
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    position?: LabelPosition;
    radialOffset?: number;
    rotationAngle?: number;
    textOverflow?: TextOverflow;
    visible?: boolean;
    wordWrap?: WordWrap;
}>;
declare const Label: ((props: ILabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    argumentFormat?: LocalizationFormat | undefined;
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    connector?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    customizeText?: ((pointInfo: any) => string) | undefined;
    displayFormat?: string | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    position?: LabelPosition | undefined;
    radialOffset?: number | undefined;
    rotationAngle?: number | undefined;
    textOverflow?: TextOverflow | undefined;
    visible?: boolean | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILegendProps = React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    columnCount?: number;
    columnItemSpacing?: number;
    customizeHint?: ((pointInfo: {
        pointColor: string;
        pointIndex: number;
        pointName: any;
    }) => string);
    customizeItems?: ((items: Array<PieChartLegendItem>) => Array<PieChartLegendItem>);
    customizeText?: ((pointInfo: {
        pointColor: string;
        pointIndex: number;
        pointName: any;
    }) => string);
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    hoverMode?: PieChartLegendHoverMode;
    itemsAlignment?: HorizontalAlignment | undefined;
    itemTextPosition?: Position | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    markerSize?: number;
    markerTemplate?: ((legendItem: PieChartLegendItem, element: any) => string | any) | template | undefined;
    orientation?: Orientation | undefined;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    rowCount?: number;
    rowItemSpacing?: number;
    title?: Record<string, any> | string | {
        font?: ChartsFont;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: Record<string, any> | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: Record<string, any> | string | {
            font?: ChartsFont;
            offset?: number;
            text?: string;
        };
        text?: string;
        verticalAlignment?: VerticalEdge;
    };
    verticalAlignment?: VerticalEdge;
    visible?: boolean;
    markerRender?: (...params: any) => React.ReactNode;
    markerComponent?: React.ComponentType<any>;
}>;
declare const Legend: ((props: ILegendProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        cornerRadius?: number | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    columnCount?: number | undefined;
    columnItemSpacing?: number | undefined;
    customizeHint?: ((pointInfo: {
        pointColor: string;
        pointIndex: number;
        pointName: any;
    }) => string) | undefined;
    customizeItems?: ((items: Array<PieChartLegendItem>) => Array<PieChartLegendItem>) | undefined;
    customizeText?: ((pointInfo: {
        pointColor: string;
        pointIndex: number;
        pointName: any;
    }) => string) | undefined;
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    hoverMode?: PieChartLegendHoverMode | undefined;
    itemsAlignment?: HorizontalAlignment | undefined;
    itemTextPosition?: Position | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    markerSize?: number | undefined;
    markerTemplate?: template | ((legendItem: PieChartLegendItem, element: any) => string | any) | undefined;
    orientation?: Orientation | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    rowCount?: number | undefined;
    rowItemSpacing?: number | undefined;
    title?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: Record<string, any> | {
            bottom?: number | undefined;
            left?: number | undefined;
            right?: number | undefined;
            top?: number | undefined;
        } | undefined;
        placeholderSize?: number | undefined;
        subtitle?: string | Record<string, any> | {
            font?: ChartsFont | undefined;
            offset?: number | undefined;
            text?: string | undefined;
        } | undefined;
        text?: string | undefined;
        verticalAlignment?: VerticalEdge | undefined;
    } | undefined;
    verticalAlignment?: VerticalEdge | undefined;
    visible?: boolean | undefined;
    markerRender?: ((...params: any) => React.ReactNode) | undefined;
    markerComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILegendTitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    placeholderSize?: number | undefined;
    subtitle?: Record<string, any> | string | {
        font?: ChartsFont;
        offset?: number;
        text?: string;
    };
    text?: string;
    verticalAlignment?: VerticalEdge;
}>;
declare const LegendTitle: ((props: ILegendTitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    placeholderSize?: number | undefined;
    subtitle?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        offset?: number | undefined;
        text?: string | undefined;
    } | undefined;
    text?: string | undefined;
    verticalAlignment?: VerticalEdge | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILegendTitleSubtitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    offset?: number;
    text?: string;
}>;
declare const LegendTitleSubtitle: ((props: ILegendTitleSubtitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    offset?: number | undefined;
    text?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILoadingIndicatorProps = React.PropsWithChildren<{
    backgroundColor?: string;
    enabled?: boolean;
    font?: ChartsFont;
    show?: boolean;
    text?: string;
    defaultShow?: boolean;
    onShowChange?: (value: boolean) => void;
}>;
declare const LoadingIndicator: ((props: ILoadingIndicatorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    enabled?: boolean | undefined;
    font?: ChartsFont | undefined;
    show?: boolean | undefined;
    text?: string | undefined;
    defaultShow?: boolean | undefined;
    onShowChange?: ((value: boolean) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMarginProps = React.PropsWithChildren<{
    bottom?: number;
    left?: number;
    right?: number;
    top?: number;
}>;
declare const Margin: ((props: IMarginProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    bottom?: number | undefined;
    left?: number | undefined;
    right?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPieChartTitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    margin?: number | Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    placeholderSize?: number | undefined;
    subtitle?: Record<string, any> | string | {
        font?: ChartsFont;
        offset?: number;
        text?: string;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    text?: string;
    textOverflow?: TextOverflow;
    verticalAlignment?: VerticalEdge;
    wordWrap?: WordWrap;
}>;
declare const PieChartTitle: ((props: IPieChartTitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    placeholderSize?: number | undefined;
    subtitle?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        offset?: number | undefined;
        text?: string | undefined;
        textOverflow?: TextOverflow | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    verticalAlignment?: VerticalEdge | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPieChartTitleSubtitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    offset?: number;
    text?: string;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const PieChartTitleSubtitle: ((props: IPieChartTitleSubtitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    offset?: number | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISelectionStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    highlight?: boolean;
}>;
declare const SelectionStyle: ((props: ISelectionStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection | undefined;
        opacity?: number | undefined;
        step?: number | undefined;
        width?: number | undefined;
    } | undefined;
    highlight?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISeriesProps = React.PropsWithChildren<{
    argumentField?: string;
    argumentType?: ChartsDataType | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    hoverMode?: PieChartSeriesInteractionMode;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    };
    label?: Record<string, any> | {
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        position?: LabelPosition;
        radialOffset?: number;
        rotationAngle?: number;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    };
    maxLabelCount?: number | undefined;
    minSegmentSize?: number | undefined;
    name?: string | undefined;
    selectionMode?: PieChartSeriesInteractionMode;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    };
    smallValuesGrouping?: Record<string, any> | {
        groupName?: string;
        mode?: SmallValuesGroupingMode;
        threshold?: number | undefined;
        topCount?: number | undefined;
    };
    tag?: any | undefined;
    tagField?: string;
    valueField?: string;
}>;
declare const Series: ((props: ISeriesProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    argumentField?: string | undefined;
    argumentType?: ChartsDataType | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    hoverMode?: PieChartSeriesInteractionMode | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
    } | undefined;
    label?: Record<string, any> | {
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        customizeText?: ((pointInfo: any) => string) | undefined;
        displayFormat?: string | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        position?: LabelPosition | undefined;
        radialOffset?: number | undefined;
        rotationAngle?: number | undefined;
        textOverflow?: TextOverflow | undefined;
        visible?: boolean | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    maxLabelCount?: number | undefined;
    minSegmentSize?: number | undefined;
    name?: string | undefined;
    selectionMode?: PieChartSeriesInteractionMode | undefined;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
    } | undefined;
    smallValuesGrouping?: Record<string, any> | {
        groupName?: string | undefined;
        mode?: SmallValuesGroupingMode | undefined;
        threshold?: number | undefined;
        topCount?: number | undefined;
    } | undefined;
    tag?: any | undefined;
    tagField?: string | undefined;
    valueField?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISeriesBorderProps = React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const SeriesBorder: ((props: ISeriesBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISeriesTemplateProps = React.PropsWithChildren<{
    customizeSeries?: ((seriesName: any) => PieChartSeries);
    nameField?: string;
}>;
declare const SeriesTemplate: ((props: ISeriesTemplateProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    customizeSeries?: ((seriesName: any) => PieChartSeries) | undefined;
    nameField?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShadowProps = React.PropsWithChildren<{
    blur?: number;
    color?: string;
    offsetX?: number;
    offsetY?: number;
    opacity?: number;
}>;
declare const Shadow: ((props: IShadowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    blur?: number | undefined;
    color?: string | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISizeProps = React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
}>;
declare const Size: ((props: ISizeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISmallValuesGroupingProps = React.PropsWithChildren<{
    groupName?: string;
    mode?: SmallValuesGroupingMode;
    threshold?: number | undefined;
    topCount?: number | undefined;
}>;
declare const SmallValuesGrouping: ((props: ISmallValuesGroupingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    groupName?: string | undefined;
    mode?: SmallValuesGroupingMode | undefined;
    threshold?: number | undefined;
    topCount?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISubtitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    offset?: number;
    text?: string;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const Subtitle: ((props: ISubtitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    offset?: number | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: Record<string, any> | number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    placeholderSize?: number | undefined;
    subtitle?: Record<string, any> | string | {
        font?: ChartsFont;
        offset?: number;
        text?: string;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    text?: string;
    verticalAlignment?: VerticalEdge;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const Title: ((props: ITitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    placeholderSize?: number | undefined;
    subtitle?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        offset?: number | undefined;
        text?: string | undefined;
        textOverflow?: TextOverflow | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    text?: string | undefined;
    verticalAlignment?: VerticalEdge | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITooltipProps = React.PropsWithChildren<{
    argumentFormat?: LocalizationFormat | undefined;
    arrowLength?: number;
    border?: Record<string, any> | {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: string;
    container?: any | string | undefined;
    contentTemplate?: ((pointInfo: any, element: any) => string | any) | template | undefined;
    cornerRadius?: number;
    customizeTooltip?: ((pointInfo: any) => Record<string, any>) | undefined;
    enabled?: boolean;
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    interactive?: boolean;
    opacity?: number | undefined;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    shared?: boolean;
    zIndex?: number | undefined;
    contentRender?: (...params: any) => React.ReactNode;
    contentComponent?: React.ComponentType<any>;
}>;
declare const Tooltip: ((props: ITooltipProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    argumentFormat?: LocalizationFormat | undefined;
    arrowLength?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    container?: any | string | undefined;
    contentTemplate?: template | ((pointInfo: any, element: any) => string | any) | undefined;
    cornerRadius?: number | undefined;
    customizeTooltip?: ((pointInfo: any) => Record<string, any>) | undefined;
    enabled?: boolean | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    interactive?: boolean | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    shared?: boolean | undefined;
    zIndex?: number | undefined;
    contentRender?: ((...params: any) => React.ReactNode) | undefined;
    contentComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITooltipBorderProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const TooltipBorder: ((props: ITooltipBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default PieChart;
export { PieChart, IPieChartOptions, PieChartRef, AdaptiveLayout, IAdaptiveLayoutProps, Animation, IAnimationProps, Annotation, IAnnotationProps, AnnotationBorder, IAnnotationBorderProps, ArgumentFormat, IArgumentFormatProps, Border, IBorderProps, Color, IColorProps, CommonAnnotationSettings, ICommonAnnotationSettingsProps, CommonSeriesSettings, ICommonSeriesSettingsProps, Connector, IConnectorProps, Export, IExportProps, Font, IFontProps, Format, IFormatProps, Hatching, IHatchingProps, HoverStyle, IHoverStyleProps, Image, IImageProps, Label, ILabelProps, Legend, ILegendProps, LegendTitle, ILegendTitleProps, LegendTitleSubtitle, ILegendTitleSubtitleProps, LoadingIndicator, ILoadingIndicatorProps, Margin, IMarginProps, PieChartTitle, IPieChartTitleProps, PieChartTitleSubtitle, IPieChartTitleSubtitleProps, SelectionStyle, ISelectionStyleProps, Series, ISeriesProps, SeriesBorder, ISeriesBorderProps, SeriesTemplate, ISeriesTemplateProps, Shadow, IShadowProps, Size, ISizeProps, SmallValuesGrouping, ISmallValuesGroupingProps, Subtitle, ISubtitleProps, Title, ITitleProps, Tooltip, ITooltipProps, TooltipBorder, ITooltipBorderProps };
import type * as PieChartTypes from 'devextreme/viz/pie_chart_types';
export { PieChartTypes };
