/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

export { ExplicitTypes } from "devextreme/ui/responsive_box";
import * as React from "react";
import { Ref, ReactElement } from "react";
import dxResponsiveBox, { Properties } from "devextreme/ui/responsive_box";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { dxResponsiveBoxItem, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent } from "devextreme/ui/responsive_box";
import type { CollectionWidgetItem } from "devextreme/ui/collection/ui.collection_widget.base";
import type { template } from "devextreme/common";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IResponsiveBoxOptionsNarrowedEvents<TItem = any, TKey = any> = {
    onContentReady?: ((e: ContentReadyEvent<TItem, TKey>) => void);
    onDisposing?: ((e: DisposingEvent<TItem, TKey>) => void);
    onInitialized?: ((e: InitializedEvent<TItem, TKey>) => void);
    onItemClick?: ((e: ItemClickEvent<TItem, TKey>) => void);
    onItemContextMenu?: ((e: ItemContextMenuEvent<TItem, TKey>) => void);
    onItemHold?: ((e: ItemHoldEvent<TItem, TKey>) => void);
    onItemRendered?: ((e: ItemRenderedEvent<TItem, TKey>) => void);
};
type IResponsiveBoxOptions<TItem = any, TKey = any> = React.PropsWithChildren<ReplaceFieldTypes<Properties<TItem, TKey>, IResponsiveBoxOptionsNarrowedEvents<TItem, TKey>> & IHtmlOptions & {
    dataSource?: Properties<TItem, TKey>["dataSource"];
    itemRender?: (...params: any) => React.ReactNode;
    itemComponent?: React.ComponentType<any>;
    defaultItems?: Array<any | dxResponsiveBoxItem | string>;
    onItemsChange?: (value: Array<any | dxResponsiveBoxItem | string>) => void;
}>;
interface ResponsiveBoxRef<TItem = any, TKey = any> {
    instance: () => dxResponsiveBox<TItem, TKey>;
}
declare const ResponsiveBox: <TItem = any, TKey = any>(props: ReplaceFieldTypes<Properties<TItem, TKey>, IResponsiveBoxOptionsNarrowedEvents<TItem, TKey>> & IHtmlOptions & {
    dataSource?: import("devextreme/data/data_source").DataSourceLike<TItem, TKey> | null | undefined;
    itemRender?: ((...params: any) => React.ReactNode) | undefined;
    itemComponent?: React.ComponentType<any> | undefined;
    defaultItems?: any[] | undefined;
    onItemsChange?: ((value: Array<any | dxResponsiveBoxItem | string>) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    ref?: React.Ref<ResponsiveBoxRef<TItem, TKey>> | undefined;
}) => ReactElement | null;
type IColProps = React.PropsWithChildren<{
    baseSize?: number | string;
    ratio?: number;
    screen?: string | undefined;
    shrink?: number;
}>;
declare const Col: ((props: IColProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    baseSize?: string | number | undefined;
    ratio?: number | undefined;
    screen?: string | undefined;
    shrink?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IItemProps = React.PropsWithChildren<{
    disabled?: boolean;
    html?: string;
    location?: Array<Record<string, any>> | Record<string, any> | {
        col?: number;
        colspan?: number | undefined;
        row?: number;
        rowspan?: number | undefined;
        screen?: string | undefined;
    }[];
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const Item: ((props: IItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    disabled?: boolean | undefined;
    html?: string | undefined;
    location?: Record<string, any> | Record<string, any>[] | {
        col?: number | undefined;
        colspan?: number | undefined;
        row?: number | undefined;
        rowspan?: number | undefined;
        screen?: string | undefined;
    }[] | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILocationProps = React.PropsWithChildren<{
    col?: number;
    colspan?: number | undefined;
    row?: number;
    rowspan?: number | undefined;
    screen?: string | undefined;
}>;
declare const Location: ((props: ILocationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    col?: number | undefined;
    colspan?: number | undefined;
    row?: number | undefined;
    rowspan?: number | undefined;
    screen?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IRowProps = React.PropsWithChildren<{
    baseSize?: number | string;
    ratio?: number;
    screen?: string | undefined;
    shrink?: number;
}>;
declare const Row: ((props: IRowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    baseSize?: string | number | undefined;
    ratio?: number | undefined;
    screen?: string | undefined;
    shrink?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default ResponsiveBox;
export { ResponsiveBox, IResponsiveBoxOptions, ResponsiveBoxRef, Col, IColProps, Item, IItemProps, Location, ILocationProps, Row, IRowProps };
import type * as ResponsiveBoxTypes from 'devextreme/ui/responsive_box_types';
export { ResponsiveBoxTypes };
