/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxChart, { Properties } from "devextreme/viz/chart";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { ArgumentAxisClickEvent, DisposingEvent, DoneEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, LegendClickEvent, PointClickEvent, SeriesClickEvent, TooltipHiddenEvent, TooltipShownEvent, ZoomEndEvent, ZoomStartEvent, chartPointAggregationInfoObject, chartSeriesObject, ChartSeriesAggregationMethod, dxChartAnnotationConfig, AggregatedPointsPosition, ChartLabelDisplayMode, FinancialChartReductionLevel, chartPointObject, ChartTooltipLocation, ChartZoomAndPanMode, EventKeyModifier } from "devextreme/viz/chart";
import type { AnimationEaseMode, DashStyle, Font as ChartsFont, TextOverflow, AnnotationType, WordWrap, TimeInterval, ChartsDataType, ScaleBreak, ScaleBreakLineStyle, RelativePosition, DiscreteAxisDivisionMode, ArgumentAxisHoverMode, ChartsAxisLabelOverlap, AxisScaleType, VisualRangeUpdateMode, ChartsColor, SeriesHoverMode, HatchDirection, PointInteractionMode, PointSymbol, SeriesSelectionMode, SeriesType, ValueErrorBarDisplayMode, ValueErrorBarType, LegendItem, LegendHoverMode } from "devextreme/common/charts";
import type { template, HorizontalAlignment, VerticalAlignment, Format as CommonFormat, Position, VerticalEdge, ExportFormat, Orientation } from "devextreme/common";
import type { Format as LocalizationFormat } from "devextreme/common/core/localization";
import type { ChartSeries } from "devextreme/viz/common";
import type * as CommonChartTypes from "devextreme/common/charts";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IChartOptionsNarrowedEvents = {
    onArgumentAxisClick?: ((e: ArgumentAxisClickEvent) => void);
    onDisposing?: ((e: DisposingEvent) => void);
    onDone?: ((e: DoneEvent) => void);
    onDrawn?: ((e: DrawnEvent) => void);
    onExported?: ((e: ExportedEvent) => void);
    onExporting?: ((e: ExportingEvent) => void);
    onFileSaving?: ((e: FileSavingEvent) => void);
    onIncidentOccurred?: ((e: IncidentOccurredEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onLegendClick?: ((e: LegendClickEvent) => void);
    onPointClick?: ((e: PointClickEvent) => void);
    onSeriesClick?: ((e: SeriesClickEvent) => void);
    onTooltipHidden?: ((e: TooltipHiddenEvent) => void);
    onTooltipShown?: ((e: TooltipShownEvent) => void);
    onZoomEnd?: ((e: ZoomEndEvent) => void);
    onZoomStart?: ((e: ZoomStartEvent) => void);
};
type IChartOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IChartOptionsNarrowedEvents> & IHtmlOptions & {
    defaultArgumentAxis?: Record<string, any>;
    defaultLoadingIndicator?: Record<string, any>;
    defaultValueAxis?: Array<Record<string, any>> | Record<string, any>;
    onArgumentAxisChange?: (value: Record<string, any>) => void;
    onLoadingIndicatorChange?: (value: Record<string, any>) => void;
    onValueAxisChange?: (value: Array<Record<string, any>> | Record<string, any>) => void;
}>;
interface ChartRef {
    instance: () => dxChart;
}
declare const Chart: (props: React.PropsWithChildren<IChartOptions> & {
    ref?: Ref<ChartRef>;
}) => ReactElement | null;
type IAdaptiveLayoutProps = React.PropsWithChildren<{
    height?: number;
    keepLabels?: boolean;
    width?: number;
}>;
declare const AdaptiveLayout: ((props: IAdaptiveLayoutProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    keepLabels?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAggregationProps = React.PropsWithChildren<{
    calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
    enabled?: boolean;
    method?: ChartSeriesAggregationMethod;
}>;
declare const Aggregation: ((props: IAggregationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
    enabled?: boolean | undefined;
    method?: ChartSeriesAggregationMethod | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAggregationIntervalProps = React.PropsWithChildren<{
    days?: number;
    hours?: number;
    milliseconds?: number;
    minutes?: number;
    months?: number;
    quarters?: number;
    seconds?: number;
    weeks?: number;
    years?: number;
}>;
declare const AggregationInterval: ((props: IAggregationIntervalProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    days?: number | undefined;
    hours?: number | undefined;
    milliseconds?: number | undefined;
    minutes?: number | undefined;
    months?: number | undefined;
    quarters?: number | undefined;
    seconds?: number | undefined;
    weeks?: number | undefined;
    years?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAnimationProps = React.PropsWithChildren<{
    duration?: number;
    easing?: AnimationEaseMode;
    enabled?: boolean;
    maxPointCountSupported?: number;
}>;
declare const Animation: ((props: IAnimationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    duration?: number | undefined;
    easing?: AnimationEaseMode | undefined;
    enabled?: boolean | undefined;
    maxPointCountSupported?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAnnotationProps = React.PropsWithChildren<{
    allowDragging?: boolean;
    argument?: Date | number | string | undefined;
    arrowLength?: number;
    arrowWidth?: number;
    axis?: string | undefined;
    border?: Record<string, any> | {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: string;
    customizeTooltip?: ((annotation: dxChartAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont;
    height?: number | undefined;
    image?: Record<string, any> | string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    name?: string | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    series?: string | undefined;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    template?: ((annotation: dxChartAnnotationConfig | any, element: any) => string | any) | template | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow;
    tooltipEnabled?: boolean;
    tooltipTemplate?: ((annotation: dxChartAnnotationConfig | any, element: any) => string | any) | template | undefined;
    type?: AnnotationType | undefined;
    value?: Date | number | string | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap;
    x?: number | undefined;
    y?: number | undefined;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
    tooltipRender?: (...params: any) => React.ReactNode;
    tooltipComponent?: React.ComponentType<any>;
}>;
declare const Annotation: ((props: IAnnotationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowDragging?: boolean | undefined;
    argument?: Date | number | string | undefined;
    arrowLength?: number | undefined;
    arrowWidth?: number | undefined;
    axis?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        cornerRadius?: number | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    customizeTooltip?: ((annotation: dxChartAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont | undefined;
    height?: number | undefined;
    image?: string | Record<string, any> | {
        height?: number | undefined;
        url?: string | undefined;
        width?: number | undefined;
    } | undefined;
    name?: string | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    series?: string | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    template?: template | ((annotation: dxChartAnnotationConfig | any, element: any) => string | any) | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    tooltipEnabled?: boolean | undefined;
    tooltipTemplate?: template | ((annotation: dxChartAnnotationConfig | any, element: any) => string | any) | undefined;
    type?: AnnotationType | undefined;
    value?: Date | number | string | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap | undefined;
    x?: number | undefined;
    y?: number | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
    tooltipRender?: ((...params: any) => React.ReactNode) | undefined;
    tooltipComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAnnotationBorderProps = React.PropsWithChildren<{
    color?: string;
    cornerRadius?: number;
    dashStyle?: DashStyle;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const AnnotationBorder: ((props: IAnnotationBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    cornerRadius?: number | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAnnotationImageProps = React.PropsWithChildren<{
    height?: number;
    url?: string | undefined;
    width?: number;
}>;
declare const AnnotationImage: ((props: IAnnotationImageProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    url?: string | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IArgumentAxisProps = React.PropsWithChildren<{
    aggregateByCategory?: boolean;
    aggregatedPointsPosition?: AggregatedPointsPosition;
    aggregationGroupWidth?: number | undefined;
    aggregationInterval?: number | Record<string, any> | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    allowDecimals?: boolean | undefined;
    argumentType?: ChartsDataType | undefined;
    axisDivisionFactor?: number;
    breaks?: Array<ScaleBreak> | {
        endValue?: Date | number | string | undefined;
        startValue?: Date | number | string | undefined;
    }[];
    breakStyle?: Record<string, any> | {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    };
    categories?: Array<Date | number | string>;
    color?: string;
    constantLines?: Array<Record<string, any>> | {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: Record<string, any> | {
            font?: ChartsFont;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        value?: Date | number | string | undefined;
        width?: number;
    }[];
    constantLineStyle?: Record<string, any> | {
        color?: string;
        dashStyle?: DashStyle;
        label?: Record<string, any> | {
            font?: ChartsFont;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        width?: number;
    };
    customPosition?: Date | number | string | undefined;
    customPositionAxis?: string | undefined;
    discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
    endOnTick?: boolean;
    grid?: Record<string, any> | {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    holidays?: Array<Date | string> | Array<number>;
    hoverMode?: ArgumentAxisHoverMode;
    inverted?: boolean;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        customizeHint?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        customizeText?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        displayMode?: ChartLabelDisplayMode;
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: ChartsAxisLabelOverlap;
        position?: Position | RelativePosition;
        rotationAngle?: number;
        staggeringSpacing?: number;
        template?: ((data: {
            value: Date | number | string;
            valueText: string;
        }, element: any) => string | any) | template | undefined;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    };
    linearThreshold?: number | undefined;
    logarithmBase?: number;
    maxValueMargin?: number | undefined;
    minorGrid?: Record<string, any> | {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    minorTick?: Record<string, any> | {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    minorTickCount?: number | undefined;
    minorTickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    minValueMargin?: number | undefined;
    minVisualRangeLength?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    offset?: number | undefined;
    opacity?: number | undefined;
    placeholderSize?: number;
    position?: Position;
    singleWorkdays?: Array<Date | string> | Array<number>;
    strips?: Array<Record<string, any>> | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont;
            horizontalAlignment?: HorizontalAlignment;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        startValue?: Date | number | string | undefined;
    }[];
    stripStyle?: Record<string, any> | {
        label?: Record<string, any> | {
            font?: ChartsFont;
            horizontalAlignment?: HorizontalAlignment;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
    };
    tick?: Record<string, any> | {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    tickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    title?: Record<string, any> | string | {
        alignment?: HorizontalAlignment;
        font?: ChartsFont;
        margin?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    type?: AxisScaleType | undefined;
    valueMarginsEnabled?: boolean;
    visible?: boolean;
    visualRange?: Array<Date | number | string> | CommonChartTypes.VisualRange;
    visualRangeUpdateMode?: VisualRangeUpdateMode;
    wholeRange?: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
    width?: number;
    workdaysOnly?: boolean;
    workWeek?: Array<number>;
    defaultCategories?: Array<Date | number | string>;
    onCategoriesChange?: (value: Array<Date | number | string>) => void;
    defaultVisualRange?: Array<Date | number | string> | CommonChartTypes.VisualRange;
    onVisualRangeChange?: (value: Array<Date | number | string> | CommonChartTypes.VisualRange) => void;
}>;
declare const ArgumentAxis: ((props: IArgumentAxisProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    aggregateByCategory?: boolean | undefined;
    aggregatedPointsPosition?: AggregatedPointsPosition | undefined;
    aggregationGroupWidth?: number | undefined;
    aggregationInterval?: number | Record<string, any> | TimeInterval | {
        days?: number | undefined;
        hours?: number | undefined;
        milliseconds?: number | undefined;
        minutes?: number | undefined;
        months?: number | undefined;
        quarters?: number | undefined;
        seconds?: number | undefined;
        weeks?: number | undefined;
        years?: number | undefined;
    } | undefined;
    allowDecimals?: boolean | undefined;
    argumentType?: ChartsDataType | undefined;
    axisDivisionFactor?: number | undefined;
    breaks?: ScaleBreak[] | {
        endValue?: Date | number | string | undefined;
        startValue?: Date | number | string | undefined;
    }[] | undefined;
    breakStyle?: Record<string, any> | {
        color?: string | undefined;
        line?: ScaleBreakLineStyle | undefined;
        width?: number | undefined;
    } | undefined;
    categories?: (string | number | Date)[] | undefined;
    color?: string | undefined;
    constantLines?: Record<string, any>[] | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        displayBehindSeries?: boolean | undefined;
        extendAxis?: boolean | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            horizontalAlignment?: HorizontalAlignment | undefined;
            position?: RelativePosition | undefined;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment | undefined;
            visible?: boolean | undefined;
        } | undefined;
        paddingLeftRight?: number | undefined;
        paddingTopBottom?: number | undefined;
        value?: Date | number | string | undefined;
        width?: number | undefined;
    }[] | undefined;
    constantLineStyle?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            horizontalAlignment?: HorizontalAlignment | undefined;
            position?: RelativePosition | undefined;
            verticalAlignment?: VerticalAlignment | undefined;
            visible?: boolean | undefined;
        } | undefined;
        paddingLeftRight?: number | undefined;
        paddingTopBottom?: number | undefined;
        width?: number | undefined;
    } | undefined;
    customPosition?: Date | number | string | undefined;
    customPositionAxis?: string | undefined;
    discreteAxisDivisionMode?: DiscreteAxisDivisionMode | undefined;
    endOnTick?: boolean | undefined;
    grid?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    holidays?: number[] | (string | Date)[] | undefined;
    hoverMode?: ArgumentAxisHoverMode | undefined;
    inverted?: boolean | undefined;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        customizeHint?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string) | undefined;
        customizeText?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string) | undefined;
        displayMode?: ChartLabelDisplayMode | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        indentFromAxis?: number | undefined;
        overlappingBehavior?: ChartsAxisLabelOverlap | undefined;
        position?: Position | RelativePosition | undefined;
        rotationAngle?: number | undefined;
        staggeringSpacing?: number | undefined;
        template?: template | ((data: {
            value: Date | number | string;
            valueText: string;
        }, element: any) => string | any) | undefined;
        textOverflow?: TextOverflow | undefined;
        visible?: boolean | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    linearThreshold?: number | undefined;
    logarithmBase?: number | undefined;
    maxValueMargin?: number | undefined;
    minorGrid?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    minorTick?: Record<string, any> | {
        color?: string | undefined;
        length?: number | undefined;
        opacity?: number | undefined;
        shift?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    minorTickCount?: number | undefined;
    minorTickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number | undefined;
        hours?: number | undefined;
        milliseconds?: number | undefined;
        minutes?: number | undefined;
        months?: number | undefined;
        quarters?: number | undefined;
        seconds?: number | undefined;
        weeks?: number | undefined;
        years?: number | undefined;
    } | undefined;
    minValueMargin?: number | undefined;
    minVisualRangeLength?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    offset?: number | undefined;
    opacity?: number | undefined;
    placeholderSize?: number | undefined;
    position?: Position | undefined;
    singleWorkdays?: number[] | (string | Date)[] | undefined;
    strips?: Record<string, any>[] | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            horizontalAlignment?: HorizontalAlignment | undefined;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment | undefined;
        } | undefined;
        paddingLeftRight?: number | undefined;
        paddingTopBottom?: number | undefined;
        startValue?: Date | number | string | undefined;
    }[] | undefined;
    stripStyle?: Record<string, any> | {
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            horizontalAlignment?: HorizontalAlignment | undefined;
            verticalAlignment?: VerticalAlignment | undefined;
        } | undefined;
        paddingLeftRight?: number | undefined;
        paddingTopBottom?: number | undefined;
    } | undefined;
    tick?: Record<string, any> | {
        color?: string | undefined;
        length?: number | undefined;
        opacity?: number | undefined;
        shift?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    tickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number | undefined;
        hours?: number | undefined;
        milliseconds?: number | undefined;
        minutes?: number | undefined;
        months?: number | undefined;
        quarters?: number | undefined;
        seconds?: number | undefined;
        weeks?: number | undefined;
        years?: number | undefined;
    } | undefined;
    title?: string | Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        font?: ChartsFont | undefined;
        margin?: number | undefined;
        text?: string | undefined;
        textOverflow?: TextOverflow | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    type?: AxisScaleType | undefined;
    valueMarginsEnabled?: boolean | undefined;
    visible?: boolean | undefined;
    visualRange?: (string | number | Date)[] | CommonChartTypes.VisualRange | undefined;
    visualRangeUpdateMode?: VisualRangeUpdateMode | undefined;
    wholeRange?: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
    width?: number | undefined;
    workdaysOnly?: boolean | undefined;
    workWeek?: number[] | undefined;
    defaultCategories?: (string | number | Date)[] | undefined;
    onCategoriesChange?: ((value: Array<Date | number | string>) => void) | undefined;
    defaultVisualRange?: (string | number | Date)[] | CommonChartTypes.VisualRange | undefined;
    onVisualRangeChange?: ((value: Array<Date | number | string> | CommonChartTypes.VisualRange) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IArgumentFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const ArgumentFormat: ((props: IArgumentFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAxisConstantLineStyleProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    label?: Record<string, any> | {
        font?: ChartsFont;
        horizontalAlignment?: HorizontalAlignment;
        position?: RelativePosition;
        verticalAlignment?: VerticalAlignment;
        visible?: boolean;
    };
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    width?: number;
}>;
declare const AxisConstantLineStyle: ((props: IAxisConstantLineStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    label?: Record<string, any> | {
        font?: ChartsFont | undefined;
        horizontalAlignment?: HorizontalAlignment | undefined;
        position?: RelativePosition | undefined;
        verticalAlignment?: VerticalAlignment | undefined;
        visible?: boolean | undefined;
    } | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAxisConstantLineStyleLabelProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    position?: RelativePosition;
    verticalAlignment?: VerticalAlignment;
    visible?: boolean;
}>;
declare const AxisConstantLineStyleLabel: ((props: IAxisConstantLineStyleLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    position?: RelativePosition | undefined;
    verticalAlignment?: VerticalAlignment | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAxisLabelProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    customizeHint?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    customizeText?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    displayMode?: ChartLabelDisplayMode;
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    indentFromAxis?: number;
    overlappingBehavior?: ChartsAxisLabelOverlap;
    position?: Position | RelativePosition;
    rotationAngle?: number;
    staggeringSpacing?: number;
    template?: ((data: {
        value: Date | number | string;
        valueText: string;
    }, element: any) => string | any) | template | undefined;
    textOverflow?: TextOverflow;
    visible?: boolean;
    wordWrap?: WordWrap;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const AxisLabel: ((props: IAxisLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    customizeHint?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string) | undefined;
    customizeText?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string) | undefined;
    displayMode?: ChartLabelDisplayMode | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    indentFromAxis?: number | undefined;
    overlappingBehavior?: ChartsAxisLabelOverlap | undefined;
    position?: Position | RelativePosition | undefined;
    rotationAngle?: number | undefined;
    staggeringSpacing?: number | undefined;
    template?: template | ((data: {
        value: Date | number | string;
        valueText: string;
    }, element: any) => string | any) | undefined;
    textOverflow?: TextOverflow | undefined;
    visible?: boolean | undefined;
    wordWrap?: WordWrap | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAxisTitleProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment;
    font?: ChartsFont;
    margin?: number;
    text?: string | undefined;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const AxisTitle: ((props: IAxisTitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    font?: ChartsFont | undefined;
    margin?: number | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBackgroundColorProps = React.PropsWithChildren<{
    base?: string | undefined;
    fillId?: string | undefined;
}>;
declare const BackgroundColor: ((props: IBackgroundColorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    base?: string | undefined;
    fillId?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBorderProps = React.PropsWithChildren<{
    color?: string | undefined;
    cornerRadius?: number;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
    bottom?: boolean;
    left?: boolean;
    right?: boolean;
    top?: boolean;
}>;
declare const Border: ((props: IBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    cornerRadius?: number | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
    bottom?: boolean | undefined;
    left?: boolean | undefined;
    right?: boolean | undefined;
    top?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBreakProps = React.PropsWithChildren<{
    endValue?: Date | number | string | undefined;
    startValue?: Date | number | string | undefined;
}>;
declare const Break: ((props: IBreakProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    endValue?: Date | number | string | undefined;
    startValue?: Date | number | string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBreakStyleProps = React.PropsWithChildren<{
    color?: string;
    line?: ScaleBreakLineStyle;
    width?: number;
}>;
declare const BreakStyle: ((props: IBreakStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    line?: ScaleBreakLineStyle | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IChartTitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    margin?: number | Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    placeholderSize?: number | undefined;
    subtitle?: Record<string, any> | string | {
        font?: ChartsFont;
        offset?: number;
        text?: string;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    text?: string;
    textOverflow?: TextOverflow;
    verticalAlignment?: VerticalEdge;
    wordWrap?: WordWrap;
}>;
declare const ChartTitle: ((props: IChartTitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    placeholderSize?: number | undefined;
    subtitle?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        offset?: number | undefined;
        text?: string | undefined;
        textOverflow?: TextOverflow | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    verticalAlignment?: VerticalEdge | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IChartTitleSubtitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    offset?: number;
    text?: string;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const ChartTitleSubtitle: ((props: IChartTitleSubtitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    offset?: number | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColorProps = React.PropsWithChildren<{
    base?: string | undefined;
    fillId?: string | undefined;
}>;
declare const Color: ((props: IColorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    base?: string | undefined;
    fillId?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonAnnotationSettingsProps = React.PropsWithChildren<{
    allowDragging?: boolean;
    argument?: Date | number | string | undefined;
    arrowLength?: number;
    arrowWidth?: number;
    axis?: string | undefined;
    border?: Record<string, any> | {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: string;
    customizeTooltip?: ((annotation: dxChartAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont;
    height?: number | undefined;
    image?: Record<string, any> | string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    series?: string | undefined;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    template?: ((annotation: dxChartAnnotationConfig | any, element: any) => string | any) | template | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow;
    tooltipEnabled?: boolean;
    tooltipTemplate?: ((annotation: dxChartAnnotationConfig | any, element: any) => string | any) | template | undefined;
    type?: AnnotationType | undefined;
    value?: Date | number | string | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap;
    x?: number | undefined;
    y?: number | undefined;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
    tooltipRender?: (...params: any) => React.ReactNode;
    tooltipComponent?: React.ComponentType<any>;
}>;
declare const CommonAnnotationSettings: ((props: ICommonAnnotationSettingsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowDragging?: boolean | undefined;
    argument?: Date | number | string | undefined;
    arrowLength?: number | undefined;
    arrowWidth?: number | undefined;
    axis?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        cornerRadius?: number | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    customizeTooltip?: ((annotation: dxChartAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont | undefined;
    height?: number | undefined;
    image?: string | Record<string, any> | {
        height?: number | undefined;
        url?: string | undefined;
        width?: number | undefined;
    } | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    series?: string | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    template?: template | ((annotation: dxChartAnnotationConfig | any, element: any) => string | any) | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    tooltipEnabled?: boolean | undefined;
    tooltipTemplate?: template | ((annotation: dxChartAnnotationConfig | any, element: any) => string | any) | undefined;
    type?: AnnotationType | undefined;
    value?: Date | number | string | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap | undefined;
    x?: number | undefined;
    y?: number | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
    tooltipRender?: ((...params: any) => React.ReactNode) | undefined;
    tooltipComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonAxisSettingsProps = React.PropsWithChildren<{
    aggregatedPointsPosition?: AggregatedPointsPosition;
    allowDecimals?: boolean | undefined;
    breakStyle?: Record<string, any> | {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    };
    color?: string;
    constantLineStyle?: Record<string, any> | {
        color?: string;
        dashStyle?: DashStyle;
        label?: Record<string, any> | {
            font?: ChartsFont;
            position?: RelativePosition;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        width?: number;
    };
    discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
    endOnTick?: boolean | undefined;
    grid?: Record<string, any> | {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    inverted?: boolean;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        displayMode?: ChartLabelDisplayMode;
        font?: ChartsFont;
        indentFromAxis?: number;
        overlappingBehavior?: ChartsAxisLabelOverlap;
        position?: Position | RelativePosition;
        rotationAngle?: number;
        staggeringSpacing?: number;
        template?: ((data: {
            value: Date | number | string;
            valueText: string;
        }, element: any) => string | any) | template | undefined;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    };
    maxValueMargin?: number | undefined;
    minorGrid?: Record<string, any> | {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    minorTick?: Record<string, any> | {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    minValueMargin?: number | undefined;
    opacity?: number | undefined;
    placeholderSize?: number;
    stripStyle?: Record<string, any> | {
        label?: Record<string, any> | {
            font?: ChartsFont;
            horizontalAlignment?: HorizontalAlignment;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
    };
    tick?: Record<string, any> | {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    title?: Record<string, any> | {
        alignment?: HorizontalAlignment;
        font?: ChartsFont;
        margin?: number;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    valueMarginsEnabled?: boolean;
    visible?: boolean;
    width?: number;
}>;
declare const CommonAxisSettings: ((props: ICommonAxisSettingsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    aggregatedPointsPosition?: AggregatedPointsPosition | undefined;
    allowDecimals?: boolean | undefined;
    breakStyle?: Record<string, any> | {
        color?: string | undefined;
        line?: ScaleBreakLineStyle | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    constantLineStyle?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            position?: RelativePosition | undefined;
            visible?: boolean | undefined;
        } | undefined;
        paddingLeftRight?: number | undefined;
        paddingTopBottom?: number | undefined;
        width?: number | undefined;
    } | undefined;
    discreteAxisDivisionMode?: DiscreteAxisDivisionMode | undefined;
    endOnTick?: boolean | undefined;
    grid?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    inverted?: boolean | undefined;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        displayMode?: ChartLabelDisplayMode | undefined;
        font?: ChartsFont | undefined;
        indentFromAxis?: number | undefined;
        overlappingBehavior?: ChartsAxisLabelOverlap | undefined;
        position?: Position | RelativePosition | undefined;
        rotationAngle?: number | undefined;
        staggeringSpacing?: number | undefined;
        template?: template | ((data: {
            value: Date | number | string;
            valueText: string;
        }, element: any) => string | any) | undefined;
        textOverflow?: TextOverflow | undefined;
        visible?: boolean | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    maxValueMargin?: number | undefined;
    minorGrid?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    minorTick?: Record<string, any> | {
        color?: string | undefined;
        length?: number | undefined;
        opacity?: number | undefined;
        shift?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    minValueMargin?: number | undefined;
    opacity?: number | undefined;
    placeholderSize?: number | undefined;
    stripStyle?: Record<string, any> | {
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            horizontalAlignment?: HorizontalAlignment | undefined;
            verticalAlignment?: VerticalAlignment | undefined;
        } | undefined;
        paddingLeftRight?: number | undefined;
        paddingTopBottom?: number | undefined;
    } | undefined;
    tick?: Record<string, any> | {
        color?: string | undefined;
        length?: number | undefined;
        opacity?: number | undefined;
        shift?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    title?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        font?: ChartsFont | undefined;
        margin?: number | undefined;
        textOverflow?: TextOverflow | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    valueMarginsEnabled?: boolean | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonAxisSettingsConstantLineStyleProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    label?: Record<string, any> | {
        font?: ChartsFont;
        position?: RelativePosition;
        visible?: boolean;
    };
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    width?: number;
}>;
declare const CommonAxisSettingsConstantLineStyle: ((props: ICommonAxisSettingsConstantLineStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    label?: Record<string, any> | {
        font?: ChartsFont | undefined;
        position?: RelativePosition | undefined;
        visible?: boolean | undefined;
    } | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonAxisSettingsConstantLineStyleLabelProps = React.PropsWithChildren<{
    font?: ChartsFont;
    position?: RelativePosition;
    visible?: boolean;
}>;
declare const CommonAxisSettingsConstantLineStyleLabel: ((props: ICommonAxisSettingsConstantLineStyleLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    position?: RelativePosition | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonAxisSettingsLabelProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    displayMode?: ChartLabelDisplayMode;
    font?: ChartsFont;
    indentFromAxis?: number;
    overlappingBehavior?: ChartsAxisLabelOverlap;
    position?: Position | RelativePosition;
    rotationAngle?: number;
    staggeringSpacing?: number;
    template?: ((data: {
        value: Date | number | string;
        valueText: string;
    }, element: any) => string | any) | template | undefined;
    textOverflow?: TextOverflow;
    visible?: boolean;
    wordWrap?: WordWrap;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const CommonAxisSettingsLabel: ((props: ICommonAxisSettingsLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    displayMode?: ChartLabelDisplayMode | undefined;
    font?: ChartsFont | undefined;
    indentFromAxis?: number | undefined;
    overlappingBehavior?: ChartsAxisLabelOverlap | undefined;
    position?: Position | RelativePosition | undefined;
    rotationAngle?: number | undefined;
    staggeringSpacing?: number | undefined;
    template?: template | ((data: {
        value: Date | number | string;
        valueText: string;
    }, element: any) => string | any) | undefined;
    textOverflow?: TextOverflow | undefined;
    visible?: boolean | undefined;
    wordWrap?: WordWrap | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonAxisSettingsTitleProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment;
    font?: ChartsFont;
    margin?: number;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const CommonAxisSettingsTitle: ((props: ICommonAxisSettingsTitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    font?: ChartsFont | undefined;
    margin?: number | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonPaneSettingsProps = React.PropsWithChildren<{
    backgroundColor?: ChartsColor | string;
    border?: Record<string, any> | {
        bottom?: boolean;
        color?: string;
        dashStyle?: DashStyle;
        left?: boolean;
        opacity?: number | undefined;
        right?: boolean;
        top?: boolean;
        visible?: boolean;
        width?: number;
    };
}>;
declare const CommonPaneSettings: ((props: ICommonPaneSettingsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | ChartsColor | undefined;
    border?: Record<string, any> | {
        bottom?: boolean | undefined;
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        left?: boolean | undefined;
        opacity?: number | undefined;
        right?: boolean | undefined;
        top?: boolean | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonSeriesSettingsProps = React.PropsWithChildren<{
    aggregation?: Record<string, any> | {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    };
    area?: any;
    argumentField?: string;
    axis?: string | undefined;
    bar?: any;
    barOverlapGroup?: string | undefined;
    barPadding?: number | undefined;
    barWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    bubble?: any;
    candlestick?: any;
    closeValueField?: string;
    color?: ChartsColor | string | undefined;
    cornerRadius?: number;
    dashStyle?: DashStyle;
    fullstackedarea?: any;
    fullstackedbar?: any;
    fullstackedline?: any;
    fullstackedspline?: any;
    fullstackedsplinearea?: any;
    highValueField?: string;
    hoverMode?: SeriesHoverMode;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    ignoreEmptyPoints?: boolean;
    innerColor?: string;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment;
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    };
    line?: any;
    lowValueField?: string;
    maxLabelCount?: number | undefined;
    minBarSize?: number | undefined;
    opacity?: number;
    openValueField?: string;
    pane?: string;
    point?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: Record<string, any> | string | undefined | {
            height?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: Record<string, any> | string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    };
    rangearea?: any;
    rangebar?: any;
    rangeValue1Field?: string;
    rangeValue2Field?: string;
    reduction?: Record<string, any> | {
        color?: string;
        level?: FinancialChartReductionLevel;
    };
    scatter?: any;
    selectionMode?: SeriesSelectionMode;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    showInLegend?: boolean;
    sizeField?: string;
    spline?: any;
    splinearea?: any;
    stack?: string;
    stackedarea?: any;
    stackedbar?: any;
    stackedline?: any;
    stackedspline?: any;
    stackedsplinearea?: any;
    steparea?: any;
    stepline?: any;
    stock?: any;
    tagField?: string;
    type?: SeriesType;
    valueErrorBar?: Record<string, any> | {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    };
    valueField?: string;
    visible?: boolean;
    width?: number;
}>;
declare const CommonSeriesSettings: ((props: ICommonSeriesSettingsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    aggregation?: Record<string, any> | {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean | undefined;
        method?: ChartSeriesAggregationMethod | undefined;
    } | undefined;
    area?: any;
    argumentField?: string | undefined;
    axis?: string | undefined;
    bar?: any;
    barOverlapGroup?: string | undefined;
    barPadding?: number | undefined;
    barWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    bubble?: any;
    candlestick?: any;
    closeValueField?: string | undefined;
    color?: ChartsColor | string | undefined;
    cornerRadius?: number | undefined;
    dashStyle?: DashStyle | undefined;
    fullstackedarea?: any;
    fullstackedbar?: any;
    fullstackedline?: any;
    fullstackedspline?: any;
    fullstackedsplinearea?: any;
    highValueField?: string | undefined;
    hoverMode?: SeriesHoverMode | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    ignoreEmptyPoints?: boolean | undefined;
    innerColor?: string | undefined;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        customizeText?: ((pointInfo: any) => string) | undefined;
        displayFormat?: string | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        horizontalOffset?: number | undefined;
        position?: RelativePosition | undefined;
        rotationAngle?: number | undefined;
        showForZeroValues?: boolean | undefined;
        verticalOffset?: number | undefined;
        visible?: boolean | undefined;
    } | undefined;
    line?: any;
    lowValueField?: string | undefined;
    maxLabelCount?: number | undefined;
    minBarSize?: number | undefined;
    opacity?: number | undefined;
    openValueField?: string | undefined;
    pane?: string | undefined;
    point?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode | undefined;
        hoverStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            } | undefined;
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        } | undefined;
        image?: Record<string, any> | string | undefined | {
            height?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: Record<string, any> | string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode | undefined;
        selectionStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            } | undefined;
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        } | undefined;
        size?: number | undefined;
        symbol?: PointSymbol | undefined;
        visible?: boolean | undefined;
    } | undefined;
    rangearea?: any;
    rangebar?: any;
    rangeValue1Field?: string | undefined;
    rangeValue2Field?: string | undefined;
    reduction?: Record<string, any> | {
        color?: string | undefined;
        level?: FinancialChartReductionLevel | undefined;
    } | undefined;
    scatter?: any;
    selectionMode?: SeriesSelectionMode | undefined;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    showInLegend?: boolean | undefined;
    sizeField?: string | undefined;
    spline?: any;
    splinearea?: any;
    stack?: string | undefined;
    stackedarea?: any;
    stackedbar?: any;
    stackedline?: any;
    stackedspline?: any;
    stackedsplinearea?: any;
    steparea?: any;
    stepline?: any;
    stock?: any;
    tagField?: string | undefined;
    type?: SeriesType | undefined;
    valueErrorBar?: Record<string, any> | {
        color?: string | undefined;
        displayMode?: ValueErrorBarDisplayMode | undefined;
        edgeLength?: number | undefined;
        highValueField?: string | undefined;
        lineWidth?: number | undefined;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number | undefined;
    } | undefined;
    valueField?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonSeriesSettingsHoverStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle;
    hatching?: Record<string, any> | {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    highlight?: boolean;
    width?: number;
}>;
declare const CommonSeriesSettingsHoverStyle: ((props: ICommonSeriesSettingsHoverStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection | undefined;
        opacity?: number | undefined;
        step?: number | undefined;
        width?: number | undefined;
    } | undefined;
    highlight?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonSeriesSettingsLabelProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment;
    argumentFormat?: LocalizationFormat | undefined;
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    connector?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    customizeText?: ((pointInfo: any) => string);
    displayFormat?: string | undefined;
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    horizontalOffset?: number;
    position?: RelativePosition;
    rotationAngle?: number;
    showForZeroValues?: boolean;
    verticalOffset?: number;
    visible?: boolean;
}>;
declare const CommonSeriesSettingsLabel: ((props: ICommonSeriesSettingsLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    argumentFormat?: LocalizationFormat | undefined;
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    connector?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    customizeText?: ((pointInfo: any) => string) | undefined;
    displayFormat?: string | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    horizontalOffset?: number | undefined;
    position?: RelativePosition | undefined;
    rotationAngle?: number | undefined;
    showForZeroValues?: boolean | undefined;
    verticalOffset?: number | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonSeriesSettingsSelectionStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle;
    hatching?: Record<string, any> | {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    highlight?: boolean;
    width?: number;
}>;
declare const CommonSeriesSettingsSelectionStyle: ((props: ICommonSeriesSettingsSelectionStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection | undefined;
        opacity?: number | undefined;
        step?: number | undefined;
        width?: number | undefined;
    } | undefined;
    highlight?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IConnectorProps = React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const Connector: ((props: IConnectorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IConstantLineProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    displayBehindSeries?: boolean;
    extendAxis?: boolean;
    label?: Record<string, any> | {
        font?: ChartsFont;
        horizontalAlignment?: HorizontalAlignment;
        position?: RelativePosition;
        text?: string | undefined;
        verticalAlignment?: VerticalAlignment;
        visible?: boolean;
    };
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    value?: Date | number | string | undefined;
    width?: number;
}>;
declare const ConstantLine: ((props: IConstantLineProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    displayBehindSeries?: boolean | undefined;
    extendAxis?: boolean | undefined;
    label?: Record<string, any> | {
        font?: ChartsFont | undefined;
        horizontalAlignment?: HorizontalAlignment | undefined;
        position?: RelativePosition | undefined;
        text?: string | undefined;
        verticalAlignment?: VerticalAlignment | undefined;
        visible?: boolean | undefined;
    } | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    value?: Date | number | string | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IConstantLineLabelProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    position?: RelativePosition;
    text?: string | undefined;
    verticalAlignment?: VerticalAlignment;
    visible?: boolean;
}>;
declare const ConstantLineLabel: ((props: IConstantLineLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    position?: RelativePosition | undefined;
    text?: string | undefined;
    verticalAlignment?: VerticalAlignment | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IConstantLineStyleProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    label?: Record<string, any> | {
        font?: ChartsFont;
        horizontalAlignment?: HorizontalAlignment;
        position?: RelativePosition;
        verticalAlignment?: VerticalAlignment;
        visible?: boolean;
    };
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    width?: number;
}>;
declare const ConstantLineStyle: ((props: IConstantLineStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    label?: Record<string, any> | {
        font?: ChartsFont | undefined;
        horizontalAlignment?: HorizontalAlignment | undefined;
        position?: RelativePosition | undefined;
        verticalAlignment?: VerticalAlignment | undefined;
        visible?: boolean | undefined;
    } | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICrosshairProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    enabled?: boolean;
    horizontalLine?: boolean | Record<string, any> | {
        color?: string;
        dashStyle?: DashStyle;
        label?: Record<string, any> | {
            backgroundColor?: string;
            customizeText?: ((info: {
                point: chartPointObject;
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: ChartsFont;
            format?: LocalizationFormat | undefined;
            visible?: boolean;
        };
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    label?: Record<string, any> | {
        backgroundColor?: string;
        customizeText?: ((info: {
            point: chartPointObject;
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        visible?: boolean;
    };
    opacity?: number | undefined;
    verticalLine?: boolean | Record<string, any> | {
        color?: string;
        dashStyle?: DashStyle;
        label?: Record<string, any> | {
            backgroundColor?: string;
            customizeText?: ((info: {
                point: chartPointObject;
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: ChartsFont;
            format?: LocalizationFormat | undefined;
            visible?: boolean;
        };
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    width?: number;
}>;
declare const Crosshair: ((props: ICrosshairProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    enabled?: boolean | undefined;
    horizontalLine?: boolean | Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        label?: Record<string, any> | {
            backgroundColor?: string | undefined;
            customizeText?: ((info: {
                point: chartPointObject;
                value: Date | number | string;
                valueText: string;
            }) => string) | undefined;
            font?: ChartsFont | undefined;
            format?: LocalizationFormat | undefined;
            visible?: boolean | undefined;
        } | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    label?: Record<string, any> | {
        backgroundColor?: string | undefined;
        customizeText?: ((info: {
            point: chartPointObject;
            value: Date | number | string;
            valueText: string;
        }) => string) | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        visible?: boolean | undefined;
    } | undefined;
    opacity?: number | undefined;
    verticalLine?: boolean | Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        label?: Record<string, any> | {
            backgroundColor?: string | undefined;
            customizeText?: ((info: {
                point: chartPointObject;
                value: Date | number | string;
                valueText: string;
            }) => string) | undefined;
            font?: ChartsFont | undefined;
            format?: LocalizationFormat | undefined;
            visible?: boolean | undefined;
        } | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IDataPrepareSettingsProps = React.PropsWithChildren<{
    checkTypeForAllData?: boolean;
    convertToAxisDataType?: boolean;
    sortingMethod?: boolean | ((a: any, b: any) => number);
}>;
declare const DataPrepareSettings: ((props: IDataPrepareSettingsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    checkTypeForAllData?: boolean | undefined;
    convertToAxisDataType?: boolean | undefined;
    sortingMethod?: boolean | ((a: any, b: any) => number) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IDragBoxStyleProps = React.PropsWithChildren<{
    color?: string | undefined;
    opacity?: number | undefined;
}>;
declare const DragBoxStyle: ((props: IDragBoxStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    opacity?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IExportProps = React.PropsWithChildren<{
    backgroundColor?: string;
    enabled?: boolean;
    fileName?: string;
    formats?: Array<ExportFormat>;
    margin?: number;
    printingEnabled?: boolean;
    svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
}>;
declare const Export: ((props: IExportProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    enabled?: boolean | undefined;
    fileName?: string | undefined;
    formats?: ExportFormat[] | undefined;
    margin?: number | undefined;
    printingEnabled?: boolean | undefined;
    svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFontProps = React.PropsWithChildren<{
    color?: string;
    family?: string;
    opacity?: number;
    size?: number | string;
    weight?: number;
}>;
declare const Font: ((props: IFontProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    family?: string | undefined;
    opacity?: number | undefined;
    size?: string | number | undefined;
    weight?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const Format: ((props: IFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IGridProps = React.PropsWithChildren<{
    color?: string;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const Grid: ((props: IGridProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHatchingProps = React.PropsWithChildren<{
    direction?: HatchDirection;
    opacity?: number;
    step?: number;
    width?: number;
}>;
declare const Hatching: ((props: IHatchingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    direction?: HatchDirection | undefined;
    opacity?: number | undefined;
    step?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHeightProps = React.PropsWithChildren<{
    rangeMaxPoint?: number | undefined;
    rangeMinPoint?: number | undefined;
}>;
declare const Height: ((props: IHeightProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    rangeMaxPoint?: number | undefined;
    rangeMinPoint?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHorizontalLineProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    label?: Record<string, any> | {
        backgroundColor?: string;
        customizeText?: ((info: {
            point: chartPointObject;
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        visible?: boolean;
    };
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const HorizontalLine: ((props: IHorizontalLineProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    label?: Record<string, any> | {
        backgroundColor?: string | undefined;
        customizeText?: ((info: {
            point: chartPointObject;
            value: Date | number | string;
            valueText: string;
        }) => string) | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        visible?: boolean | undefined;
    } | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHorizontalLineLabelProps = React.PropsWithChildren<{
    backgroundColor?: string;
    customizeText?: ((info: {
        point: chartPointObject;
        value: Date | number | string;
        valueText: string;
    }) => string);
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    visible?: boolean;
}>;
declare const HorizontalLineLabel: ((props: IHorizontalLineLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    customizeText?: ((info: {
        point: chartPointObject;
        value: Date | number | string;
        valueText: string;
    }) => string) | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHoverStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle;
    hatching?: Record<string, any> | {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    highlight?: boolean;
    width?: number;
    size?: number | undefined;
}>;
declare const HoverStyle: ((props: IHoverStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection | undefined;
        opacity?: number | undefined;
        step?: number | undefined;
        width?: number | undefined;
    } | undefined;
    highlight?: boolean | undefined;
    width?: number | undefined;
    size?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IImageProps = React.PropsWithChildren<{
    height?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
    url?: string | undefined | Record<string, any> | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    };
    width?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
}>;
declare const Image: ((props: IImageProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    } | undefined;
    url?: string | undefined | Record<string, any> | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    };
    width?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILabelProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    position?: RelativePosition | Position;
    verticalAlignment?: VerticalAlignment;
    visible?: boolean;
    text?: string | undefined;
    alignment?: HorizontalAlignment | undefined;
    customizeHint?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    customizeText?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    displayMode?: ChartLabelDisplayMode;
    format?: LocalizationFormat | undefined;
    indentFromAxis?: number;
    overlappingBehavior?: ChartsAxisLabelOverlap;
    rotationAngle?: number;
    staggeringSpacing?: number;
    template?: ((data: {
        value: Date | number | string;
        valueText: string;
    }, element: any) => string | any) | template | undefined;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
    argumentFormat?: LocalizationFormat | undefined;
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    connector?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    displayFormat?: string | undefined;
    horizontalOffset?: number;
    showForZeroValues?: boolean;
    verticalOffset?: number;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const Label: ((props: ILabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    position?: Position | RelativePosition | undefined;
    verticalAlignment?: VerticalAlignment | undefined;
    visible?: boolean | undefined;
    text?: string | undefined;
    alignment?: HorizontalAlignment | undefined;
    customizeHint?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string) | undefined;
    customizeText?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string) | undefined;
    displayMode?: ChartLabelDisplayMode | undefined;
    format?: LocalizationFormat | undefined;
    indentFromAxis?: number | undefined;
    overlappingBehavior?: ChartsAxisLabelOverlap | undefined;
    rotationAngle?: number | undefined;
    staggeringSpacing?: number | undefined;
    template?: template | ((data: {
        value: Date | number | string;
        valueText: string;
    }, element: any) => string | any) | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
    argumentFormat?: LocalizationFormat | undefined;
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    connector?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    displayFormat?: string | undefined;
    horizontalOffset?: number | undefined;
    showForZeroValues?: boolean | undefined;
    verticalOffset?: number | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILegendProps = React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    columnCount?: number;
    columnItemSpacing?: number;
    customizeHint?: ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string);
    customizeItems?: ((items: Array<LegendItem>) => Array<LegendItem>);
    customizeText?: ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string);
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    hoverMode?: LegendHoverMode;
    itemsAlignment?: HorizontalAlignment | undefined;
    itemTextPosition?: Position | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    markerSize?: number;
    markerTemplate?: ((legendItem: LegendItem, element: any) => string | any) | template | undefined;
    orientation?: Orientation | undefined;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    position?: RelativePosition;
    rowCount?: number;
    rowItemSpacing?: number;
    title?: Record<string, any> | string | {
        font?: ChartsFont;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: Record<string, any> | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: Record<string, any> | string | {
            font?: ChartsFont;
            offset?: number;
            text?: string;
        };
        text?: string;
        verticalAlignment?: VerticalEdge;
    };
    verticalAlignment?: VerticalEdge;
    visible?: boolean;
    markerRender?: (...params: any) => React.ReactNode;
    markerComponent?: React.ComponentType<any>;
}>;
declare const Legend: ((props: ILegendProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        cornerRadius?: number | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    columnCount?: number | undefined;
    columnItemSpacing?: number | undefined;
    customizeHint?: ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string) | undefined;
    customizeItems?: ((items: Array<LegendItem>) => Array<LegendItem>) | undefined;
    customizeText?: ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string) | undefined;
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    hoverMode?: LegendHoverMode | undefined;
    itemsAlignment?: HorizontalAlignment | undefined;
    itemTextPosition?: Position | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    markerSize?: number | undefined;
    markerTemplate?: template | ((legendItem: LegendItem, element: any) => string | any) | undefined;
    orientation?: Orientation | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    position?: RelativePosition | undefined;
    rowCount?: number | undefined;
    rowItemSpacing?: number | undefined;
    title?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: Record<string, any> | {
            bottom?: number | undefined;
            left?: number | undefined;
            right?: number | undefined;
            top?: number | undefined;
        } | undefined;
        placeholderSize?: number | undefined;
        subtitle?: string | Record<string, any> | {
            font?: ChartsFont | undefined;
            offset?: number | undefined;
            text?: string | undefined;
        } | undefined;
        text?: string | undefined;
        verticalAlignment?: VerticalEdge | undefined;
    } | undefined;
    verticalAlignment?: VerticalEdge | undefined;
    visible?: boolean | undefined;
    markerRender?: ((...params: any) => React.ReactNode) | undefined;
    markerComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILegendTitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    placeholderSize?: number | undefined;
    subtitle?: Record<string, any> | string | {
        font?: ChartsFont;
        offset?: number;
        text?: string;
    };
    text?: string;
    verticalAlignment?: VerticalEdge;
}>;
declare const LegendTitle: ((props: ILegendTitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    placeholderSize?: number | undefined;
    subtitle?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        offset?: number | undefined;
        text?: string | undefined;
    } | undefined;
    text?: string | undefined;
    verticalAlignment?: VerticalEdge | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILegendTitleSubtitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    offset?: number;
    text?: string;
}>;
declare const LegendTitleSubtitle: ((props: ILegendTitleSubtitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    offset?: number | undefined;
    text?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILengthProps = React.PropsWithChildren<{
    days?: number;
    hours?: number;
    milliseconds?: number;
    minutes?: number;
    months?: number;
    quarters?: number;
    seconds?: number;
    weeks?: number;
    years?: number;
}>;
declare const Length: ((props: ILengthProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    days?: number | undefined;
    hours?: number | undefined;
    milliseconds?: number | undefined;
    minutes?: number | undefined;
    months?: number | undefined;
    quarters?: number | undefined;
    seconds?: number | undefined;
    weeks?: number | undefined;
    years?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILoadingIndicatorProps = React.PropsWithChildren<{
    backgroundColor?: string;
    enabled?: boolean;
    font?: ChartsFont;
    show?: boolean;
    text?: string;
    defaultShow?: boolean;
    onShowChange?: (value: boolean) => void;
}>;
declare const LoadingIndicator: ((props: ILoadingIndicatorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    enabled?: boolean | undefined;
    font?: ChartsFont | undefined;
    show?: boolean | undefined;
    text?: string | undefined;
    defaultShow?: boolean | undefined;
    onShowChange?: ((value: boolean) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMarginProps = React.PropsWithChildren<{
    bottom?: number;
    left?: number;
    right?: number;
    top?: number;
}>;
declare const Margin: ((props: IMarginProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    bottom?: number | undefined;
    left?: number | undefined;
    right?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMinorGridProps = React.PropsWithChildren<{
    color?: string;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const MinorGrid: ((props: IMinorGridProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMinorTickProps = React.PropsWithChildren<{
    color?: string;
    length?: number;
    opacity?: number;
    shift?: number;
    visible?: boolean;
    width?: number;
}>;
declare const MinorTick: ((props: IMinorTickProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    length?: number | undefined;
    opacity?: number | undefined;
    shift?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMinorTickIntervalProps = React.PropsWithChildren<{
    days?: number;
    hours?: number;
    milliseconds?: number;
    minutes?: number;
    months?: number;
    quarters?: number;
    seconds?: number;
    weeks?: number;
    years?: number;
}>;
declare const MinorTickInterval: ((props: IMinorTickIntervalProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    days?: number | undefined;
    hours?: number | undefined;
    milliseconds?: number | undefined;
    minutes?: number | undefined;
    months?: number | undefined;
    quarters?: number | undefined;
    seconds?: number | undefined;
    weeks?: number | undefined;
    years?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMinVisualRangeLengthProps = React.PropsWithChildren<{
    days?: number;
    hours?: number;
    milliseconds?: number;
    minutes?: number;
    months?: number;
    quarters?: number;
    seconds?: number;
    weeks?: number;
    years?: number;
}>;
declare const MinVisualRangeLength: ((props: IMinVisualRangeLengthProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    days?: number | undefined;
    hours?: number | undefined;
    milliseconds?: number | undefined;
    minutes?: number | undefined;
    months?: number | undefined;
    quarters?: number | undefined;
    seconds?: number | undefined;
    weeks?: number | undefined;
    years?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPaneProps = React.PropsWithChildren<{
    backgroundColor?: ChartsColor | string;
    border?: Record<string, any> | {
        bottom?: boolean;
        color?: string;
        dashStyle?: DashStyle;
        left?: boolean;
        opacity?: number | undefined;
        right?: boolean;
        top?: boolean;
        visible?: boolean;
        width?: number;
    };
    height?: number | string | undefined;
    name?: string | undefined;
}>;
declare const Pane: ((props: IPaneProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | ChartsColor | undefined;
    border?: Record<string, any> | {
        bottom?: boolean | undefined;
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        left?: boolean | undefined;
        opacity?: number | undefined;
        right?: boolean | undefined;
        top?: boolean | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    height?: number | string | undefined;
    name?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPaneBorderProps = React.PropsWithChildren<{
    bottom?: boolean;
    color?: string;
    dashStyle?: DashStyle;
    left?: boolean;
    opacity?: number | undefined;
    right?: boolean;
    top?: boolean;
    visible?: boolean;
    width?: number;
}>;
declare const PaneBorder: ((props: IPaneBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    bottom?: boolean | undefined;
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    left?: boolean | undefined;
    opacity?: number | undefined;
    right?: boolean | undefined;
    top?: boolean | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPointProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    hoverMode?: PointInteractionMode;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    };
    image?: Record<string, any> | string | undefined | {
        height?: number | Record<string, any> | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
        url?: Record<string, any> | string | undefined | {
            rangeMaxPoint?: string | undefined;
            rangeMinPoint?: string | undefined;
        };
        width?: number | Record<string, any> | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
    };
    selectionMode?: PointInteractionMode;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    };
    size?: number;
    symbol?: PointSymbol;
    visible?: boolean;
}>;
declare const Point: ((props: IPointProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    hoverMode?: PointInteractionMode | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    } | undefined;
    image?: Record<string, any> | string | undefined | {
        height?: number | Record<string, any> | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
        url?: Record<string, any> | string | undefined | {
            rangeMaxPoint?: string | undefined;
            rangeMinPoint?: string | undefined;
        };
        width?: number | Record<string, any> | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
    };
    selectionMode?: PointInteractionMode | undefined;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    } | undefined;
    size?: number | undefined;
    symbol?: PointSymbol | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPointBorderProps = React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const PointBorder: ((props: IPointBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPointHoverStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    size?: number | undefined;
}>;
declare const PointHoverStyle: ((props: IPointHoverStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    size?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPointImageProps = React.PropsWithChildren<{
    height?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
    url?: Record<string, any> | string | undefined | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    };
    width?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
}>;
declare const PointImage: ((props: IPointImageProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    } | undefined;
    url?: Record<string, any> | string | undefined | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    };
    width?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPointSelectionStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    size?: number | undefined;
}>;
declare const PointSelectionStyle: ((props: IPointSelectionStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    size?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IReductionProps = React.PropsWithChildren<{
    color?: string;
    level?: FinancialChartReductionLevel;
}>;
declare const Reduction: ((props: IReductionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    level?: FinancialChartReductionLevel | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IScrollBarProps = React.PropsWithChildren<{
    color?: string;
    offset?: number;
    opacity?: number | undefined;
    position?: Position;
    visible?: boolean;
    width?: number;
}>;
declare const ScrollBar: ((props: IScrollBarProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    offset?: number | undefined;
    opacity?: number | undefined;
    position?: Position | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISelectionStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
        dashStyle?: DashStyle | undefined;
    };
    color?: ChartsColor | string | undefined;
    size?: number | undefined;
    dashStyle?: DashStyle;
    hatching?: Record<string, any> | {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    highlight?: boolean;
    width?: number;
}>;
declare const SelectionStyle: ((props: ISelectionStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
        dashStyle?: DashStyle | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    size?: number | undefined;
    dashStyle?: DashStyle | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection | undefined;
        opacity?: number | undefined;
        step?: number | undefined;
        width?: number | undefined;
    } | undefined;
    highlight?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISeriesProps = React.PropsWithChildren<{
    aggregation?: Record<string, any> | {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    };
    argumentField?: string;
    axis?: string | undefined;
    barOverlapGroup?: string | undefined;
    barPadding?: number | undefined;
    barWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    closeValueField?: string;
    color?: ChartsColor | string | undefined;
    cornerRadius?: number;
    dashStyle?: DashStyle;
    highValueField?: string;
    hoverMode?: SeriesHoverMode;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    ignoreEmptyPoints?: boolean;
    innerColor?: string;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment;
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    };
    lowValueField?: string;
    maxLabelCount?: number | undefined;
    minBarSize?: number | undefined;
    name?: string | undefined;
    opacity?: number;
    openValueField?: string;
    pane?: string;
    point?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: Record<string, any> | string | undefined | {
            height?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: Record<string, any> | string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    };
    rangeValue1Field?: string;
    rangeValue2Field?: string;
    reduction?: Record<string, any> | {
        color?: string;
        level?: FinancialChartReductionLevel;
    };
    selectionMode?: SeriesSelectionMode;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    showInLegend?: boolean;
    sizeField?: string;
    stack?: string;
    tag?: any | undefined;
    tagField?: string;
    type?: SeriesType;
    valueErrorBar?: Record<string, any> | {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    };
    valueField?: string;
    visible?: boolean;
    width?: number;
}>;
declare const Series: ((props: ISeriesProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    aggregation?: Record<string, any> | {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean | undefined;
        method?: ChartSeriesAggregationMethod | undefined;
    } | undefined;
    argumentField?: string | undefined;
    axis?: string | undefined;
    barOverlapGroup?: string | undefined;
    barPadding?: number | undefined;
    barWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    closeValueField?: string | undefined;
    color?: ChartsColor | string | undefined;
    cornerRadius?: number | undefined;
    dashStyle?: DashStyle | undefined;
    highValueField?: string | undefined;
    hoverMode?: SeriesHoverMode | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    ignoreEmptyPoints?: boolean | undefined;
    innerColor?: string | undefined;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        customizeText?: ((pointInfo: any) => string) | undefined;
        displayFormat?: string | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        horizontalOffset?: number | undefined;
        position?: RelativePosition | undefined;
        rotationAngle?: number | undefined;
        showForZeroValues?: boolean | undefined;
        verticalOffset?: number | undefined;
        visible?: boolean | undefined;
    } | undefined;
    lowValueField?: string | undefined;
    maxLabelCount?: number | undefined;
    minBarSize?: number | undefined;
    name?: string | undefined;
    opacity?: number | undefined;
    openValueField?: string | undefined;
    pane?: string | undefined;
    point?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode | undefined;
        hoverStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            } | undefined;
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        } | undefined;
        image?: Record<string, any> | string | undefined | {
            height?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: Record<string, any> | string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode | undefined;
        selectionStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            } | undefined;
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        } | undefined;
        size?: number | undefined;
        symbol?: PointSymbol | undefined;
        visible?: boolean | undefined;
    } | undefined;
    rangeValue1Field?: string | undefined;
    rangeValue2Field?: string | undefined;
    reduction?: Record<string, any> | {
        color?: string | undefined;
        level?: FinancialChartReductionLevel | undefined;
    } | undefined;
    selectionMode?: SeriesSelectionMode | undefined;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    showInLegend?: boolean | undefined;
    sizeField?: string | undefined;
    stack?: string | undefined;
    tag?: any | undefined;
    tagField?: string | undefined;
    type?: SeriesType | undefined;
    valueErrorBar?: Record<string, any> | {
        color?: string | undefined;
        displayMode?: ValueErrorBarDisplayMode | undefined;
        edgeLength?: number | undefined;
        highValueField?: string | undefined;
        lineWidth?: number | undefined;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number | undefined;
    } | undefined;
    valueField?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISeriesBorderProps = React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const SeriesBorder: ((props: ISeriesBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISeriesTemplateProps = React.PropsWithChildren<{
    customizeSeries?: ((seriesName: any) => ChartSeries);
    nameField?: string;
}>;
declare const SeriesTemplate: ((props: ISeriesTemplateProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    customizeSeries?: ((seriesName: any) => ChartSeries) | undefined;
    nameField?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShadowProps = React.PropsWithChildren<{
    blur?: number;
    color?: string;
    offsetX?: number;
    offsetY?: number;
    opacity?: number;
}>;
declare const Shadow: ((props: IShadowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    blur?: number | undefined;
    color?: string | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISizeProps = React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
}>;
declare const Size: ((props: ISizeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IStripProps = React.PropsWithChildren<{
    color?: string | undefined;
    endValue?: Date | number | string | undefined;
    label?: Record<string, any> | {
        font?: ChartsFont;
        horizontalAlignment?: HorizontalAlignment;
        text?: string | undefined;
        verticalAlignment?: VerticalAlignment;
    };
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    startValue?: Date | number | string | undefined;
}>;
declare const Strip: ((props: IStripProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    endValue?: Date | number | string | undefined;
    label?: Record<string, any> | {
        font?: ChartsFont | undefined;
        horizontalAlignment?: HorizontalAlignment | undefined;
        text?: string | undefined;
        verticalAlignment?: VerticalAlignment | undefined;
    } | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    startValue?: Date | number | string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IStripLabelProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    text?: string | undefined;
    verticalAlignment?: VerticalAlignment;
}>;
declare const StripLabel: ((props: IStripLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    text?: string | undefined;
    verticalAlignment?: VerticalAlignment | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IStripStyleProps = React.PropsWithChildren<{
    label?: Record<string, any> | {
        font?: ChartsFont;
        horizontalAlignment?: HorizontalAlignment;
        verticalAlignment?: VerticalAlignment;
    };
    paddingLeftRight?: number;
    paddingTopBottom?: number;
}>;
declare const StripStyle: ((props: IStripStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    label?: Record<string, any> | {
        font?: ChartsFont | undefined;
        horizontalAlignment?: HorizontalAlignment | undefined;
        verticalAlignment?: VerticalAlignment | undefined;
    } | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IStripStyleLabelProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    verticalAlignment?: VerticalAlignment;
}>;
declare const StripStyleLabel: ((props: IStripStyleLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    verticalAlignment?: VerticalAlignment | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISubtitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    offset?: number;
    text?: string;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const Subtitle: ((props: ISubtitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    offset?: number | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITickProps = React.PropsWithChildren<{
    color?: string;
    length?: number;
    opacity?: number | undefined;
    shift?: number;
    visible?: boolean;
    width?: number;
}>;
declare const Tick: ((props: ITickProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    length?: number | undefined;
    opacity?: number | undefined;
    shift?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITickIntervalProps = React.PropsWithChildren<{
    days?: number;
    hours?: number;
    milliseconds?: number;
    minutes?: number;
    months?: number;
    quarters?: number;
    seconds?: number;
    weeks?: number;
    years?: number;
}>;
declare const TickInterval: ((props: ITickIntervalProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    days?: number | undefined;
    hours?: number | undefined;
    milliseconds?: number | undefined;
    minutes?: number | undefined;
    months?: number | undefined;
    quarters?: number | undefined;
    seconds?: number | undefined;
    weeks?: number | undefined;
    years?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITitleProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment;
    font?: ChartsFont;
    margin?: number | Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    text?: string | undefined;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
    horizontalAlignment?: HorizontalAlignment | undefined;
    placeholderSize?: number | undefined;
    subtitle?: Record<string, any> | string | {
        font?: ChartsFont;
        offset?: number;
        text?: string;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    verticalAlignment?: VerticalEdge;
}>;
declare const Title: ((props: ITitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    font?: ChartsFont | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    placeholderSize?: number | undefined;
    subtitle?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        offset?: number | undefined;
        text?: string | undefined;
        textOverflow?: TextOverflow | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    verticalAlignment?: VerticalEdge | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITooltipProps = React.PropsWithChildren<{
    argumentFormat?: LocalizationFormat | undefined;
    arrowLength?: number;
    border?: Record<string, any> | {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: string;
    container?: any | string | undefined;
    contentTemplate?: ((pointInfo: any, element: any) => string | any) | template | undefined;
    cornerRadius?: number;
    customizeTooltip?: ((pointInfo: any) => Record<string, any>) | undefined;
    enabled?: boolean;
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    interactive?: boolean;
    location?: ChartTooltipLocation;
    opacity?: number | undefined;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    shared?: boolean;
    zIndex?: number | undefined;
    contentRender?: (...params: any) => React.ReactNode;
    contentComponent?: React.ComponentType<any>;
}>;
declare const Tooltip: ((props: ITooltipProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    argumentFormat?: LocalizationFormat | undefined;
    arrowLength?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    container?: any | string | undefined;
    contentTemplate?: template | ((pointInfo: any, element: any) => string | any) | undefined;
    cornerRadius?: number | undefined;
    customizeTooltip?: ((pointInfo: any) => Record<string, any>) | undefined;
    enabled?: boolean | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    interactive?: boolean | undefined;
    location?: ChartTooltipLocation | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    shared?: boolean | undefined;
    zIndex?: number | undefined;
    contentRender?: ((...params: any) => React.ReactNode) | undefined;
    contentComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITooltipBorderProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const TooltipBorder: ((props: ITooltipBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IUrlProps = React.PropsWithChildren<{
    rangeMaxPoint?: string | undefined;
    rangeMinPoint?: string | undefined;
}>;
declare const Url: ((props: IUrlProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    rangeMaxPoint?: string | undefined;
    rangeMinPoint?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IValueAxisProps = React.PropsWithChildren<{
    aggregatedPointsPosition?: AggregatedPointsPosition;
    allowDecimals?: boolean | undefined;
    autoBreaksEnabled?: boolean;
    axisDivisionFactor?: number;
    breaks?: Array<ScaleBreak> | {
        endValue?: Date | number | string | undefined;
        startValue?: Date | number | string | undefined;
    }[];
    breakStyle?: Record<string, any> | {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    };
    categories?: Array<Date | number | string>;
    color?: string;
    constantLines?: Array<Record<string, any>> | {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: Record<string, any> | {
            font?: ChartsFont;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        value?: Date | number | string | undefined;
        width?: number;
    }[];
    constantLineStyle?: Record<string, any> | {
        color?: string;
        dashStyle?: DashStyle;
        label?: Record<string, any> | {
            font?: ChartsFont;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        width?: number;
    };
    customPosition?: Date | number | string | undefined;
    discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
    endOnTick?: boolean | undefined;
    grid?: Record<string, any> | {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    inverted?: boolean;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        customizeHint?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        customizeText?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        displayMode?: ChartLabelDisplayMode;
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: ChartsAxisLabelOverlap;
        position?: Position | RelativePosition;
        rotationAngle?: number;
        staggeringSpacing?: number;
        template?: ((data: {
            value: Date | number | string;
            valueText: string;
        }, element: any) => string | any) | template | undefined;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    };
    linearThreshold?: number | undefined;
    logarithmBase?: number;
    maxAutoBreakCount?: number;
    maxValueMargin?: number | undefined;
    minorGrid?: Record<string, any> | {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    minorTick?: Record<string, any> | {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    minorTickCount?: number | undefined;
    minorTickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    minValueMargin?: number | undefined;
    minVisualRangeLength?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    multipleAxesSpacing?: number;
    name?: string | undefined;
    offset?: number | undefined;
    opacity?: number | undefined;
    pane?: string | undefined;
    placeholderSize?: number;
    position?: Position;
    showZero?: boolean | undefined;
    strips?: Array<Record<string, any>> | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont;
            horizontalAlignment?: HorizontalAlignment;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        startValue?: Date | number | string | undefined;
    }[];
    stripStyle?: Record<string, any> | {
        label?: Record<string, any> | {
            font?: ChartsFont;
            horizontalAlignment?: HorizontalAlignment;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
    };
    synchronizedValue?: number | undefined;
    tick?: Record<string, any> | {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    tickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    title?: Record<string, any> | string | {
        alignment?: HorizontalAlignment;
        font?: ChartsFont;
        margin?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    type?: AxisScaleType | undefined;
    valueMarginsEnabled?: boolean;
    valueType?: ChartsDataType | undefined;
    visible?: boolean;
    visualRange?: Array<Date | number | string> | CommonChartTypes.VisualRange;
    visualRangeUpdateMode?: VisualRangeUpdateMode;
    wholeRange?: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
    width?: number;
    defaultCategories?: Array<Date | number | string>;
    onCategoriesChange?: (value: Array<Date | number | string>) => void;
    defaultVisualRange?: Array<Date | number | string> | CommonChartTypes.VisualRange;
    onVisualRangeChange?: (value: Array<Date | number | string> | CommonChartTypes.VisualRange) => void;
}>;
declare const ValueAxis: ((props: IValueAxisProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    aggregatedPointsPosition?: AggregatedPointsPosition | undefined;
    allowDecimals?: boolean | undefined;
    autoBreaksEnabled?: boolean | undefined;
    axisDivisionFactor?: number | undefined;
    breaks?: ScaleBreak[] | {
        endValue?: Date | number | string | undefined;
        startValue?: Date | number | string | undefined;
    }[] | undefined;
    breakStyle?: Record<string, any> | {
        color?: string | undefined;
        line?: ScaleBreakLineStyle | undefined;
        width?: number | undefined;
    } | undefined;
    categories?: (string | number | Date)[] | undefined;
    color?: string | undefined;
    constantLines?: Record<string, any>[] | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        displayBehindSeries?: boolean | undefined;
        extendAxis?: boolean | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            horizontalAlignment?: HorizontalAlignment | undefined;
            position?: RelativePosition | undefined;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment | undefined;
            visible?: boolean | undefined;
        } | undefined;
        paddingLeftRight?: number | undefined;
        paddingTopBottom?: number | undefined;
        value?: Date | number | string | undefined;
        width?: number | undefined;
    }[] | undefined;
    constantLineStyle?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            horizontalAlignment?: HorizontalAlignment | undefined;
            position?: RelativePosition | undefined;
            verticalAlignment?: VerticalAlignment | undefined;
            visible?: boolean | undefined;
        } | undefined;
        paddingLeftRight?: number | undefined;
        paddingTopBottom?: number | undefined;
        width?: number | undefined;
    } | undefined;
    customPosition?: Date | number | string | undefined;
    discreteAxisDivisionMode?: DiscreteAxisDivisionMode | undefined;
    endOnTick?: boolean | undefined;
    grid?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    inverted?: boolean | undefined;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        customizeHint?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string) | undefined;
        customizeText?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string) | undefined;
        displayMode?: ChartLabelDisplayMode | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        indentFromAxis?: number | undefined;
        overlappingBehavior?: ChartsAxisLabelOverlap | undefined;
        position?: Position | RelativePosition | undefined;
        rotationAngle?: number | undefined;
        staggeringSpacing?: number | undefined;
        template?: template | ((data: {
            value: Date | number | string;
            valueText: string;
        }, element: any) => string | any) | undefined;
        textOverflow?: TextOverflow | undefined;
        visible?: boolean | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    linearThreshold?: number | undefined;
    logarithmBase?: number | undefined;
    maxAutoBreakCount?: number | undefined;
    maxValueMargin?: number | undefined;
    minorGrid?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    minorTick?: Record<string, any> | {
        color?: string | undefined;
        length?: number | undefined;
        opacity?: number | undefined;
        shift?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    minorTickCount?: number | undefined;
    minorTickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number | undefined;
        hours?: number | undefined;
        milliseconds?: number | undefined;
        minutes?: number | undefined;
        months?: number | undefined;
        quarters?: number | undefined;
        seconds?: number | undefined;
        weeks?: number | undefined;
        years?: number | undefined;
    } | undefined;
    minValueMargin?: number | undefined;
    minVisualRangeLength?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    multipleAxesSpacing?: number | undefined;
    name?: string | undefined;
    offset?: number | undefined;
    opacity?: number | undefined;
    pane?: string | undefined;
    placeholderSize?: number | undefined;
    position?: Position | undefined;
    showZero?: boolean | undefined;
    strips?: Record<string, any>[] | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            horizontalAlignment?: HorizontalAlignment | undefined;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment | undefined;
        } | undefined;
        paddingLeftRight?: number | undefined;
        paddingTopBottom?: number | undefined;
        startValue?: Date | number | string | undefined;
    }[] | undefined;
    stripStyle?: Record<string, any> | {
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            horizontalAlignment?: HorizontalAlignment | undefined;
            verticalAlignment?: VerticalAlignment | undefined;
        } | undefined;
        paddingLeftRight?: number | undefined;
        paddingTopBottom?: number | undefined;
    } | undefined;
    synchronizedValue?: number | undefined;
    tick?: Record<string, any> | {
        color?: string | undefined;
        length?: number | undefined;
        opacity?: number | undefined;
        shift?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    tickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number | undefined;
        hours?: number | undefined;
        milliseconds?: number | undefined;
        minutes?: number | undefined;
        months?: number | undefined;
        quarters?: number | undefined;
        seconds?: number | undefined;
        weeks?: number | undefined;
        years?: number | undefined;
    } | undefined;
    title?: string | Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        font?: ChartsFont | undefined;
        margin?: number | undefined;
        text?: string | undefined;
        textOverflow?: TextOverflow | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    type?: AxisScaleType | undefined;
    valueMarginsEnabled?: boolean | undefined;
    valueType?: ChartsDataType | undefined;
    visible?: boolean | undefined;
    visualRange?: (string | number | Date)[] | CommonChartTypes.VisualRange | undefined;
    visualRangeUpdateMode?: VisualRangeUpdateMode | undefined;
    wholeRange?: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
    width?: number | undefined;
    defaultCategories?: (string | number | Date)[] | undefined;
    onCategoriesChange?: ((value: Array<Date | number | string>) => void) | undefined;
    defaultVisualRange?: (string | number | Date)[] | CommonChartTypes.VisualRange | undefined;
    onVisualRangeChange?: ((value: Array<Date | number | string> | CommonChartTypes.VisualRange) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IValueErrorBarProps = React.PropsWithChildren<{
    color?: string;
    displayMode?: ValueErrorBarDisplayMode;
    edgeLength?: number;
    highValueField?: string | undefined;
    lineWidth?: number;
    lowValueField?: string | undefined;
    opacity?: number | undefined;
    type?: undefined | ValueErrorBarType;
    value?: number;
}>;
declare const ValueErrorBar: ((props: IValueErrorBarProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    displayMode?: ValueErrorBarDisplayMode | undefined;
    edgeLength?: number | undefined;
    highValueField?: string | undefined;
    lineWidth?: number | undefined;
    lowValueField?: string | undefined;
    opacity?: number | undefined;
    type?: undefined | ValueErrorBarType;
    value?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IVerticalLineProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    label?: Record<string, any> | {
        backgroundColor?: string;
        customizeText?: ((info: {
            point: chartPointObject;
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        visible?: boolean;
    };
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const VerticalLine: ((props: IVerticalLineProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    label?: Record<string, any> | {
        backgroundColor?: string | undefined;
        customizeText?: ((info: {
            point: chartPointObject;
            value: Date | number | string;
            valueText: string;
        }) => string) | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        visible?: boolean | undefined;
    } | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IVisualRangeProps = React.PropsWithChildren<{
    endValue?: Date | number | string | undefined;
    length?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    startValue?: Date | number | string | undefined;
    defaultEndValue?: Date | number | string | undefined;
    onEndValueChange?: (value: Date | number | string | undefined) => void;
    defaultStartValue?: Date | number | string | undefined;
    onStartValueChange?: (value: Date | number | string | undefined) => void;
}>;
declare const VisualRange: ((props: IVisualRangeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    endValue?: Date | number | string | undefined;
    length?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    startValue?: Date | number | string | undefined;
    defaultEndValue?: Date | number | string | undefined;
    onEndValueChange?: ((value: Date | number | string | undefined) => void) | undefined;
    defaultStartValue?: Date | number | string | undefined;
    onStartValueChange?: ((value: Date | number | string | undefined) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IWholeRangeProps = React.PropsWithChildren<{
    endValue?: Date | number | string | undefined;
    length?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    startValue?: Date | number | string | undefined;
    defaultEndValue?: Date | number | string | undefined;
    onEndValueChange?: (value: Date | number | string | undefined) => void;
    defaultStartValue?: Date | number | string | undefined;
    onStartValueChange?: (value: Date | number | string | undefined) => void;
}>;
declare const WholeRange: ((props: IWholeRangeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    endValue?: Date | number | string | undefined;
    length?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    startValue?: Date | number | string | undefined;
    defaultEndValue?: Date | number | string | undefined;
    onEndValueChange?: ((value: Date | number | string | undefined) => void) | undefined;
    defaultStartValue?: Date | number | string | undefined;
    onStartValueChange?: ((value: Date | number | string | undefined) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IWidthProps = React.PropsWithChildren<{
    rangeMaxPoint?: number | undefined;
    rangeMinPoint?: number | undefined;
}>;
declare const Width: ((props: IWidthProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    rangeMaxPoint?: number | undefined;
    rangeMinPoint?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IZoomAndPanProps = React.PropsWithChildren<{
    allowMouseWheel?: boolean;
    allowTouchGestures?: boolean;
    argumentAxis?: ChartZoomAndPanMode;
    dragBoxStyle?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
    };
    dragToZoom?: boolean;
    panKey?: EventKeyModifier;
    valueAxis?: ChartZoomAndPanMode;
}>;
declare const ZoomAndPan: ((props: IZoomAndPanProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowMouseWheel?: boolean | undefined;
    allowTouchGestures?: boolean | undefined;
    argumentAxis?: ChartZoomAndPanMode | undefined;
    dragBoxStyle?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
    } | undefined;
    dragToZoom?: boolean | undefined;
    panKey?: EventKeyModifier | undefined;
    valueAxis?: ChartZoomAndPanMode | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default Chart;
export { Chart, IChartOptions, ChartRef, AdaptiveLayout, IAdaptiveLayoutProps, Aggregation, IAggregationProps, AggregationInterval, IAggregationIntervalProps, Animation, IAnimationProps, Annotation, IAnnotationProps, AnnotationBorder, IAnnotationBorderProps, AnnotationImage, IAnnotationImageProps, ArgumentAxis, IArgumentAxisProps, ArgumentFormat, IArgumentFormatProps, AxisConstantLineStyle, IAxisConstantLineStyleProps, AxisConstantLineStyleLabel, IAxisConstantLineStyleLabelProps, AxisLabel, IAxisLabelProps, AxisTitle, IAxisTitleProps, BackgroundColor, IBackgroundColorProps, Border, IBorderProps, Break, IBreakProps, BreakStyle, IBreakStyleProps, ChartTitle, IChartTitleProps, ChartTitleSubtitle, IChartTitleSubtitleProps, Color, IColorProps, CommonAnnotationSettings, ICommonAnnotationSettingsProps, CommonAxisSettings, ICommonAxisSettingsProps, CommonAxisSettingsConstantLineStyle, ICommonAxisSettingsConstantLineStyleProps, CommonAxisSettingsConstantLineStyleLabel, ICommonAxisSettingsConstantLineStyleLabelProps, CommonAxisSettingsLabel, ICommonAxisSettingsLabelProps, CommonAxisSettingsTitle, ICommonAxisSettingsTitleProps, CommonPaneSettings, ICommonPaneSettingsProps, CommonSeriesSettings, ICommonSeriesSettingsProps, CommonSeriesSettingsHoverStyle, ICommonSeriesSettingsHoverStyleProps, CommonSeriesSettingsLabel, ICommonSeriesSettingsLabelProps, CommonSeriesSettingsSelectionStyle, ICommonSeriesSettingsSelectionStyleProps, Connector, IConnectorProps, ConstantLine, IConstantLineProps, ConstantLineLabel, IConstantLineLabelProps, ConstantLineStyle, IConstantLineStyleProps, Crosshair, ICrosshairProps, DataPrepareSettings, IDataPrepareSettingsProps, DragBoxStyle, IDragBoxStyleProps, Export, IExportProps, Font, IFontProps, Format, IFormatProps, Grid, IGridProps, Hatching, IHatchingProps, Height, IHeightProps, HorizontalLine, IHorizontalLineProps, HorizontalLineLabel, IHorizontalLineLabelProps, HoverStyle, IHoverStyleProps, Image, IImageProps, Label, ILabelProps, Legend, ILegendProps, LegendTitle, ILegendTitleProps, LegendTitleSubtitle, ILegendTitleSubtitleProps, Length, ILengthProps, LoadingIndicator, ILoadingIndicatorProps, Margin, IMarginProps, MinorGrid, IMinorGridProps, MinorTick, IMinorTickProps, MinorTickInterval, IMinorTickIntervalProps, MinVisualRangeLength, IMinVisualRangeLengthProps, Pane, IPaneProps, PaneBorder, IPaneBorderProps, Point, IPointProps, PointBorder, IPointBorderProps, PointHoverStyle, IPointHoverStyleProps, PointImage, IPointImageProps, PointSelectionStyle, IPointSelectionStyleProps, Reduction, IReductionProps, ScrollBar, IScrollBarProps, SelectionStyle, ISelectionStyleProps, Series, ISeriesProps, SeriesBorder, ISeriesBorderProps, SeriesTemplate, ISeriesTemplateProps, Shadow, IShadowProps, Size, ISizeProps, Strip, IStripProps, StripLabel, IStripLabelProps, StripStyle, IStripStyleProps, StripStyleLabel, IStripStyleLabelProps, Subtitle, ISubtitleProps, Tick, ITickProps, TickInterval, ITickIntervalProps, Title, ITitleProps, Tooltip, ITooltipProps, TooltipBorder, ITooltipBorderProps, Url, IUrlProps, ValueAxis, IValueAxisProps, ValueErrorBar, IValueErrorBarProps, VerticalLine, IVerticalLineProps, VisualRange, IVisualRangeProps, WholeRange, IWholeRangeProps, Width, IWidthProps, ZoomAndPan, IZoomAndPanProps };
import type * as ChartTypes from 'devextreme/viz/chart_types';
export { ChartTypes };
