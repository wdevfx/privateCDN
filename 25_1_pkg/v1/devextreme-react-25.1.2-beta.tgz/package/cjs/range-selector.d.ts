/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxRangeSelector, { Properties } from "devextreme/viz/range_selector";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { DisposingEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, ValueChangedEvent, BackgroundImageLocation, ValueChangedCallMode, ChartAxisScale, AxisScale } from "devextreme/viz/range_selector";
import type { chartPointAggregationInfoObject, chartSeriesObject, ChartSeriesAggregationMethod, dxChartCommonSeriesSettings, FinancialChartReductionLevel } from "devextreme/viz/chart";
import type { Format as CommonFormat, SliderValueChangeMode, HorizontalAlignment, ExportFormat, VerticalEdge } from "devextreme/common";
import type { Format as LocalizationFormat } from "devextreme/common/core/localization";
import type { DashStyle, ScaleBreakLineStyle, Palette, PaletteExtensionMode, ChartsDataType, ChartsColor, SeriesHoverMode, HatchDirection, Font as ChartsFont, RelativePosition, PointInteractionMode, PointSymbol, SeriesSelectionMode, SeriesType, ValueErrorBarDisplayMode, ValueErrorBarType, LabelOverlap, TimeInterval, ScaleBreak, DiscreteAxisDivisionMode, TextOverflow, WordWrap } from "devextreme/common/charts";
import type { ChartSeries } from "devextreme/viz/common";
import type * as CommonChartTypes from "devextreme/common/charts";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IRangeSelectorOptionsNarrowedEvents = {
    onDisposing?: ((e: DisposingEvent) => void);
    onDrawn?: ((e: DrawnEvent) => void);
    onExported?: ((e: ExportedEvent) => void);
    onExporting?: ((e: ExportingEvent) => void);
    onFileSaving?: ((e: FileSavingEvent) => void);
    onIncidentOccurred?: ((e: IncidentOccurredEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onValueChanged?: ((e: ValueChangedEvent) => void);
};
type IRangeSelectorOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IRangeSelectorOptionsNarrowedEvents> & IHtmlOptions & {
    defaultLoadingIndicator?: Record<string, any>;
    defaultValue?: Array<Date | number | string> | CommonChartTypes.VisualRange;
    onLoadingIndicatorChange?: (value: Record<string, any>) => void;
    onValueChange?: (value: Array<Date | number | string> | CommonChartTypes.VisualRange) => void;
}>;
interface RangeSelectorRef {
    instance: () => dxRangeSelector;
}
declare const RangeSelector: (props: React.PropsWithChildren<IRangeSelectorOptions> & {
    ref?: Ref<RangeSelectorRef>;
}) => ReactElement | null;
type IAggregationProps = React.PropsWithChildren<{
    calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
    enabled?: boolean;
    method?: ChartSeriesAggregationMethod;
}>;
declare const Aggregation: ((props: IAggregationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
    enabled?: boolean | undefined;
    method?: ChartSeriesAggregationMethod | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAggregationIntervalProps = React.PropsWithChildren<{
    days?: number;
    hours?: number;
    milliseconds?: number;
    minutes?: number;
    months?: number;
    quarters?: number;
    seconds?: number;
    weeks?: number;
    years?: number;
}>;
declare const AggregationInterval: ((props: IAggregationIntervalProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    days?: number | undefined;
    hours?: number | undefined;
    milliseconds?: number | undefined;
    minutes?: number | undefined;
    months?: number | undefined;
    quarters?: number | undefined;
    seconds?: number | undefined;
    weeks?: number | undefined;
    years?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IArgumentFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const ArgumentFormat: ((props: IArgumentFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBackgroundProps = React.PropsWithChildren<{
    color?: string;
    image?: Record<string, any> | {
        location?: BackgroundImageLocation;
        url?: string | undefined;
    };
    visible?: boolean;
}>;
declare const Background: ((props: IBackgroundProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    image?: Record<string, any> | {
        location?: BackgroundImageLocation | undefined;
        url?: string | undefined;
    } | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBackgroundImageProps = React.PropsWithChildren<{
    location?: BackgroundImageLocation;
    url?: string | undefined;
}>;
declare const BackgroundImage: ((props: IBackgroundImageProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    location?: BackgroundImageLocation | undefined;
    url?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBehaviorProps = React.PropsWithChildren<{
    allowSlidersSwap?: boolean;
    animationEnabled?: boolean;
    callValueChanged?: ValueChangedCallMode;
    manualRangeSelectionEnabled?: boolean;
    moveSelectedRangeByClick?: boolean;
    snapToTicks?: boolean;
    valueChangeMode?: SliderValueChangeMode;
}>;
declare const Behavior: ((props: IBehaviorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowSlidersSwap?: boolean | undefined;
    animationEnabled?: boolean | undefined;
    callValueChanged?: ValueChangedCallMode | undefined;
    manualRangeSelectionEnabled?: boolean | undefined;
    moveSelectedRangeByClick?: boolean | undefined;
    snapToTicks?: boolean | undefined;
    valueChangeMode?: SliderValueChangeMode | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBorderProps = React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const Border: ((props: IBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBreakProps = React.PropsWithChildren<{
    endValue?: Date | number | string | undefined;
    startValue?: Date | number | string | undefined;
}>;
declare const Break: ((props: IBreakProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    endValue?: Date | number | string | undefined;
    startValue?: Date | number | string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBreakStyleProps = React.PropsWithChildren<{
    color?: string;
    line?: ScaleBreakLineStyle;
    width?: number;
}>;
declare const BreakStyle: ((props: IBreakStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    line?: ScaleBreakLineStyle | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IChartProps = React.PropsWithChildren<{
    barGroupPadding?: number;
    barGroupWidth?: number | undefined;
    bottomIndent?: number;
    commonSeriesSettings?: dxChartCommonSeriesSettings;
    dataPrepareSettings?: Record<string, any> | {
        checkTypeForAllData?: boolean;
        convertToAxisDataType?: boolean;
        sortingMethod?: boolean | ((a: {
            arg: Date | number | string;
            val: Date | number | string;
        }, b: {
            arg: Date | number | string;
            val: Date | number | string;
        }) => number);
    };
    maxBubbleSize?: number;
    minBubbleSize?: number;
    negativesAsZeroes?: boolean;
    palette?: Array<string> | Palette;
    paletteExtensionMode?: PaletteExtensionMode;
    series?: Array<ChartSeries> | ChartSeries | undefined;
    seriesTemplate?: Record<string, any> | {
        customizeSeries?: ((seriesName: any) => ChartSeries);
        nameField?: string;
    };
    topIndent?: number;
    valueAxis?: Record<string, any> | {
        inverted?: boolean;
        logarithmBase?: number;
        max?: number | undefined;
        min?: number | undefined;
        type?: ChartAxisScale | undefined;
        valueType?: ChartsDataType | undefined;
    };
}>;
declare const Chart: ((props: IChartProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    barGroupPadding?: number | undefined;
    barGroupWidth?: number | undefined;
    bottomIndent?: number | undefined;
    commonSeriesSettings?: import("devextreme/viz/chart").CommonSeriesSettings | undefined;
    dataPrepareSettings?: Record<string, any> | {
        checkTypeForAllData?: boolean | undefined;
        convertToAxisDataType?: boolean | undefined;
        sortingMethod?: boolean | ((a: {
            arg: Date | number | string;
            val: Date | number | string;
        }, b: {
            arg: Date | number | string;
            val: Date | number | string;
        }) => number) | undefined;
    } | undefined;
    maxBubbleSize?: number | undefined;
    minBubbleSize?: number | undefined;
    negativesAsZeroes?: boolean | undefined;
    palette?: string[] | Palette | undefined;
    paletteExtensionMode?: PaletteExtensionMode | undefined;
    series?: Array<ChartSeries> | ChartSeries | undefined;
    seriesTemplate?: Record<string, any> | {
        customizeSeries?: ((seriesName: any) => ChartSeries) | undefined;
        nameField?: string | undefined;
    } | undefined;
    topIndent?: number | undefined;
    valueAxis?: Record<string, any> | {
        inverted?: boolean | undefined;
        logarithmBase?: number | undefined;
        max?: number | undefined;
        min?: number | undefined;
        type?: ChartAxisScale | undefined;
        valueType?: ChartsDataType | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColorProps = React.PropsWithChildren<{
    base?: string | undefined;
    fillId?: string | undefined;
}>;
declare const Color: ((props: IColorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    base?: string | undefined;
    fillId?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonSeriesSettingsProps = React.PropsWithChildren<{
    aggregation?: Record<string, any> | {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    };
    area?: any;
    argumentField?: string;
    axis?: string | undefined;
    bar?: any;
    barOverlapGroup?: string | undefined;
    barPadding?: number | undefined;
    barWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    bubble?: any;
    candlestick?: any;
    closeValueField?: string;
    color?: ChartsColor | string | undefined;
    cornerRadius?: number;
    dashStyle?: DashStyle;
    fullstackedarea?: any;
    fullstackedbar?: any;
    fullstackedline?: any;
    fullstackedspline?: any;
    fullstackedsplinearea?: any;
    highValueField?: string;
    hoverMode?: SeriesHoverMode;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    ignoreEmptyPoints?: boolean;
    innerColor?: string;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment;
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    };
    line?: any;
    lowValueField?: string;
    maxLabelCount?: number | undefined;
    minBarSize?: number | undefined;
    opacity?: number;
    openValueField?: string;
    pane?: string;
    point?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: Record<string, any> | string | undefined | {
            height?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: Record<string, any> | string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    };
    rangearea?: any;
    rangebar?: any;
    rangeValue1Field?: string;
    rangeValue2Field?: string;
    reduction?: Record<string, any> | {
        color?: string;
        level?: FinancialChartReductionLevel;
    };
    scatter?: any;
    selectionMode?: SeriesSelectionMode;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    showInLegend?: boolean;
    sizeField?: string;
    spline?: any;
    splinearea?: any;
    stack?: string;
    stackedarea?: any;
    stackedbar?: any;
    stackedline?: any;
    stackedspline?: any;
    stackedsplinearea?: any;
    steparea?: any;
    stepline?: any;
    stock?: any;
    tagField?: string;
    type?: SeriesType;
    valueErrorBar?: Record<string, any> | {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    };
    valueField?: string;
    visible?: boolean;
    width?: number;
}>;
declare const CommonSeriesSettings: ((props: ICommonSeriesSettingsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    aggregation?: Record<string, any> | {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean | undefined;
        method?: ChartSeriesAggregationMethod | undefined;
    } | undefined;
    area?: any;
    argumentField?: string | undefined;
    axis?: string | undefined;
    bar?: any;
    barOverlapGroup?: string | undefined;
    barPadding?: number | undefined;
    barWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    bubble?: any;
    candlestick?: any;
    closeValueField?: string | undefined;
    color?: ChartsColor | string | undefined;
    cornerRadius?: number | undefined;
    dashStyle?: DashStyle | undefined;
    fullstackedarea?: any;
    fullstackedbar?: any;
    fullstackedline?: any;
    fullstackedspline?: any;
    fullstackedsplinearea?: any;
    highValueField?: string | undefined;
    hoverMode?: SeriesHoverMode | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    ignoreEmptyPoints?: boolean | undefined;
    innerColor?: string | undefined;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        customizeText?: ((pointInfo: any) => string) | undefined;
        displayFormat?: string | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        horizontalOffset?: number | undefined;
        position?: RelativePosition | undefined;
        rotationAngle?: number | undefined;
        showForZeroValues?: boolean | undefined;
        verticalOffset?: number | undefined;
        visible?: boolean | undefined;
    } | undefined;
    line?: any;
    lowValueField?: string | undefined;
    maxLabelCount?: number | undefined;
    minBarSize?: number | undefined;
    opacity?: number | undefined;
    openValueField?: string | undefined;
    pane?: string | undefined;
    point?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode | undefined;
        hoverStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            } | undefined;
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        } | undefined;
        image?: Record<string, any> | string | undefined | {
            height?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: Record<string, any> | string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode | undefined;
        selectionStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            } | undefined;
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        } | undefined;
        size?: number | undefined;
        symbol?: PointSymbol | undefined;
        visible?: boolean | undefined;
    } | undefined;
    rangearea?: any;
    rangebar?: any;
    rangeValue1Field?: string | undefined;
    rangeValue2Field?: string | undefined;
    reduction?: Record<string, any> | {
        color?: string | undefined;
        level?: FinancialChartReductionLevel | undefined;
    } | undefined;
    scatter?: any;
    selectionMode?: SeriesSelectionMode | undefined;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    showInLegend?: boolean | undefined;
    sizeField?: string | undefined;
    spline?: any;
    splinearea?: any;
    stack?: string | undefined;
    stackedarea?: any;
    stackedbar?: any;
    stackedline?: any;
    stackedspline?: any;
    stackedsplinearea?: any;
    steparea?: any;
    stepline?: any;
    stock?: any;
    tagField?: string | undefined;
    type?: SeriesType | undefined;
    valueErrorBar?: Record<string, any> | {
        color?: string | undefined;
        displayMode?: ValueErrorBarDisplayMode | undefined;
        edgeLength?: number | undefined;
        highValueField?: string | undefined;
        lineWidth?: number | undefined;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number | undefined;
    } | undefined;
    valueField?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonSeriesSettingsHoverStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle;
    hatching?: Record<string, any> | {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    highlight?: boolean;
    width?: number;
}>;
declare const CommonSeriesSettingsHoverStyle: ((props: ICommonSeriesSettingsHoverStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection | undefined;
        opacity?: number | undefined;
        step?: number | undefined;
        width?: number | undefined;
    } | undefined;
    highlight?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonSeriesSettingsLabelProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment;
    argumentFormat?: LocalizationFormat | undefined;
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    connector?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    customizeText?: ((pointInfo: any) => string);
    displayFormat?: string | undefined;
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    horizontalOffset?: number;
    position?: RelativePosition;
    rotationAngle?: number;
    showForZeroValues?: boolean;
    verticalOffset?: number;
    visible?: boolean;
}>;
declare const CommonSeriesSettingsLabel: ((props: ICommonSeriesSettingsLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    argumentFormat?: LocalizationFormat | undefined;
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    connector?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    customizeText?: ((pointInfo: any) => string) | undefined;
    displayFormat?: string | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    horizontalOffset?: number | undefined;
    position?: RelativePosition | undefined;
    rotationAngle?: number | undefined;
    showForZeroValues?: boolean | undefined;
    verticalOffset?: number | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonSeriesSettingsSelectionStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle;
    hatching?: Record<string, any> | {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    highlight?: boolean;
    width?: number;
}>;
declare const CommonSeriesSettingsSelectionStyle: ((props: ICommonSeriesSettingsSelectionStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection | undefined;
        opacity?: number | undefined;
        step?: number | undefined;
        width?: number | undefined;
    } | undefined;
    highlight?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IConnectorProps = React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const Connector: ((props: IConnectorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IDataPrepareSettingsProps = React.PropsWithChildren<{
    checkTypeForAllData?: boolean;
    convertToAxisDataType?: boolean;
    sortingMethod?: boolean | ((a: {
        arg: Date | number | string;
        val: Date | number | string;
    }, b: {
        arg: Date | number | string;
        val: Date | number | string;
    }) => number);
}>;
declare const DataPrepareSettings: ((props: IDataPrepareSettingsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    checkTypeForAllData?: boolean | undefined;
    convertToAxisDataType?: boolean | undefined;
    sortingMethod?: boolean | ((a: {
        arg: Date | number | string;
        val: Date | number | string;
    }, b: {
        arg: Date | number | string;
        val: Date | number | string;
    }) => number) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IExportProps = React.PropsWithChildren<{
    backgroundColor?: string;
    enabled?: boolean;
    fileName?: string;
    formats?: Array<ExportFormat>;
    margin?: number;
    printingEnabled?: boolean;
    svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
}>;
declare const Export: ((props: IExportProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    enabled?: boolean | undefined;
    fileName?: string | undefined;
    formats?: ExportFormat[] | undefined;
    margin?: number | undefined;
    printingEnabled?: boolean | undefined;
    svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFontProps = React.PropsWithChildren<{
    color?: string;
    family?: string;
    opacity?: number;
    size?: number | string;
    weight?: number;
}>;
declare const Font: ((props: IFontProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    family?: string | undefined;
    opacity?: number | undefined;
    size?: string | number | undefined;
    weight?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const Format: ((props: IFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHatchingProps = React.PropsWithChildren<{
    direction?: HatchDirection;
    opacity?: number;
    step?: number;
    width?: number;
}>;
declare const Hatching: ((props: IHatchingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    direction?: HatchDirection | undefined;
    opacity?: number | undefined;
    step?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHeightProps = React.PropsWithChildren<{
    rangeMaxPoint?: number | undefined;
    rangeMinPoint?: number | undefined;
}>;
declare const Height: ((props: IHeightProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    rangeMaxPoint?: number | undefined;
    rangeMinPoint?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHoverStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle;
    hatching?: Record<string, any> | {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    highlight?: boolean;
    width?: number;
    size?: number | undefined;
}>;
declare const HoverStyle: ((props: IHoverStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection | undefined;
        opacity?: number | undefined;
        step?: number | undefined;
        width?: number | undefined;
    } | undefined;
    highlight?: boolean | undefined;
    width?: number | undefined;
    size?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IImageProps = React.PropsWithChildren<{
    location?: BackgroundImageLocation;
    url?: string | undefined | Record<string, any> | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    };
    height?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
    width?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
}>;
declare const Image: ((props: IImageProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    location?: BackgroundImageLocation | undefined;
    url?: string | undefined | Record<string, any> | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    };
    height?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    } | undefined;
    width?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IIndentProps = React.PropsWithChildren<{
    left?: number | undefined;
    right?: number | undefined;
}>;
declare const Indent: ((props: IIndentProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    left?: number | undefined;
    right?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILabelProps = React.PropsWithChildren<{
    alignment?: HorizontalAlignment;
    argumentFormat?: LocalizationFormat | undefined;
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    connector?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    customizeText?: ((pointInfo: any) => string);
    displayFormat?: string | undefined;
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    horizontalOffset?: number;
    position?: RelativePosition;
    rotationAngle?: number;
    showForZeroValues?: boolean;
    verticalOffset?: number;
    visible?: boolean;
    overlappingBehavior?: LabelOverlap;
    topIndent?: number;
}>;
declare const Label: ((props: ILabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    alignment?: HorizontalAlignment | undefined;
    argumentFormat?: LocalizationFormat | undefined;
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    connector?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    customizeText?: ((pointInfo: any) => string) | undefined;
    displayFormat?: string | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    horizontalOffset?: number | undefined;
    position?: RelativePosition | undefined;
    rotationAngle?: number | undefined;
    showForZeroValues?: boolean | undefined;
    verticalOffset?: number | undefined;
    visible?: boolean | undefined;
    overlappingBehavior?: LabelOverlap | undefined;
    topIndent?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILengthProps = React.PropsWithChildren<{
    days?: number;
    hours?: number;
    milliseconds?: number;
    minutes?: number;
    months?: number;
    quarters?: number;
    seconds?: number;
    weeks?: number;
    years?: number;
}>;
declare const Length: ((props: ILengthProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    days?: number | undefined;
    hours?: number | undefined;
    milliseconds?: number | undefined;
    minutes?: number | undefined;
    months?: number | undefined;
    quarters?: number | undefined;
    seconds?: number | undefined;
    weeks?: number | undefined;
    years?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILoadingIndicatorProps = React.PropsWithChildren<{
    backgroundColor?: string;
    enabled?: boolean;
    font?: ChartsFont;
    show?: boolean;
    text?: string;
    defaultShow?: boolean;
    onShowChange?: (value: boolean) => void;
}>;
declare const LoadingIndicator: ((props: ILoadingIndicatorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    enabled?: boolean | undefined;
    font?: ChartsFont | undefined;
    show?: boolean | undefined;
    text?: string | undefined;
    defaultShow?: boolean | undefined;
    onShowChange?: ((value: boolean) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMarginProps = React.PropsWithChildren<{
    bottom?: number;
    left?: number;
    right?: number;
    top?: number;
}>;
declare const Margin: ((props: IMarginProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    bottom?: number | undefined;
    left?: number | undefined;
    right?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMarkerProps = React.PropsWithChildren<{
    label?: Record<string, any> | {
        customizeText?: ((markerValue: {
            value: Date | number;
            valueText: string;
        }) => string);
        format?: LocalizationFormat | undefined;
    };
    separatorHeight?: number;
    textLeftIndent?: number;
    textTopIndent?: number;
    topIndent?: number;
    visible?: boolean;
}>;
declare const Marker: ((props: IMarkerProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    label?: Record<string, any> | {
        customizeText?: ((markerValue: {
            value: Date | number;
            valueText: string;
        }) => string) | undefined;
        format?: LocalizationFormat | undefined;
    } | undefined;
    separatorHeight?: number | undefined;
    textLeftIndent?: number | undefined;
    textTopIndent?: number | undefined;
    topIndent?: number | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMarkerLabelProps = React.PropsWithChildren<{
    customizeText?: ((markerValue: {
        value: Date | number;
        valueText: string;
    }) => string);
    format?: LocalizationFormat | undefined;
}>;
declare const MarkerLabel: ((props: IMarkerLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    customizeText?: ((markerValue: {
        value: Date | number;
        valueText: string;
    }) => string) | undefined;
    format?: LocalizationFormat | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMaxRangeProps = React.PropsWithChildren<{
    days?: number;
    hours?: number;
    milliseconds?: number;
    minutes?: number;
    months?: number;
    quarters?: number;
    seconds?: number;
    weeks?: number;
    years?: number;
}>;
declare const MaxRange: ((props: IMaxRangeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    days?: number | undefined;
    hours?: number | undefined;
    milliseconds?: number | undefined;
    minutes?: number | undefined;
    months?: number | undefined;
    quarters?: number | undefined;
    seconds?: number | undefined;
    weeks?: number | undefined;
    years?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMinorTickProps = React.PropsWithChildren<{
    color?: string;
    opacity?: number;
    visible?: boolean;
    width?: number;
}>;
declare const MinorTick: ((props: IMinorTickProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMinorTickIntervalProps = React.PropsWithChildren<{
    days?: number;
    hours?: number;
    milliseconds?: number;
    minutes?: number;
    months?: number;
    quarters?: number;
    seconds?: number;
    weeks?: number;
    years?: number;
}>;
declare const MinorTickInterval: ((props: IMinorTickIntervalProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    days?: number | undefined;
    hours?: number | undefined;
    milliseconds?: number | undefined;
    minutes?: number | undefined;
    months?: number | undefined;
    quarters?: number | undefined;
    seconds?: number | undefined;
    weeks?: number | undefined;
    years?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMinRangeProps = React.PropsWithChildren<{
    days?: number;
    hours?: number;
    milliseconds?: number;
    minutes?: number;
    months?: number;
    quarters?: number;
    seconds?: number;
    weeks?: number;
    years?: number;
}>;
declare const MinRange: ((props: IMinRangeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    days?: number | undefined;
    hours?: number | undefined;
    milliseconds?: number | undefined;
    minutes?: number | undefined;
    months?: number | undefined;
    quarters?: number | undefined;
    seconds?: number | undefined;
    weeks?: number | undefined;
    years?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPointProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    hoverMode?: PointInteractionMode;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    };
    image?: Record<string, any> | string | undefined | {
        height?: number | Record<string, any> | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
        url?: Record<string, any> | string | undefined | {
            rangeMaxPoint?: string | undefined;
            rangeMinPoint?: string | undefined;
        };
        width?: number | Record<string, any> | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
    };
    selectionMode?: PointInteractionMode;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    };
    size?: number;
    symbol?: PointSymbol;
    visible?: boolean;
}>;
declare const Point: ((props: IPointProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    hoverMode?: PointInteractionMode | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    } | undefined;
    image?: Record<string, any> | string | undefined | {
        height?: number | Record<string, any> | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
        url?: Record<string, any> | string | undefined | {
            rangeMaxPoint?: string | undefined;
            rangeMinPoint?: string | undefined;
        };
        width?: number | Record<string, any> | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
    };
    selectionMode?: PointInteractionMode | undefined;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    } | undefined;
    size?: number | undefined;
    symbol?: PointSymbol | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPointBorderProps = React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const PointBorder: ((props: IPointBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPointHoverStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    size?: number | undefined;
}>;
declare const PointHoverStyle: ((props: IPointHoverStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    size?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPointImageProps = React.PropsWithChildren<{
    height?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
    url?: Record<string, any> | string | undefined | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    };
    width?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
}>;
declare const PointImage: ((props: IPointImageProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    } | undefined;
    url?: Record<string, any> | string | undefined | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    };
    width?: number | Record<string, any> | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPointSelectionStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    size?: number | undefined;
}>;
declare const PointSelectionStyle: ((props: IPointSelectionStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    size?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IReductionProps = React.PropsWithChildren<{
    color?: string;
    level?: FinancialChartReductionLevel;
}>;
declare const Reduction: ((props: IReductionProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    level?: FinancialChartReductionLevel | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IScaleProps = React.PropsWithChildren<{
    aggregateByCategory?: boolean;
    aggregationGroupWidth?: number | undefined;
    aggregationInterval?: number | Record<string, any> | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    allowDecimals?: boolean | undefined;
    breaks?: Array<ScaleBreak> | {
        endValue?: Date | number | string | undefined;
        startValue?: Date | number | string | undefined;
    }[];
    breakStyle?: Record<string, any> | {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    };
    categories?: Array<Date | number | string>;
    discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
    endOnTick?: boolean;
    endValue?: Date | number | string | undefined;
    holidays?: Array<Date | string> | Array<number>;
    label?: Record<string, any> | {
        customizeText?: ((scaleValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        overlappingBehavior?: LabelOverlap;
        topIndent?: number;
        visible?: boolean;
    };
    linearThreshold?: number;
    logarithmBase?: number;
    marker?: Record<string, any> | {
        label?: Record<string, any> | {
            customizeText?: ((markerValue: {
                value: Date | number;
                valueText: string;
            }) => string);
            format?: LocalizationFormat | undefined;
        };
        separatorHeight?: number;
        textLeftIndent?: number;
        textTopIndent?: number;
        topIndent?: number;
        visible?: boolean;
    };
    maxRange?: number | Record<string, any> | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    minorTick?: Record<string, any> | {
        color?: string;
        opacity?: number;
        visible?: boolean;
        width?: number;
    };
    minorTickCount?: number | undefined;
    minorTickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    minRange?: number | Record<string, any> | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    placeholderHeight?: number | undefined;
    showCustomBoundaryTicks?: boolean;
    singleWorkdays?: Array<Date | string> | Array<number>;
    startValue?: Date | number | string | undefined;
    tick?: Record<string, any> | {
        color?: string;
        opacity?: number;
        width?: number;
    };
    tickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    type?: AxisScale | undefined;
    valueType?: ChartsDataType | undefined;
    workdaysOnly?: boolean;
    workWeek?: Array<number>;
}>;
declare const Scale: ((props: IScaleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    aggregateByCategory?: boolean | undefined;
    aggregationGroupWidth?: number | undefined;
    aggregationInterval?: number | Record<string, any> | TimeInterval | {
        days?: number | undefined;
        hours?: number | undefined;
        milliseconds?: number | undefined;
        minutes?: number | undefined;
        months?: number | undefined;
        quarters?: number | undefined;
        seconds?: number | undefined;
        weeks?: number | undefined;
        years?: number | undefined;
    } | undefined;
    allowDecimals?: boolean | undefined;
    breaks?: ScaleBreak[] | {
        endValue?: Date | number | string | undefined;
        startValue?: Date | number | string | undefined;
    }[] | undefined;
    breakStyle?: Record<string, any> | {
        color?: string | undefined;
        line?: ScaleBreakLineStyle | undefined;
        width?: number | undefined;
    } | undefined;
    categories?: (string | number | Date)[] | undefined;
    discreteAxisDivisionMode?: DiscreteAxisDivisionMode | undefined;
    endOnTick?: boolean | undefined;
    endValue?: Date | number | string | undefined;
    holidays?: number[] | (string | Date)[] | undefined;
    label?: Record<string, any> | {
        customizeText?: ((scaleValue: {
            value: Date | number | string;
            valueText: string;
        }) => string) | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        overlappingBehavior?: LabelOverlap | undefined;
        topIndent?: number | undefined;
        visible?: boolean | undefined;
    } | undefined;
    linearThreshold?: number | undefined;
    logarithmBase?: number | undefined;
    marker?: Record<string, any> | {
        label?: Record<string, any> | {
            customizeText?: ((markerValue: {
                value: Date | number;
                valueText: string;
            }) => string) | undefined;
            format?: LocalizationFormat | undefined;
        } | undefined;
        separatorHeight?: number | undefined;
        textLeftIndent?: number | undefined;
        textTopIndent?: number | undefined;
        topIndent?: number | undefined;
        visible?: boolean | undefined;
    } | undefined;
    maxRange?: number | Record<string, any> | TimeInterval | {
        days?: number | undefined;
        hours?: number | undefined;
        milliseconds?: number | undefined;
        minutes?: number | undefined;
        months?: number | undefined;
        quarters?: number | undefined;
        seconds?: number | undefined;
        weeks?: number | undefined;
        years?: number | undefined;
    } | undefined;
    minorTick?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    minorTickCount?: number | undefined;
    minorTickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number | undefined;
        hours?: number | undefined;
        milliseconds?: number | undefined;
        minutes?: number | undefined;
        months?: number | undefined;
        quarters?: number | undefined;
        seconds?: number | undefined;
        weeks?: number | undefined;
        years?: number | undefined;
    } | undefined;
    minRange?: number | Record<string, any> | TimeInterval | {
        days?: number | undefined;
        hours?: number | undefined;
        milliseconds?: number | undefined;
        minutes?: number | undefined;
        months?: number | undefined;
        quarters?: number | undefined;
        seconds?: number | undefined;
        weeks?: number | undefined;
        years?: number | undefined;
    } | undefined;
    placeholderHeight?: number | undefined;
    showCustomBoundaryTicks?: boolean | undefined;
    singleWorkdays?: number[] | (string | Date)[] | undefined;
    startValue?: Date | number | string | undefined;
    tick?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
        width?: number | undefined;
    } | undefined;
    tickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number | undefined;
        hours?: number | undefined;
        milliseconds?: number | undefined;
        minutes?: number | undefined;
        months?: number | undefined;
        quarters?: number | undefined;
        seconds?: number | undefined;
        weeks?: number | undefined;
        years?: number | undefined;
    } | undefined;
    type?: AxisScale | undefined;
    valueType?: ChartsDataType | undefined;
    workdaysOnly?: boolean | undefined;
    workWeek?: number[] | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IScaleLabelProps = React.PropsWithChildren<{
    customizeText?: ((scaleValue: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    overlappingBehavior?: LabelOverlap;
    topIndent?: number;
    visible?: boolean;
}>;
declare const ScaleLabel: ((props: IScaleLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    customizeText?: ((scaleValue: {
        value: Date | number | string;
        valueText: string;
    }) => string) | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    overlappingBehavior?: LabelOverlap | undefined;
    topIndent?: number | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISelectionStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
        dashStyle?: DashStyle | undefined;
    };
    color?: ChartsColor | string | undefined;
    size?: number | undefined;
    dashStyle?: DashStyle;
    hatching?: Record<string, any> | {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    highlight?: boolean;
    width?: number;
}>;
declare const SelectionStyle: ((props: ISelectionStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
        dashStyle?: DashStyle | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    size?: number | undefined;
    dashStyle?: DashStyle | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection | undefined;
        opacity?: number | undefined;
        step?: number | undefined;
        width?: number | undefined;
    } | undefined;
    highlight?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISeriesProps = React.PropsWithChildren<{
    aggregation?: Record<string, any> | {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    };
    argumentField?: string;
    axis?: string | undefined;
    barOverlapGroup?: string | undefined;
    barPadding?: number | undefined;
    barWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    closeValueField?: string;
    color?: ChartsColor | string | undefined;
    cornerRadius?: number;
    dashStyle?: DashStyle;
    highValueField?: string;
    hoverMode?: SeriesHoverMode;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    ignoreEmptyPoints?: boolean;
    innerColor?: string;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment;
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    };
    lowValueField?: string;
    maxLabelCount?: number | undefined;
    minBarSize?: number | undefined;
    name?: string | undefined;
    opacity?: number;
    openValueField?: string;
    pane?: string;
    point?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: Record<string, any> | string | undefined | {
            height?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: Record<string, any> | string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    };
    rangeValue1Field?: string;
    rangeValue2Field?: string;
    reduction?: Record<string, any> | {
        color?: string;
        level?: FinancialChartReductionLevel;
    };
    selectionMode?: SeriesSelectionMode;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    showInLegend?: boolean;
    sizeField?: string;
    stack?: string;
    tag?: any | undefined;
    tagField?: string;
    type?: SeriesType;
    valueErrorBar?: Record<string, any> | {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    };
    valueField?: string;
    visible?: boolean;
    width?: number;
}>;
declare const Series: ((props: ISeriesProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    aggregation?: Record<string, any> | {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean | undefined;
        method?: ChartSeriesAggregationMethod | undefined;
    } | undefined;
    argumentField?: string | undefined;
    axis?: string | undefined;
    barOverlapGroup?: string | undefined;
    barPadding?: number | undefined;
    barWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    closeValueField?: string | undefined;
    color?: ChartsColor | string | undefined;
    cornerRadius?: number | undefined;
    dashStyle?: DashStyle | undefined;
    highValueField?: string | undefined;
    hoverMode?: SeriesHoverMode | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    ignoreEmptyPoints?: boolean | undefined;
    innerColor?: string | undefined;
    label?: Record<string, any> | {
        alignment?: HorizontalAlignment | undefined;
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        customizeText?: ((pointInfo: any) => string) | undefined;
        displayFormat?: string | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        horizontalOffset?: number | undefined;
        position?: RelativePosition | undefined;
        rotationAngle?: number | undefined;
        showForZeroValues?: boolean | undefined;
        verticalOffset?: number | undefined;
        visible?: boolean | undefined;
    } | undefined;
    lowValueField?: string | undefined;
    maxLabelCount?: number | undefined;
    minBarSize?: number | undefined;
    name?: string | undefined;
    opacity?: number | undefined;
    openValueField?: string | undefined;
    pane?: string | undefined;
    point?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode | undefined;
        hoverStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            } | undefined;
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        } | undefined;
        image?: Record<string, any> | string | undefined | {
            height?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: Record<string, any> | string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | Record<string, any> | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode | undefined;
        selectionStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            } | undefined;
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        } | undefined;
        size?: number | undefined;
        symbol?: PointSymbol | undefined;
        visible?: boolean | undefined;
    } | undefined;
    rangeValue1Field?: string | undefined;
    rangeValue2Field?: string | undefined;
    reduction?: Record<string, any> | {
        color?: string | undefined;
        level?: FinancialChartReductionLevel | undefined;
    } | undefined;
    selectionMode?: SeriesSelectionMode | undefined;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    showInLegend?: boolean | undefined;
    sizeField?: string | undefined;
    stack?: string | undefined;
    tag?: any | undefined;
    tagField?: string | undefined;
    type?: SeriesType | undefined;
    valueErrorBar?: Record<string, any> | {
        color?: string | undefined;
        displayMode?: ValueErrorBarDisplayMode | undefined;
        edgeLength?: number | undefined;
        highValueField?: string | undefined;
        lineWidth?: number | undefined;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number | undefined;
    } | undefined;
    valueField?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISeriesBorderProps = React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const SeriesBorder: ((props: ISeriesBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISeriesTemplateProps = React.PropsWithChildren<{
    customizeSeries?: ((seriesName: any) => ChartSeries);
    nameField?: string;
}>;
declare const SeriesTemplate: ((props: ISeriesTemplateProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    customizeSeries?: ((seriesName: any) => ChartSeries) | undefined;
    nameField?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShutterProps = React.PropsWithChildren<{
    color?: string | undefined;
    opacity?: number;
}>;
declare const Shutter: ((props: IShutterProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    opacity?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISizeProps = React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
}>;
declare const Size: ((props: ISizeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISliderHandleProps = React.PropsWithChildren<{
    color?: string;
    opacity?: number;
    width?: number;
}>;
declare const SliderHandle: ((props: ISliderHandleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    opacity?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISliderMarkerProps = React.PropsWithChildren<{
    color?: string;
    customizeText?: ((scaleValue: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    invalidRangeColor?: string;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    placeholderHeight?: number | undefined;
    visible?: boolean;
}>;
declare const SliderMarker: ((props: ISliderMarkerProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    customizeText?: ((scaleValue: {
        value: Date | number | string;
        valueText: string;
    }) => string) | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    invalidRangeColor?: string | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    placeholderHeight?: number | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISubtitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    offset?: number;
    text?: string;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const Subtitle: ((props: ISubtitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    offset?: number | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITickProps = React.PropsWithChildren<{
    color?: string;
    opacity?: number;
    width?: number;
}>;
declare const Tick: ((props: ITickProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    opacity?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITickIntervalProps = React.PropsWithChildren<{
    days?: number;
    hours?: number;
    milliseconds?: number;
    minutes?: number;
    months?: number;
    quarters?: number;
    seconds?: number;
    weeks?: number;
    years?: number;
}>;
declare const TickInterval: ((props: ITickIntervalProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    days?: number | undefined;
    hours?: number | undefined;
    milliseconds?: number | undefined;
    minutes?: number | undefined;
    months?: number | undefined;
    quarters?: number | undefined;
    seconds?: number | undefined;
    weeks?: number | undefined;
    years?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    margin?: number | Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    placeholderSize?: number | undefined;
    subtitle?: Record<string, any> | string | {
        font?: ChartsFont;
        offset?: number;
        text?: string;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    text?: string;
    textOverflow?: TextOverflow;
    verticalAlignment?: VerticalEdge;
    wordWrap?: WordWrap;
}>;
declare const Title: ((props: ITitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    placeholderSize?: number | undefined;
    subtitle?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        offset?: number | undefined;
        text?: string | undefined;
        textOverflow?: TextOverflow | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    verticalAlignment?: VerticalEdge | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IUrlProps = React.PropsWithChildren<{
    rangeMaxPoint?: string | undefined;
    rangeMinPoint?: string | undefined;
}>;
declare const Url: ((props: IUrlProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    rangeMaxPoint?: string | undefined;
    rangeMinPoint?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IValueProps = React.PropsWithChildren<{
    endValue?: Date | number | string | undefined;
    length?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    startValue?: Date | number | string | undefined;
    defaultEndValue?: Date | number | string | undefined;
    onEndValueChange?: (value: Date | number | string | undefined) => void;
    defaultStartValue?: Date | number | string | undefined;
    onStartValueChange?: (value: Date | number | string | undefined) => void;
}>;
declare const Value: ((props: IValueProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    endValue?: Date | number | string | undefined;
    length?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    startValue?: Date | number | string | undefined;
    defaultEndValue?: Date | number | string | undefined;
    onEndValueChange?: ((value: Date | number | string | undefined) => void) | undefined;
    defaultStartValue?: Date | number | string | undefined;
    onStartValueChange?: ((value: Date | number | string | undefined) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IValueAxisProps = React.PropsWithChildren<{
    inverted?: boolean;
    logarithmBase?: number;
    max?: number | undefined;
    min?: number | undefined;
    type?: ChartAxisScale | undefined;
    valueType?: ChartsDataType | undefined;
}>;
declare const ValueAxis: ((props: IValueAxisProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    inverted?: boolean | undefined;
    logarithmBase?: number | undefined;
    max?: number | undefined;
    min?: number | undefined;
    type?: ChartAxisScale | undefined;
    valueType?: ChartsDataType | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IValueErrorBarProps = React.PropsWithChildren<{
    color?: string;
    displayMode?: ValueErrorBarDisplayMode;
    edgeLength?: number;
    highValueField?: string | undefined;
    lineWidth?: number;
    lowValueField?: string | undefined;
    opacity?: number | undefined;
    type?: undefined | ValueErrorBarType;
    value?: number;
}>;
declare const ValueErrorBar: ((props: IValueErrorBarProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    displayMode?: ValueErrorBarDisplayMode | undefined;
    edgeLength?: number | undefined;
    highValueField?: string | undefined;
    lineWidth?: number | undefined;
    lowValueField?: string | undefined;
    opacity?: number | undefined;
    type?: undefined | ValueErrorBarType;
    value?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IWidthProps = React.PropsWithChildren<{
    rangeMaxPoint?: number | undefined;
    rangeMinPoint?: number | undefined;
}>;
declare const Width: ((props: IWidthProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    rangeMaxPoint?: number | undefined;
    rangeMinPoint?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default RangeSelector;
export { RangeSelector, IRangeSelectorOptions, RangeSelectorRef, Aggregation, IAggregationProps, AggregationInterval, IAggregationIntervalProps, ArgumentFormat, IArgumentFormatProps, Background, IBackgroundProps, BackgroundImage, IBackgroundImageProps, Behavior, IBehaviorProps, Border, IBorderProps, Break, IBreakProps, BreakStyle, IBreakStyleProps, Chart, IChartProps, Color, IColorProps, CommonSeriesSettings, ICommonSeriesSettingsProps, CommonSeriesSettingsHoverStyle, ICommonSeriesSettingsHoverStyleProps, CommonSeriesSettingsLabel, ICommonSeriesSettingsLabelProps, CommonSeriesSettingsSelectionStyle, ICommonSeriesSettingsSelectionStyleProps, Connector, IConnectorProps, DataPrepareSettings, IDataPrepareSettingsProps, Export, IExportProps, Font, IFontProps, Format, IFormatProps, Hatching, IHatchingProps, Height, IHeightProps, HoverStyle, IHoverStyleProps, Image, IImageProps, Indent, IIndentProps, Label, ILabelProps, Length, ILengthProps, LoadingIndicator, ILoadingIndicatorProps, Margin, IMarginProps, Marker, IMarkerProps, MarkerLabel, IMarkerLabelProps, MaxRange, IMaxRangeProps, MinorTick, IMinorTickProps, MinorTickInterval, IMinorTickIntervalProps, MinRange, IMinRangeProps, Point, IPointProps, PointBorder, IPointBorderProps, PointHoverStyle, IPointHoverStyleProps, PointImage, IPointImageProps, PointSelectionStyle, IPointSelectionStyleProps, Reduction, IReductionProps, Scale, IScaleProps, ScaleLabel, IScaleLabelProps, SelectionStyle, ISelectionStyleProps, Series, ISeriesProps, SeriesBorder, ISeriesBorderProps, SeriesTemplate, ISeriesTemplateProps, Shutter, IShutterProps, Size, ISizeProps, SliderHandle, ISliderHandleProps, SliderMarker, ISliderMarkerProps, Subtitle, ISubtitleProps, Tick, ITickProps, TickInterval, ITickIntervalProps, Title, ITitleProps, Url, IUrlProps, Value, IValueProps, ValueAxis, IValueAxisProps, ValueErrorBar, IValueErrorBarProps, Width, IWidthProps };
import type * as RangeSelectorTypes from 'devextreme/viz/range_selector_types';
export { RangeSelectorTypes };
