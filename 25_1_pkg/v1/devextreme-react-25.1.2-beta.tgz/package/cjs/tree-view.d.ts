/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

export { ExplicitTypes } from "devextreme/ui/tree_view";
import * as React from "react";
import { Ref, ReactElement } from "react";
import dxTreeView, { Properties } from "devextreme/ui/tree_view";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { dxTreeViewItem, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemCollapsedEvent, ItemContextMenuEvent, ItemExpandedEvent, ItemHoldEvent, ItemRenderedEvent, SelectAllValueChangedEvent } from "devextreme/ui/tree_view";
import type { ContentReadyEvent as ButtonContentReadyEvent, DisposingEvent as ButtonDisposingEvent, InitializedEvent as ButtonInitializedEvent, dxButtonOptions, ClickEvent, OptionChangedEvent } from "devextreme/ui/button";
import type { ContentReadyEvent as TextBoxContentReadyEvent, DisposingEvent as TextBoxDisposingEvent, InitializedEvent as TextBoxInitializedEvent, OptionChangedEvent as TextBoxOptionChangedEvent, TextBoxType, ChangeEvent, CopyEvent, CutEvent, EnterKeyEvent, FocusInEvent, FocusOutEvent, InputEvent, KeyDownEvent, KeyUpEvent, PasteEvent, ValueChangedEvent } from "devextreme/ui/text_box";
import type { TextEditorButtonLocation, template, ButtonStyle, ButtonType, TextBoxPredefinedButton, TextEditorButton, LabelMode, MaskMode, EditorStyle, ValidationMessageMode, Position, ValidationStatus } from "devextreme/common";
import type { CollectionWidgetItem } from "devextreme/ui/collection/ui.collection_widget.base";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type ITreeViewOptionsNarrowedEvents<TKey = any> = {
    onContentReady?: ((e: ContentReadyEvent<TKey>) => void);
    onDisposing?: ((e: DisposingEvent<TKey>) => void);
    onInitialized?: ((e: InitializedEvent<TKey>) => void);
    onItemClick?: ((e: ItemClickEvent<TKey>) => void);
    onItemCollapsed?: ((e: ItemCollapsedEvent<TKey>) => void);
    onItemContextMenu?: ((e: ItemContextMenuEvent<TKey>) => void);
    onItemExpanded?: ((e: ItemExpandedEvent<TKey>) => void);
    onItemHold?: ((e: ItemHoldEvent<TKey>) => void);
    onItemRendered?: ((e: ItemRenderedEvent<TKey>) => void);
    onSelectAllValueChanged?: ((e: SelectAllValueChangedEvent<TKey>) => void);
};
type ITreeViewOptions<TKey = any> = React.PropsWithChildren<ReplaceFieldTypes<Properties<TKey>, ITreeViewOptionsNarrowedEvents<TKey>> & IHtmlOptions & {
    dataSource?: Properties<TKey>["dataSource"];
    itemRender?: (...params: any) => React.ReactNode;
    itemComponent?: React.ComponentType<any>;
    defaultItems?: Array<dxTreeViewItem>;
    onItemsChange?: (value: Array<dxTreeViewItem>) => void;
}>;
interface TreeViewRef<TKey = any> {
    instance: () => dxTreeView<TKey>;
}
declare const TreeView: <TKey = any>(props: ReplaceFieldTypes<Properties<TKey>, ITreeViewOptionsNarrowedEvents<TKey>> & IHtmlOptions & {
    dataSource?: import("devextreme/data/data_source").DataSourceLike<dxTreeViewItem, TKey> | null | undefined;
    itemRender?: ((...params: any) => React.ReactNode) | undefined;
    itemComponent?: React.ComponentType<any> | undefined;
    defaultItems?: dxTreeViewItem[] | undefined;
    onItemsChange?: ((value: Array<dxTreeViewItem>) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    ref?: React.Ref<TreeViewRef<TKey>> | undefined;
}) => ReactElement | null;
type IButtonProps = React.PropsWithChildren<{
    location?: TextEditorButtonLocation;
    name?: string | undefined;
    options?: dxButtonOptions | undefined;
}>;
declare const Button: ((props: IButtonProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    location?: TextEditorButtonLocation | undefined;
    name?: string | undefined;
    options?: dxButtonOptions | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IItemProps = React.PropsWithChildren<{
    disabled?: boolean;
    expanded?: boolean;
    hasItems?: boolean | undefined;
    html?: string;
    icon?: string;
    id?: number | string | undefined;
    items?: Array<dxTreeViewItem>;
    parentId?: number | string | undefined;
    selected?: boolean;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const Item: ((props: IItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    disabled?: boolean | undefined;
    expanded?: boolean | undefined;
    hasItems?: boolean | undefined;
    html?: string | undefined;
    icon?: string | undefined;
    id?: number | string | undefined;
    items?: dxTreeViewItem[] | undefined;
    parentId?: number | string | undefined;
    selected?: boolean | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IOptionsProps = React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean;
    bindingOptions?: Record<string, any>;
    disabled?: boolean;
    elementAttr?: Record<string, any>;
    focusStateEnabled?: boolean;
    height?: (() => number | string) | number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    icon?: string;
    onClick?: ((e: ClickEvent) => void);
    onContentReady?: ((e: ButtonContentReadyEvent) => void);
    onDisposing?: ((e: ButtonDisposingEvent) => void);
    onInitialized?: ((e: ButtonInitializedEvent) => void);
    onOptionChanged?: ((e: OptionChangedEvent) => void);
    rtlEnabled?: boolean;
    stylingMode?: ButtonStyle;
    tabIndex?: number;
    template?: ((buttonData: {
        icon: string;
        text: string;
    }, contentElement: any) => string | any) | template;
    text?: string;
    type?: ButtonType | string;
    useSubmitBehavior?: boolean;
    validationGroup?: string | undefined;
    visible?: boolean;
    width?: (() => number | string) | number | string | undefined;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const Options: ((props: IOptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean | undefined;
    bindingOptions?: Record<string, any> | undefined;
    disabled?: boolean | undefined;
    elementAttr?: Record<string, any> | undefined;
    focusStateEnabled?: boolean | undefined;
    height?: (() => number | string) | number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    icon?: string | undefined;
    onClick?: ((e: ClickEvent) => void) | undefined;
    onContentReady?: ((e: ButtonContentReadyEvent) => void) | undefined;
    onDisposing?: ((e: ButtonDisposingEvent) => void) | undefined;
    onInitialized?: ((e: ButtonInitializedEvent) => void) | undefined;
    onOptionChanged?: ((e: OptionChangedEvent) => void) | undefined;
    rtlEnabled?: boolean | undefined;
    stylingMode?: ButtonStyle | undefined;
    tabIndex?: number | undefined;
    template?: template | ((buttonData: {
        icon: string;
        text: string;
    }, contentElement: any) => string | any) | undefined;
    text?: string | undefined;
    type?: string | undefined;
    useSubmitBehavior?: boolean | undefined;
    validationGroup?: string | undefined;
    visible?: boolean | undefined;
    width?: (() => number | string) | number | string | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISearchEditorOptionsProps = React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean;
    bindingOptions?: Record<string, any>;
    buttons?: Array<string | TextBoxPredefinedButton | TextEditorButton>;
    disabled?: boolean;
    elementAttr?: Record<string, any>;
    focusStateEnabled?: boolean;
    height?: (() => number | string) | number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean;
    inputAttr?: any;
    isDirty?: boolean;
    isValid?: boolean;
    label?: string;
    labelMode?: LabelMode;
    mask?: string;
    maskChar?: string;
    maskInvalidMessage?: string;
    maskRules?: any;
    maxLength?: number | string;
    mode?: TextBoxType;
    name?: string;
    onChange?: ((e: ChangeEvent) => void);
    onContentReady?: ((e: TextBoxContentReadyEvent) => void);
    onCopy?: ((e: CopyEvent) => void);
    onCut?: ((e: CutEvent) => void);
    onDisposing?: ((e: TextBoxDisposingEvent) => void);
    onEnterKey?: ((e: EnterKeyEvent) => void);
    onFocusIn?: ((e: FocusInEvent) => void);
    onFocusOut?: ((e: FocusOutEvent) => void);
    onInitialized?: ((e: TextBoxInitializedEvent) => void);
    onInput?: ((e: InputEvent) => void);
    onKeyDown?: ((e: KeyDownEvent) => void);
    onKeyUp?: ((e: KeyUpEvent) => void);
    onOptionChanged?: ((e: TextBoxOptionChangedEvent) => void);
    onPaste?: ((e: PasteEvent) => void);
    onValueChanged?: ((e: ValueChangedEvent) => void);
    placeholder?: string;
    readOnly?: boolean;
    rtlEnabled?: boolean;
    showClearButton?: boolean;
    showMaskMode?: MaskMode;
    spellcheck?: boolean;
    stylingMode?: EditorStyle;
    tabIndex?: number;
    text?: string;
    useMaskedValue?: boolean;
    validationError?: any;
    validationErrors?: Array<any>;
    validationMessageMode?: ValidationMessageMode;
    validationMessagePosition?: Position;
    validationStatus?: ValidationStatus;
    value?: string;
    valueChangeEvent?: string;
    visible?: boolean;
    width?: (() => number | string) | number | string | undefined;
    defaultValue?: string;
    onValueChange?: (value: string) => void;
}>;
declare const SearchEditorOptions: ((props: ISearchEditorOptionsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    accessKey?: string | undefined;
    activeStateEnabled?: boolean | undefined;
    bindingOptions?: Record<string, any> | undefined;
    buttons?: (string | TextEditorButton)[] | undefined;
    disabled?: boolean | undefined;
    elementAttr?: Record<string, any> | undefined;
    focusStateEnabled?: boolean | undefined;
    height?: (() => number | string) | number | string | undefined;
    hint?: string | undefined;
    hoverStateEnabled?: boolean | undefined;
    inputAttr?: any;
    isDirty?: boolean | undefined;
    isValid?: boolean | undefined;
    label?: string | undefined;
    labelMode?: LabelMode | undefined;
    mask?: string | undefined;
    maskChar?: string | undefined;
    maskInvalidMessage?: string | undefined;
    maskRules?: any;
    maxLength?: string | number | undefined;
    mode?: TextBoxType | undefined;
    name?: string | undefined;
    onChange?: ((e: ChangeEvent) => void) | undefined;
    onContentReady?: ((e: TextBoxContentReadyEvent) => void) | undefined;
    onCopy?: ((e: CopyEvent) => void) | undefined;
    onCut?: ((e: CutEvent) => void) | undefined;
    onDisposing?: ((e: TextBoxDisposingEvent) => void) | undefined;
    onEnterKey?: ((e: EnterKeyEvent) => void) | undefined;
    onFocusIn?: ((e: FocusInEvent) => void) | undefined;
    onFocusOut?: ((e: FocusOutEvent) => void) | undefined;
    onInitialized?: ((e: TextBoxInitializedEvent) => void) | undefined;
    onInput?: ((e: InputEvent) => void) | undefined;
    onKeyDown?: ((e: KeyDownEvent) => void) | undefined;
    onKeyUp?: ((e: KeyUpEvent) => void) | undefined;
    onOptionChanged?: ((e: TextBoxOptionChangedEvent) => void) | undefined;
    onPaste?: ((e: PasteEvent) => void) | undefined;
    onValueChanged?: ((e: ValueChangedEvent) => void) | undefined;
    placeholder?: string | undefined;
    readOnly?: boolean | undefined;
    rtlEnabled?: boolean | undefined;
    showClearButton?: boolean | undefined;
    showMaskMode?: MaskMode | undefined;
    spellcheck?: boolean | undefined;
    stylingMode?: EditorStyle | undefined;
    tabIndex?: number | undefined;
    text?: string | undefined;
    useMaskedValue?: boolean | undefined;
    validationError?: any;
    validationErrors?: any[] | undefined;
    validationMessageMode?: ValidationMessageMode | undefined;
    validationMessagePosition?: Position | undefined;
    validationStatus?: ValidationStatus | undefined;
    value?: string | undefined;
    valueChangeEvent?: string | undefined;
    visible?: boolean | undefined;
    width?: (() => number | string) | number | string | undefined;
    defaultValue?: string | undefined;
    onValueChange?: ((value: string) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default TreeView;
export { TreeView, ITreeViewOptions, TreeViewRef, Button, IButtonProps, Item, IItemProps, Options, IOptionsProps, SearchEditorOptions, ISearchEditorOptionsProps };
import type * as TreeViewTypes from 'devextreme/ui/tree_view_types';
export { TreeViewTypes };
