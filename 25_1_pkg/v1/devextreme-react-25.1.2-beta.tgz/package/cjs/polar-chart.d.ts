/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

import * as React from "react";
import { Ref, ReactElement } from "react";
import dxPolarChart, { Properties } from "devextreme/viz/polar_chart";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { ArgumentAxisClickEvent, DisposingEvent, DoneEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, LegendClickEvent, PointClickEvent, SeriesClickEvent, TooltipHiddenEvent, TooltipShownEvent, ZoomEndEvent, ZoomStartEvent, dxPolarChartAnnotationConfig, dxPolarChartCommonAnnotationConfig, PolarChartSeriesType, PolarChartSeries, ValueAxisVisualRangeUpdateMode } from "devextreme/viz/polar_chart";
import type { AnimationEaseMode, DashStyle, Font as ChartsFont, TextOverflow, AnnotationType, WordWrap, ChartsDataType, DiscreteAxisDivisionMode, ArgumentAxisHoverMode, LabelOverlap, TimeInterval, AxisScaleType, ChartsColor, SeriesHoverMode, HatchDirection, RelativePosition, PointInteractionMode, PointSymbol, SeriesSelectionMode, ValueErrorBarDisplayMode, ValueErrorBarType, LegendItem, LegendHoverMode } from "devextreme/common/charts";
import type { template, Format as CommonFormat, ExportFormat, HorizontalAlignment, Position, Orientation, VerticalEdge } from "devextreme/common";
import type { Format as LocalizationFormat } from "devextreme/common/core/localization";
import type * as CommonChartTypes from "devextreme/common/charts";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type IPolarChartOptionsNarrowedEvents = {
    onArgumentAxisClick?: ((e: ArgumentAxisClickEvent) => void);
    onDisposing?: ((e: DisposingEvent) => void);
    onDone?: ((e: DoneEvent) => void);
    onDrawn?: ((e: DrawnEvent) => void);
    onExported?: ((e: ExportedEvent) => void);
    onExporting?: ((e: ExportingEvent) => void);
    onFileSaving?: ((e: FileSavingEvent) => void);
    onIncidentOccurred?: ((e: IncidentOccurredEvent) => void);
    onInitialized?: ((e: InitializedEvent) => void);
    onLegendClick?: ((e: LegendClickEvent) => void);
    onPointClick?: ((e: PointClickEvent) => void);
    onSeriesClick?: ((e: SeriesClickEvent) => void);
    onTooltipHidden?: ((e: TooltipHiddenEvent) => void);
    onTooltipShown?: ((e: TooltipShownEvent) => void);
    onZoomEnd?: ((e: ZoomEndEvent) => void);
    onZoomStart?: ((e: ZoomStartEvent) => void);
};
type IPolarChartOptions = React.PropsWithChildren<ReplaceFieldTypes<Properties, IPolarChartOptionsNarrowedEvents> & IHtmlOptions & {
    defaultLoadingIndicator?: Record<string, any>;
    defaultValueAxis?: Record<string, any>;
    onLoadingIndicatorChange?: (value: Record<string, any>) => void;
    onValueAxisChange?: (value: Record<string, any>) => void;
}>;
interface PolarChartRef {
    instance: () => dxPolarChart;
}
declare const PolarChart: (props: React.PropsWithChildren<IPolarChartOptions> & {
    ref?: Ref<PolarChartRef>;
}) => ReactElement | null;
type IAdaptiveLayoutProps = React.PropsWithChildren<{
    height?: number;
    keepLabels?: boolean;
    width?: number;
}>;
declare const AdaptiveLayout: ((props: IAdaptiveLayoutProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    keepLabels?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAnimationProps = React.PropsWithChildren<{
    duration?: number;
    easing?: AnimationEaseMode;
    enabled?: boolean;
    maxPointCountSupported?: number;
}>;
declare const Animation: ((props: IAnimationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    duration?: number | undefined;
    easing?: AnimationEaseMode | undefined;
    enabled?: boolean | undefined;
    maxPointCountSupported?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAnnotationProps = React.PropsWithChildren<{
    allowDragging?: boolean;
    angle?: number | undefined;
    argument?: Date | number | string | undefined;
    arrowLength?: number;
    arrowWidth?: number;
    border?: Record<string, any> | {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: string;
    customizeTooltip?: ((annotation: dxPolarChartAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont;
    height?: number | undefined;
    image?: Record<string, any> | string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    name?: string | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    radius?: number | undefined;
    series?: string | undefined;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    template?: ((annotation: dxPolarChartCommonAnnotationConfig | any, element: any) => string | any) | template | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow;
    tooltipEnabled?: boolean;
    tooltipTemplate?: ((annotation: dxPolarChartAnnotationConfig | any, element: any) => string | any) | template | undefined;
    type?: AnnotationType | undefined;
    value?: Date | number | string | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap;
    x?: number | undefined;
    y?: number | undefined;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
    tooltipRender?: (...params: any) => React.ReactNode;
    tooltipComponent?: React.ComponentType<any>;
}>;
declare const Annotation: ((props: IAnnotationProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowDragging?: boolean | undefined;
    angle?: number | undefined;
    argument?: Date | number | string | undefined;
    arrowLength?: number | undefined;
    arrowWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        cornerRadius?: number | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    customizeTooltip?: ((annotation: dxPolarChartAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont | undefined;
    height?: number | undefined;
    image?: string | Record<string, any> | {
        height?: number | undefined;
        url?: string | undefined;
        width?: number | undefined;
    } | undefined;
    name?: string | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    radius?: number | undefined;
    series?: string | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    template?: template | ((annotation: dxPolarChartCommonAnnotationConfig | any, element: any) => string | any) | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    tooltipEnabled?: boolean | undefined;
    tooltipTemplate?: template | ((annotation: dxPolarChartAnnotationConfig | any, element: any) => string | any) | undefined;
    type?: AnnotationType | undefined;
    value?: Date | number | string | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap | undefined;
    x?: number | undefined;
    y?: number | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
    tooltipRender?: ((...params: any) => React.ReactNode) | undefined;
    tooltipComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAnnotationBorderProps = React.PropsWithChildren<{
    color?: string;
    cornerRadius?: number;
    dashStyle?: DashStyle;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const AnnotationBorder: ((props: IAnnotationBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    cornerRadius?: number | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IArgumentAxisProps = React.PropsWithChildren<{
    allowDecimals?: boolean | undefined;
    argumentType?: ChartsDataType | undefined;
    axisDivisionFactor?: number;
    categories?: Array<Date | number | string>;
    color?: string;
    constantLines?: Array<Record<string, any>> | {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: Record<string, any> | {
            font?: ChartsFont;
            text?: string | undefined;
            visible?: boolean;
        };
        value?: Date | number | string | undefined;
        width?: number;
    }[];
    constantLineStyle?: Record<string, any> | {
        color?: string;
        dashStyle?: DashStyle;
        label?: Record<string, any> | {
            font?: ChartsFont;
            visible?: boolean;
        };
        width?: number;
    };
    discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
    endOnTick?: boolean | undefined;
    firstPointOnStartAngle?: boolean;
    grid?: Record<string, any> | {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    hoverMode?: ArgumentAxisHoverMode;
    inverted?: boolean;
    label?: Record<string, any> | {
        customizeHint?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        customizeText?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: LabelOverlap;
        visible?: boolean;
    };
    linearThreshold?: number | undefined;
    logarithmBase?: number;
    minorGrid?: Record<string, any> | {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    minorTick?: Record<string, any> | {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    minorTickCount?: number | undefined;
    minorTickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    opacity?: number | undefined;
    originValue?: number | undefined;
    period?: number | undefined;
    startAngle?: number;
    strips?: Array<Record<string, any>> | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont;
            text?: string | undefined;
        };
        startValue?: Date | number | string | undefined;
    }[];
    stripStyle?: Record<string, any> | {
        label?: Record<string, any> | {
            font?: ChartsFont;
        };
    };
    tick?: Record<string, any> | {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    tickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    type?: AxisScaleType | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const ArgumentAxis: ((props: IArgumentAxisProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowDecimals?: boolean | undefined;
    argumentType?: ChartsDataType | undefined;
    axisDivisionFactor?: number | undefined;
    categories?: (string | number | Date)[] | undefined;
    color?: string | undefined;
    constantLines?: Record<string, any>[] | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        displayBehindSeries?: boolean | undefined;
        extendAxis?: boolean | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            text?: string | undefined;
            visible?: boolean | undefined;
        } | undefined;
        value?: Date | number | string | undefined;
        width?: number | undefined;
    }[] | undefined;
    constantLineStyle?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            visible?: boolean | undefined;
        } | undefined;
        width?: number | undefined;
    } | undefined;
    discreteAxisDivisionMode?: DiscreteAxisDivisionMode | undefined;
    endOnTick?: boolean | undefined;
    firstPointOnStartAngle?: boolean | undefined;
    grid?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    hoverMode?: ArgumentAxisHoverMode | undefined;
    inverted?: boolean | undefined;
    label?: Record<string, any> | {
        customizeHint?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string) | undefined;
        customizeText?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string) | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        indentFromAxis?: number | undefined;
        overlappingBehavior?: LabelOverlap | undefined;
        visible?: boolean | undefined;
    } | undefined;
    linearThreshold?: number | undefined;
    logarithmBase?: number | undefined;
    minorGrid?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    minorTick?: Record<string, any> | {
        color?: string | undefined;
        length?: number | undefined;
        opacity?: number | undefined;
        shift?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    minorTickCount?: number | undefined;
    minorTickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number | undefined;
        hours?: number | undefined;
        milliseconds?: number | undefined;
        minutes?: number | undefined;
        months?: number | undefined;
        quarters?: number | undefined;
        seconds?: number | undefined;
        weeks?: number | undefined;
        years?: number | undefined;
    } | undefined;
    opacity?: number | undefined;
    originValue?: number | undefined;
    period?: number | undefined;
    startAngle?: number | undefined;
    strips?: Record<string, any>[] | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            text?: string | undefined;
        } | undefined;
        startValue?: Date | number | string | undefined;
    }[] | undefined;
    stripStyle?: Record<string, any> | {
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
        } | undefined;
    } | undefined;
    tick?: Record<string, any> | {
        color?: string | undefined;
        length?: number | undefined;
        opacity?: number | undefined;
        shift?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    tickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number | undefined;
        hours?: number | undefined;
        milliseconds?: number | undefined;
        minutes?: number | undefined;
        months?: number | undefined;
        quarters?: number | undefined;
        seconds?: number | undefined;
        weeks?: number | undefined;
        years?: number | undefined;
    } | undefined;
    type?: AxisScaleType | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IArgumentAxisMinorTickProps = React.PropsWithChildren<{
    color?: string;
    length?: number;
    opacity?: number;
    shift?: number;
    visible?: boolean;
    width?: number;
}>;
declare const ArgumentAxisMinorTick: ((props: IArgumentAxisMinorTickProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    length?: number | undefined;
    opacity?: number | undefined;
    shift?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IArgumentAxisTickProps = React.PropsWithChildren<{
    color?: string;
    length?: number;
    opacity?: number | undefined;
    shift?: number;
    visible?: boolean;
    width?: number;
}>;
declare const ArgumentAxisTick: ((props: IArgumentAxisTickProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    length?: number | undefined;
    opacity?: number | undefined;
    shift?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IArgumentFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const ArgumentFormat: ((props: IArgumentFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IAxisLabelProps = React.PropsWithChildren<{
    customizeHint?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    customizeText?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    indentFromAxis?: number;
    overlappingBehavior?: LabelOverlap;
    visible?: boolean;
}>;
declare const AxisLabel: ((props: IAxisLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    customizeHint?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string) | undefined;
    customizeText?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string) | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    indentFromAxis?: number | undefined;
    overlappingBehavior?: LabelOverlap | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IBorderProps = React.PropsWithChildren<{
    color?: string | undefined;
    cornerRadius?: number;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const Border: ((props: IBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    cornerRadius?: number | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IColorProps = React.PropsWithChildren<{
    base?: string | undefined;
    fillId?: string | undefined;
}>;
declare const Color: ((props: IColorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    base?: string | undefined;
    fillId?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonAnnotationSettingsProps = React.PropsWithChildren<{
    allowDragging?: boolean;
    angle?: number | undefined;
    argument?: Date | number | string | undefined;
    arrowLength?: number;
    arrowWidth?: number;
    border?: Record<string, any> | {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: string;
    customizeTooltip?: ((annotation: dxPolarChartAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont;
    height?: number | undefined;
    image?: Record<string, any> | string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    radius?: number | undefined;
    series?: string | undefined;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    template?: ((annotation: dxPolarChartCommonAnnotationConfig | any, element: any) => string | any) | template | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow;
    tooltipEnabled?: boolean;
    tooltipTemplate?: ((annotation: dxPolarChartAnnotationConfig | any, element: any) => string | any) | template | undefined;
    type?: AnnotationType | undefined;
    value?: Date | number | string | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap;
    x?: number | undefined;
    y?: number | undefined;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
    tooltipRender?: (...params: any) => React.ReactNode;
    tooltipComponent?: React.ComponentType<any>;
}>;
declare const CommonAnnotationSettings: ((props: ICommonAnnotationSettingsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowDragging?: boolean | undefined;
    angle?: number | undefined;
    argument?: Date | number | string | undefined;
    arrowLength?: number | undefined;
    arrowWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        cornerRadius?: number | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    customizeTooltip?: ((annotation: dxPolarChartAnnotationConfig | any) => Record<string, any>) | undefined;
    data?: any;
    description?: string | undefined;
    font?: ChartsFont | undefined;
    height?: number | undefined;
    image?: string | Record<string, any> | {
        height?: number | undefined;
        url?: string | undefined;
        width?: number | undefined;
    } | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    radius?: number | undefined;
    series?: string | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    template?: template | ((annotation: dxPolarChartCommonAnnotationConfig | any, element: any) => string | any) | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    tooltipEnabled?: boolean | undefined;
    tooltipTemplate?: template | ((annotation: dxPolarChartAnnotationConfig | any, element: any) => string | any) | undefined;
    type?: AnnotationType | undefined;
    value?: Date | number | string | undefined;
    width?: number | undefined;
    wordWrap?: WordWrap | undefined;
    x?: number | undefined;
    y?: number | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
    tooltipRender?: ((...params: any) => React.ReactNode) | undefined;
    tooltipComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonAxisSettingsProps = React.PropsWithChildren<{
    allowDecimals?: boolean | undefined;
    color?: string;
    constantLineStyle?: Record<string, any> | {
        color?: string;
        dashStyle?: DashStyle;
        label?: Record<string, any> | {
            font?: ChartsFont;
            visible?: boolean;
        };
        width?: number;
    };
    discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
    endOnTick?: boolean | undefined;
    grid?: Record<string, any> | {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    inverted?: boolean;
    label?: Record<string, any> | {
        font?: ChartsFont;
        indentFromAxis?: number;
        overlappingBehavior?: LabelOverlap;
        visible?: boolean;
    };
    minorGrid?: Record<string, any> | {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    minorTick?: Record<string, any> | {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    };
    opacity?: number | undefined;
    stripStyle?: Record<string, any> | {
        label?: Record<string, any> | {
            font?: ChartsFont;
        };
    };
    tick?: Record<string, any> | {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    visible?: boolean;
    width?: number;
}>;
declare const CommonAxisSettings: ((props: ICommonAxisSettingsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowDecimals?: boolean | undefined;
    color?: string | undefined;
    constantLineStyle?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            visible?: boolean | undefined;
        } | undefined;
        width?: number | undefined;
    } | undefined;
    discreteAxisDivisionMode?: DiscreteAxisDivisionMode | undefined;
    endOnTick?: boolean | undefined;
    grid?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    inverted?: boolean | undefined;
    label?: Record<string, any> | {
        font?: ChartsFont | undefined;
        indentFromAxis?: number | undefined;
        overlappingBehavior?: LabelOverlap | undefined;
        visible?: boolean | undefined;
    } | undefined;
    minorGrid?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    minorTick?: Record<string, any> | {
        color?: string | undefined;
        length?: number | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    opacity?: number | undefined;
    stripStyle?: Record<string, any> | {
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
        } | undefined;
    } | undefined;
    tick?: Record<string, any> | {
        color?: string | undefined;
        length?: number | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonAxisSettingsLabelProps = React.PropsWithChildren<{
    font?: ChartsFont;
    indentFromAxis?: number;
    overlappingBehavior?: LabelOverlap;
    visible?: boolean;
}>;
declare const CommonAxisSettingsLabel: ((props: ICommonAxisSettingsLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    indentFromAxis?: number | undefined;
    overlappingBehavior?: LabelOverlap | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonAxisSettingsMinorTickProps = React.PropsWithChildren<{
    color?: string;
    length?: number;
    opacity?: number;
    visible?: boolean;
    width?: number;
}>;
declare const CommonAxisSettingsMinorTick: ((props: ICommonAxisSettingsMinorTickProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    length?: number | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonAxisSettingsTickProps = React.PropsWithChildren<{
    color?: string;
    length?: number;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const CommonAxisSettingsTick: ((props: ICommonAxisSettingsTickProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    length?: number | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonSeriesSettingsProps = React.PropsWithChildren<{
    area?: any;
    argumentField?: string;
    bar?: any;
    barPadding?: number | undefined;
    barWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    closed?: boolean;
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle;
    hoverMode?: SeriesHoverMode;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    ignoreEmptyPoints?: boolean;
    label?: Record<string, any> | {
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        visible?: boolean;
    };
    line?: any;
    maxLabelCount?: number | undefined;
    minBarSize?: number | undefined;
    opacity?: number;
    point?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        image?: Record<string, any> | string | undefined | {
            height?: number;
            url?: string | undefined;
            width?: number;
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    };
    scatter?: any;
    selectionMode?: SeriesSelectionMode;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    showInLegend?: boolean;
    stack?: string;
    stackedbar?: any;
    tagField?: string;
    type?: PolarChartSeriesType;
    valueErrorBar?: Record<string, any> | {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    };
    valueField?: string;
    visible?: boolean;
    width?: number;
}>;
declare const CommonSeriesSettings: ((props: ICommonSeriesSettingsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    area?: any;
    argumentField?: string | undefined;
    bar?: any;
    barPadding?: number | undefined;
    barWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    closed?: boolean | undefined;
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle | undefined;
    hoverMode?: SeriesHoverMode | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    ignoreEmptyPoints?: boolean | undefined;
    label?: Record<string, any> | {
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        customizeText?: ((pointInfo: any) => string) | undefined;
        displayFormat?: string | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        position?: RelativePosition | undefined;
        rotationAngle?: number | undefined;
        showForZeroValues?: boolean | undefined;
        visible?: boolean | undefined;
    } | undefined;
    line?: any;
    maxLabelCount?: number | undefined;
    minBarSize?: number | undefined;
    opacity?: number | undefined;
    point?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode | undefined;
        hoverStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            } | undefined;
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        } | undefined;
        image?: Record<string, any> | string | undefined | {
            height?: number;
            url?: string | undefined;
            width?: number;
        };
        selectionMode?: PointInteractionMode | undefined;
        selectionStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            } | undefined;
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        } | undefined;
        size?: number | undefined;
        symbol?: PointSymbol | undefined;
        visible?: boolean | undefined;
    } | undefined;
    scatter?: any;
    selectionMode?: SeriesSelectionMode | undefined;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    showInLegend?: boolean | undefined;
    stack?: string | undefined;
    stackedbar?: any;
    tagField?: string | undefined;
    type?: PolarChartSeriesType | undefined;
    valueErrorBar?: Record<string, any> | {
        color?: string | undefined;
        displayMode?: ValueErrorBarDisplayMode | undefined;
        edgeLength?: number | undefined;
        highValueField?: string | undefined;
        lineWidth?: number | undefined;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number | undefined;
    } | undefined;
    valueField?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonSeriesSettingsHoverStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle;
    hatching?: Record<string, any> | {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    highlight?: boolean;
    width?: number;
}>;
declare const CommonSeriesSettingsHoverStyle: ((props: ICommonSeriesSettingsHoverStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection | undefined;
        opacity?: number | undefined;
        step?: number | undefined;
        width?: number | undefined;
    } | undefined;
    highlight?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonSeriesSettingsLabelProps = React.PropsWithChildren<{
    argumentFormat?: LocalizationFormat | undefined;
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    connector?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    customizeText?: ((pointInfo: any) => string);
    displayFormat?: string | undefined;
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    position?: RelativePosition;
    rotationAngle?: number;
    showForZeroValues?: boolean;
    visible?: boolean;
}>;
declare const CommonSeriesSettingsLabel: ((props: ICommonSeriesSettingsLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    argumentFormat?: LocalizationFormat | undefined;
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    connector?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    customizeText?: ((pointInfo: any) => string) | undefined;
    displayFormat?: string | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    position?: RelativePosition | undefined;
    rotationAngle?: number | undefined;
    showForZeroValues?: boolean | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ICommonSeriesSettingsSelectionStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle;
    hatching?: Record<string, any> | {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    highlight?: boolean;
    width?: number;
}>;
declare const CommonSeriesSettingsSelectionStyle: ((props: ICommonSeriesSettingsSelectionStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection | undefined;
        opacity?: number | undefined;
        step?: number | undefined;
        width?: number | undefined;
    } | undefined;
    highlight?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IConnectorProps = React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const Connector: ((props: IConnectorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IConstantLineProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    displayBehindSeries?: boolean;
    extendAxis?: boolean;
    label?: Record<string, any> | {
        font?: ChartsFont;
        text?: string | undefined;
        visible?: boolean;
    };
    value?: Date | number | string | undefined;
    width?: number;
}>;
declare const ConstantLine: ((props: IConstantLineProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    displayBehindSeries?: boolean | undefined;
    extendAxis?: boolean | undefined;
    label?: Record<string, any> | {
        font?: ChartsFont | undefined;
        text?: string | undefined;
        visible?: boolean | undefined;
    } | undefined;
    value?: Date | number | string | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IConstantLineLabelProps = React.PropsWithChildren<{
    font?: ChartsFont;
    text?: string | undefined;
    visible?: boolean;
}>;
declare const ConstantLineLabel: ((props: IConstantLineLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IConstantLineStyleProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    label?: Record<string, any> | {
        font?: ChartsFont;
        visible?: boolean;
    };
    width?: number;
}>;
declare const ConstantLineStyle: ((props: IConstantLineStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    label?: Record<string, any> | {
        font?: ChartsFont | undefined;
        visible?: boolean | undefined;
    } | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IConstantLineStyleLabelProps = React.PropsWithChildren<{
    font?: ChartsFont;
    visible?: boolean;
}>;
declare const ConstantLineStyleLabel: ((props: IConstantLineStyleLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IDataPrepareSettingsProps = React.PropsWithChildren<{
    checkTypeForAllData?: boolean;
    convertToAxisDataType?: boolean;
    sortingMethod?: boolean | ((a: {
        arg: Date | number | string;
        val: Date | number | string;
    }, b: {
        arg: Date | number | string;
        val: Date | number | string;
    }) => number);
}>;
declare const DataPrepareSettings: ((props: IDataPrepareSettingsProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    checkTypeForAllData?: boolean | undefined;
    convertToAxisDataType?: boolean | undefined;
    sortingMethod?: boolean | ((a: {
        arg: Date | number | string;
        val: Date | number | string;
    }, b: {
        arg: Date | number | string;
        val: Date | number | string;
    }) => number) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IExportProps = React.PropsWithChildren<{
    backgroundColor?: string;
    enabled?: boolean;
    fileName?: string;
    formats?: Array<ExportFormat>;
    margin?: number;
    printingEnabled?: boolean;
    svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
}>;
declare const Export: ((props: IExportProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    enabled?: boolean | undefined;
    fileName?: string | undefined;
    formats?: ExportFormat[] | undefined;
    margin?: number | undefined;
    printingEnabled?: boolean | undefined;
    svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFontProps = React.PropsWithChildren<{
    color?: string;
    family?: string;
    opacity?: number;
    size?: number | string;
    weight?: number;
}>;
declare const Font: ((props: IFontProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    family?: string | undefined;
    opacity?: number | undefined;
    size?: string | number | undefined;
    weight?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IFormatProps = React.PropsWithChildren<{
    currency?: string;
    formatter?: ((value: number | Date) => string);
    parser?: ((value: string) => number | Date);
    precision?: number;
    type?: CommonFormat | string;
    useCurrencyAccountingStyle?: boolean;
}>;
declare const Format: ((props: IFormatProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    currency?: string | undefined;
    formatter?: ((value: number | Date) => string) | undefined;
    parser?: ((value: string) => number | Date) | undefined;
    precision?: number | undefined;
    type?: string | undefined;
    useCurrencyAccountingStyle?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IGridProps = React.PropsWithChildren<{
    color?: string;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const Grid: ((props: IGridProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHatchingProps = React.PropsWithChildren<{
    direction?: HatchDirection;
    opacity?: number;
    step?: number;
    width?: number;
}>;
declare const Hatching: ((props: IHatchingProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    direction?: HatchDirection | undefined;
    opacity?: number | undefined;
    step?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IHoverStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle;
    hatching?: Record<string, any> | {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    highlight?: boolean;
    width?: number;
    size?: number;
}>;
declare const HoverStyle: ((props: IHoverStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection | undefined;
        opacity?: number | undefined;
        step?: number | undefined;
        width?: number | undefined;
    } | undefined;
    highlight?: boolean | undefined;
    width?: number | undefined;
    size?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IImageProps = React.PropsWithChildren<{
    height?: number;
    url?: string | undefined;
    width?: number;
}>;
declare const Image: ((props: IImageProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    url?: string | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILabelProps = React.PropsWithChildren<{
    font?: ChartsFont;
    text?: string | undefined;
    visible?: boolean;
    customizeHint?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    customizeText?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    format?: LocalizationFormat | undefined;
    indentFromAxis?: number;
    overlappingBehavior?: LabelOverlap;
    argumentFormat?: LocalizationFormat | undefined;
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    connector?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    displayFormat?: string | undefined;
    position?: RelativePosition;
    rotationAngle?: number;
    showForZeroValues?: boolean;
}>;
declare const Label: ((props: ILabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    customizeHint?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string) | undefined;
    customizeText?: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string) | undefined;
    format?: LocalizationFormat | undefined;
    indentFromAxis?: number | undefined;
    overlappingBehavior?: LabelOverlap | undefined;
    argumentFormat?: LocalizationFormat | undefined;
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    connector?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    displayFormat?: string | undefined;
    position?: RelativePosition | undefined;
    rotationAngle?: number | undefined;
    showForZeroValues?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILegendProps = React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    columnCount?: number;
    columnItemSpacing?: number;
    customizeHint?: ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string);
    customizeItems?: ((items: Array<LegendItem>) => Array<LegendItem>);
    customizeText?: ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string);
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    hoverMode?: LegendHoverMode;
    itemsAlignment?: HorizontalAlignment | undefined;
    itemTextPosition?: Position | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    markerSize?: number;
    markerTemplate?: ((legendItem: LegendItem, element: any) => string | any) | template | undefined;
    orientation?: Orientation | undefined;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    rowCount?: number;
    rowItemSpacing?: number;
    title?: Record<string, any> | string | {
        font?: ChartsFont;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: Record<string, any> | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: Record<string, any> | string | {
            font?: ChartsFont;
            offset?: number;
            text?: string;
        };
        text?: string;
        verticalAlignment?: VerticalEdge;
    };
    verticalAlignment?: VerticalEdge;
    visible?: boolean;
    markerRender?: (...params: any) => React.ReactNode;
    markerComponent?: React.ComponentType<any>;
}>;
declare const Legend: ((props: ILegendProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        cornerRadius?: number | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    columnCount?: number | undefined;
    columnItemSpacing?: number | undefined;
    customizeHint?: ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string) | undefined;
    customizeItems?: ((items: Array<LegendItem>) => Array<LegendItem>) | undefined;
    customizeText?: ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string) | undefined;
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    hoverMode?: LegendHoverMode | undefined;
    itemsAlignment?: HorizontalAlignment | undefined;
    itemTextPosition?: Position | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    markerSize?: number | undefined;
    markerTemplate?: template | ((legendItem: LegendItem, element: any) => string | any) | undefined;
    orientation?: Orientation | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    rowCount?: number | undefined;
    rowItemSpacing?: number | undefined;
    title?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: Record<string, any> | {
            bottom?: number | undefined;
            left?: number | undefined;
            right?: number | undefined;
            top?: number | undefined;
        } | undefined;
        placeholderSize?: number | undefined;
        subtitle?: string | Record<string, any> | {
            font?: ChartsFont | undefined;
            offset?: number | undefined;
            text?: string | undefined;
        } | undefined;
        text?: string | undefined;
        verticalAlignment?: VerticalEdge | undefined;
    } | undefined;
    verticalAlignment?: VerticalEdge | undefined;
    visible?: boolean | undefined;
    markerRender?: ((...params: any) => React.ReactNode) | undefined;
    markerComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILegendTitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    placeholderSize?: number | undefined;
    subtitle?: Record<string, any> | string | {
        font?: ChartsFont;
        offset?: number;
        text?: string;
    };
    text?: string;
    verticalAlignment?: VerticalEdge;
}>;
declare const LegendTitle: ((props: ILegendTitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    placeholderSize?: number | undefined;
    subtitle?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        offset?: number | undefined;
        text?: string | undefined;
    } | undefined;
    text?: string | undefined;
    verticalAlignment?: VerticalEdge | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILegendTitleSubtitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    offset?: number;
    text?: string;
}>;
declare const LegendTitleSubtitle: ((props: ILegendTitleSubtitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    offset?: number | undefined;
    text?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILengthProps = React.PropsWithChildren<{
    days?: number;
    hours?: number;
    milliseconds?: number;
    minutes?: number;
    months?: number;
    quarters?: number;
    seconds?: number;
    weeks?: number;
    years?: number;
}>;
declare const Length: ((props: ILengthProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    days?: number | undefined;
    hours?: number | undefined;
    milliseconds?: number | undefined;
    minutes?: number | undefined;
    months?: number | undefined;
    quarters?: number | undefined;
    seconds?: number | undefined;
    weeks?: number | undefined;
    years?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ILoadingIndicatorProps = React.PropsWithChildren<{
    backgroundColor?: string;
    enabled?: boolean;
    font?: ChartsFont;
    show?: boolean;
    text?: string;
    defaultShow?: boolean;
    onShowChange?: (value: boolean) => void;
}>;
declare const LoadingIndicator: ((props: ILoadingIndicatorProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    backgroundColor?: string | undefined;
    enabled?: boolean | undefined;
    font?: ChartsFont | undefined;
    show?: boolean | undefined;
    text?: string | undefined;
    defaultShow?: boolean | undefined;
    onShowChange?: ((value: boolean) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMarginProps = React.PropsWithChildren<{
    bottom?: number;
    left?: number;
    right?: number;
    top?: number;
}>;
declare const Margin: ((props: IMarginProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    bottom?: number | undefined;
    left?: number | undefined;
    right?: number | undefined;
    top?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMinorGridProps = React.PropsWithChildren<{
    color?: string;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const MinorGrid: ((props: IMinorGridProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMinorTickProps = React.PropsWithChildren<{
    color?: string;
    length?: number;
    opacity?: number;
    shift?: number;
    visible?: boolean;
    width?: number;
}>;
declare const MinorTick: ((props: IMinorTickProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    length?: number | undefined;
    opacity?: number | undefined;
    shift?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMinorTickIntervalProps = React.PropsWithChildren<{
    days?: number;
    hours?: number;
    milliseconds?: number;
    minutes?: number;
    months?: number;
    quarters?: number;
    seconds?: number;
    weeks?: number;
    years?: number;
}>;
declare const MinorTickInterval: ((props: IMinorTickIntervalProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    days?: number | undefined;
    hours?: number | undefined;
    milliseconds?: number | undefined;
    minutes?: number | undefined;
    months?: number | undefined;
    quarters?: number | undefined;
    seconds?: number | undefined;
    weeks?: number | undefined;
    years?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IMinVisualRangeLengthProps = React.PropsWithChildren<{
    days?: number;
    hours?: number;
    milliseconds?: number;
    minutes?: number;
    months?: number;
    quarters?: number;
    seconds?: number;
    weeks?: number;
    years?: number;
}>;
declare const MinVisualRangeLength: ((props: IMinVisualRangeLengthProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    days?: number | undefined;
    hours?: number | undefined;
    milliseconds?: number | undefined;
    minutes?: number | undefined;
    months?: number | undefined;
    quarters?: number | undefined;
    seconds?: number | undefined;
    weeks?: number | undefined;
    years?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPointProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    hoverMode?: PointInteractionMode;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number;
    };
    image?: Record<string, any> | string | undefined | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    selectionMode?: PointInteractionMode;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number;
    };
    size?: number;
    symbol?: PointSymbol;
    visible?: boolean;
}>;
declare const Point: ((props: IPointProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    hoverMode?: PointInteractionMode | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    } | undefined;
    image?: Record<string, any> | string | undefined | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    selectionMode?: PointInteractionMode | undefined;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    } | undefined;
    size?: number | undefined;
    symbol?: PointSymbol | undefined;
    visible?: boolean | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPointBorderProps = React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const PointBorder: ((props: IPointBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPointHoverStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    size?: number;
}>;
declare const PointHoverStyle: ((props: IPointHoverStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    size?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPointSelectionStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: ChartsColor | string | undefined;
    size?: number;
}>;
declare const PointSelectionStyle: ((props: IPointSelectionStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    size?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPolarChartTitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment;
    margin?: number | Record<string, any> | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    placeholderSize?: number | undefined;
    subtitle?: Record<string, any> | string | {
        font?: ChartsFont;
        offset?: number;
        text?: string;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    text?: string;
    textOverflow?: TextOverflow;
    verticalAlignment?: VerticalEdge;
    wordWrap?: WordWrap;
}>;
declare const PolarChartTitle: ((props: IPolarChartTitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    placeholderSize?: number | undefined;
    subtitle?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        offset?: number | undefined;
        text?: string | undefined;
        textOverflow?: TextOverflow | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    verticalAlignment?: VerticalEdge | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IPolarChartTitleSubtitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    offset?: number;
    text?: string;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const PolarChartTitleSubtitle: ((props: IPolarChartTitleSubtitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    offset?: number | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISelectionStyleProps = React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
        dashStyle?: DashStyle | undefined;
    };
    color?: ChartsColor | string | undefined;
    size?: number;
    dashStyle?: DashStyle;
    hatching?: Record<string, any> | {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    highlight?: boolean;
    width?: number;
}>;
declare const SelectionStyle: ((props: ISelectionStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    border?: Record<string, any> | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
        dashStyle?: DashStyle | undefined;
    } | undefined;
    color?: ChartsColor | string | undefined;
    size?: number | undefined;
    dashStyle?: DashStyle | undefined;
    hatching?: Record<string, any> | {
        direction?: HatchDirection | undefined;
        opacity?: number | undefined;
        step?: number | undefined;
        width?: number | undefined;
    } | undefined;
    highlight?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISeriesProps = React.PropsWithChildren<{
    argumentField?: string;
    barPadding?: number | undefined;
    barWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    closed?: boolean;
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle;
    hoverMode?: SeriesHoverMode;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    ignoreEmptyPoints?: boolean;
    label?: Record<string, any> | {
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        visible?: boolean;
    };
    maxLabelCount?: number | undefined;
    minBarSize?: number | undefined;
    name?: string | undefined;
    opacity?: number;
    point?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        image?: Record<string, any> | string | undefined | {
            height?: number;
            url?: string | undefined;
            width?: number;
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    };
    selectionMode?: SeriesSelectionMode;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: Record<string, any> | {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    showInLegend?: boolean;
    stack?: string;
    tag?: any | undefined;
    tagField?: string;
    type?: PolarChartSeriesType;
    valueErrorBar?: Record<string, any> | {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    };
    valueField?: string;
    visible?: boolean;
    width?: number;
}>;
declare const Series: ((props: ISeriesProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    argumentField?: string | undefined;
    barPadding?: number | undefined;
    barWidth?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    closed?: boolean | undefined;
    color?: ChartsColor | string | undefined;
    dashStyle?: DashStyle | undefined;
    hoverMode?: SeriesHoverMode | undefined;
    hoverStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    ignoreEmptyPoints?: boolean | undefined;
    label?: Record<string, any> | {
        argumentFormat?: LocalizationFormat | undefined;
        backgroundColor?: string | undefined;
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        connector?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        customizeText?: ((pointInfo: any) => string) | undefined;
        displayFormat?: string | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        position?: RelativePosition | undefined;
        rotationAngle?: number | undefined;
        showForZeroValues?: boolean | undefined;
        visible?: boolean | undefined;
    } | undefined;
    maxLabelCount?: number | undefined;
    minBarSize?: number | undefined;
    name?: string | undefined;
    opacity?: number | undefined;
    point?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode | undefined;
        hoverStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            } | undefined;
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        } | undefined;
        image?: Record<string, any> | string | undefined | {
            height?: number;
            url?: string | undefined;
            width?: number;
        };
        selectionMode?: PointInteractionMode | undefined;
        selectionStyle?: Record<string, any> | {
            border?: Record<string, any> | {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            } | undefined;
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        } | undefined;
        size?: number | undefined;
        symbol?: PointSymbol | undefined;
        visible?: boolean | undefined;
    } | undefined;
    selectionMode?: SeriesSelectionMode | undefined;
    selectionStyle?: Record<string, any> | {
        border?: Record<string, any> | {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        } | undefined;
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle | undefined;
        hatching?: Record<string, any> | {
            direction?: HatchDirection | undefined;
            opacity?: number | undefined;
            step?: number | undefined;
            width?: number | undefined;
        } | undefined;
        highlight?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    showInLegend?: boolean | undefined;
    stack?: string | undefined;
    tag?: any | undefined;
    tagField?: string | undefined;
    type?: PolarChartSeriesType | undefined;
    valueErrorBar?: Record<string, any> | {
        color?: string | undefined;
        displayMode?: ValueErrorBarDisplayMode | undefined;
        edgeLength?: number | undefined;
        highValueField?: string | undefined;
        lineWidth?: number | undefined;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number | undefined;
    } | undefined;
    valueField?: string | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISeriesBorderProps = React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const SeriesBorder: ((props: ISeriesBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISeriesTemplateProps = React.PropsWithChildren<{
    customizeSeries?: ((seriesName: any) => PolarChartSeries);
    nameField?: string;
}>;
declare const SeriesTemplate: ((props: ISeriesTemplateProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    customizeSeries?: ((seriesName: any) => PolarChartSeries) | undefined;
    nameField?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IShadowProps = React.PropsWithChildren<{
    blur?: number;
    color?: string;
    offsetX?: number;
    offsetY?: number;
    opacity?: number;
}>;
declare const Shadow: ((props: IShadowProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    blur?: number | undefined;
    color?: string | undefined;
    offsetX?: number | undefined;
    offsetY?: number | undefined;
    opacity?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISizeProps = React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
}>;
declare const Size: ((props: ISizeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    height?: number | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IStripProps = React.PropsWithChildren<{
    color?: string | undefined;
    endValue?: Date | number | string | undefined;
    label?: Record<string, any> | {
        font?: ChartsFont;
        text?: string | undefined;
    };
    startValue?: Date | number | string | undefined;
}>;
declare const Strip: ((props: IStripProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    endValue?: Date | number | string | undefined;
    label?: Record<string, any> | {
        font?: ChartsFont | undefined;
        text?: string | undefined;
    } | undefined;
    startValue?: Date | number | string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IStripLabelProps = React.PropsWithChildren<{
    font?: ChartsFont;
    text?: string | undefined;
}>;
declare const StripLabel: ((props: IStripLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    text?: string | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IStripStyleProps = React.PropsWithChildren<{
    label?: Record<string, any> | {
        font?: ChartsFont;
    };
}>;
declare const StripStyle: ((props: IStripStyleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    label?: Record<string, any> | {
        font?: ChartsFont | undefined;
    } | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IStripStyleLabelProps = React.PropsWithChildren<{
    font?: ChartsFont;
}>;
declare const StripStyleLabel: ((props: IStripStyleLabelProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ISubtitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    offset?: number;
    text?: string;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const Subtitle: ((props: ISubtitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    offset?: number | undefined;
    text?: string | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITickProps = React.PropsWithChildren<{
    color?: string;
    length?: number;
    opacity?: number | undefined;
    shift?: number;
    visible?: boolean;
    width?: number;
}>;
declare const Tick: ((props: ITickProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    length?: number | undefined;
    opacity?: number | undefined;
    shift?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITickIntervalProps = React.PropsWithChildren<{
    days?: number;
    hours?: number;
    milliseconds?: number;
    minutes?: number;
    months?: number;
    quarters?: number;
    seconds?: number;
    weeks?: number;
    years?: number;
}>;
declare const TickInterval: ((props: ITickIntervalProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    days?: number | undefined;
    hours?: number | undefined;
    milliseconds?: number | undefined;
    minutes?: number | undefined;
    months?: number | undefined;
    quarters?: number | undefined;
    seconds?: number | undefined;
    weeks?: number | undefined;
    years?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITitleProps = React.PropsWithChildren<{
    font?: ChartsFont;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: Record<string, any> | number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    placeholderSize?: number | undefined;
    subtitle?: Record<string, any> | string | {
        font?: ChartsFont;
        offset?: number;
        text?: string;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    text?: string;
    verticalAlignment?: VerticalEdge;
    textOverflow?: TextOverflow;
    wordWrap?: WordWrap;
}>;
declare const Title: ((props: ITitleProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    font?: ChartsFont | undefined;
    horizontalAlignment?: HorizontalAlignment | undefined;
    margin?: number | Record<string, any> | {
        bottom?: number | undefined;
        left?: number | undefined;
        right?: number | undefined;
        top?: number | undefined;
    } | undefined;
    placeholderSize?: number | undefined;
    subtitle?: string | Record<string, any> | {
        font?: ChartsFont | undefined;
        offset?: number | undefined;
        text?: string | undefined;
        textOverflow?: TextOverflow | undefined;
        wordWrap?: WordWrap | undefined;
    } | undefined;
    text?: string | undefined;
    verticalAlignment?: VerticalEdge | undefined;
    textOverflow?: TextOverflow | undefined;
    wordWrap?: WordWrap | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITooltipProps = React.PropsWithChildren<{
    argumentFormat?: LocalizationFormat | undefined;
    arrowLength?: number;
    border?: Record<string, any> | {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    color?: string;
    container?: any | string | undefined;
    contentTemplate?: ((pointInfo: any, element: any) => string | any) | template | undefined;
    cornerRadius?: number;
    customizeTooltip?: ((pointInfo: any) => Record<string, any>) | undefined;
    enabled?: boolean;
    font?: ChartsFont;
    format?: LocalizationFormat | undefined;
    interactive?: boolean;
    opacity?: number | undefined;
    paddingLeftRight?: number;
    paddingTopBottom?: number;
    shadow?: Record<string, any> | {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    shared?: boolean;
    zIndex?: number | undefined;
    contentRender?: (...params: any) => React.ReactNode;
    contentComponent?: React.ComponentType<any>;
}>;
declare const Tooltip: ((props: ITooltipProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    argumentFormat?: LocalizationFormat | undefined;
    arrowLength?: number | undefined;
    border?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    color?: string | undefined;
    container?: any | string | undefined;
    contentTemplate?: template | ((pointInfo: any, element: any) => string | any) | undefined;
    cornerRadius?: number | undefined;
    customizeTooltip?: ((pointInfo: any) => Record<string, any>) | undefined;
    enabled?: boolean | undefined;
    font?: ChartsFont | undefined;
    format?: LocalizationFormat | undefined;
    interactive?: boolean | undefined;
    opacity?: number | undefined;
    paddingLeftRight?: number | undefined;
    paddingTopBottom?: number | undefined;
    shadow?: Record<string, any> | {
        blur?: number | undefined;
        color?: string | undefined;
        offsetX?: number | undefined;
        offsetY?: number | undefined;
        opacity?: number | undefined;
    } | undefined;
    shared?: boolean | undefined;
    zIndex?: number | undefined;
    contentRender?: ((...params: any) => React.ReactNode) | undefined;
    contentComponent?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type ITooltipBorderProps = React.PropsWithChildren<{
    color?: string;
    dashStyle?: DashStyle;
    opacity?: number | undefined;
    visible?: boolean;
    width?: number;
}>;
declare const TooltipBorder: ((props: ITooltipBorderProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    dashStyle?: DashStyle | undefined;
    opacity?: number | undefined;
    visible?: boolean | undefined;
    width?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IValueAxisProps = React.PropsWithChildren<{
    allowDecimals?: boolean | undefined;
    axisDivisionFactor?: number;
    categories?: Array<Date | number | string>;
    color?: string;
    constantLines?: Array<Record<string, any>> | {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: Record<string, any> | {
            font?: ChartsFont;
            text?: string | undefined;
            visible?: boolean;
        };
        value?: Date | number | string | undefined;
        width?: number;
    }[];
    constantLineStyle?: Record<string, any> | {
        color?: string;
        dashStyle?: DashStyle;
        label?: Record<string, any> | {
            font?: ChartsFont;
            visible?: boolean;
        };
        width?: number;
    };
    discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
    endOnTick?: boolean;
    grid?: Record<string, any> | {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    inverted?: boolean;
    label?: Record<string, any> | {
        customizeHint?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        customizeText?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: ChartsFont;
        format?: LocalizationFormat | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: LabelOverlap;
        visible?: boolean;
    };
    linearThreshold?: number | undefined;
    logarithmBase?: number;
    maxValueMargin?: number | undefined;
    minorGrid?: Record<string, any> | {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    minorTick?: Record<string, any> | {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    };
    minorTickCount?: number | undefined;
    minorTickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    minValueMargin?: number | undefined;
    minVisualRangeLength?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    opacity?: number | undefined;
    showZero?: boolean | undefined;
    strips?: Array<Record<string, any>> | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont;
            text?: string | undefined;
        };
        startValue?: Date | number | string | undefined;
    }[];
    stripStyle?: Record<string, any> | {
        label?: Record<string, any> | {
            font?: ChartsFont;
        };
    };
    tick?: Record<string, any> | {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    tickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    type?: AxisScaleType | undefined;
    valueMarginsEnabled?: boolean;
    valueType?: ChartsDataType | undefined;
    visible?: boolean;
    visualRange?: Array<Date | number | string> | CommonChartTypes.VisualRange;
    visualRangeUpdateMode?: ValueAxisVisualRangeUpdateMode;
    wholeRange?: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
    width?: number;
    defaultVisualRange?: Array<Date | number | string> | CommonChartTypes.VisualRange;
    onVisualRangeChange?: (value: Array<Date | number | string> | CommonChartTypes.VisualRange) => void;
}>;
declare const ValueAxis: ((props: IValueAxisProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    allowDecimals?: boolean | undefined;
    axisDivisionFactor?: number | undefined;
    categories?: (string | number | Date)[] | undefined;
    color?: string | undefined;
    constantLines?: Record<string, any>[] | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        displayBehindSeries?: boolean | undefined;
        extendAxis?: boolean | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            text?: string | undefined;
            visible?: boolean | undefined;
        } | undefined;
        value?: Date | number | string | undefined;
        width?: number | undefined;
    }[] | undefined;
    constantLineStyle?: Record<string, any> | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            visible?: boolean | undefined;
        } | undefined;
        width?: number | undefined;
    } | undefined;
    discreteAxisDivisionMode?: DiscreteAxisDivisionMode | undefined;
    endOnTick?: boolean | undefined;
    grid?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    inverted?: boolean | undefined;
    label?: Record<string, any> | {
        customizeHint?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string) | undefined;
        customizeText?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string) | undefined;
        font?: ChartsFont | undefined;
        format?: LocalizationFormat | undefined;
        indentFromAxis?: number | undefined;
        overlappingBehavior?: LabelOverlap | undefined;
        visible?: boolean | undefined;
    } | undefined;
    linearThreshold?: number | undefined;
    logarithmBase?: number | undefined;
    maxValueMargin?: number | undefined;
    minorGrid?: Record<string, any> | {
        color?: string | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    minorTick?: Record<string, any> | {
        color?: string | undefined;
        length?: number | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    minorTickCount?: number | undefined;
    minorTickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number | undefined;
        hours?: number | undefined;
        milliseconds?: number | undefined;
        minutes?: number | undefined;
        months?: number | undefined;
        quarters?: number | undefined;
        seconds?: number | undefined;
        weeks?: number | undefined;
        years?: number | undefined;
    } | undefined;
    minValueMargin?: number | undefined;
    minVisualRangeLength?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    opacity?: number | undefined;
    showZero?: boolean | undefined;
    strips?: Record<string, any>[] | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
            text?: string | undefined;
        } | undefined;
        startValue?: Date | number | string | undefined;
    }[] | undefined;
    stripStyle?: Record<string, any> | {
        label?: Record<string, any> | {
            font?: ChartsFont | undefined;
        } | undefined;
    } | undefined;
    tick?: Record<string, any> | {
        color?: string | undefined;
        length?: number | undefined;
        opacity?: number | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | undefined;
    tickInterval?: number | Record<string, any> | TimeInterval | {
        days?: number | undefined;
        hours?: number | undefined;
        milliseconds?: number | undefined;
        minutes?: number | undefined;
        months?: number | undefined;
        quarters?: number | undefined;
        seconds?: number | undefined;
        weeks?: number | undefined;
        years?: number | undefined;
    } | undefined;
    type?: AxisScaleType | undefined;
    valueMarginsEnabled?: boolean | undefined;
    valueType?: ChartsDataType | undefined;
    visible?: boolean | undefined;
    visualRange?: (string | number | Date)[] | CommonChartTypes.VisualRange | undefined;
    visualRangeUpdateMode?: ValueAxisVisualRangeUpdateMode | undefined;
    wholeRange?: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
    width?: number | undefined;
    defaultVisualRange?: (string | number | Date)[] | CommonChartTypes.VisualRange | undefined;
    onVisualRangeChange?: ((value: Array<Date | number | string> | CommonChartTypes.VisualRange) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IValueErrorBarProps = React.PropsWithChildren<{
    color?: string;
    displayMode?: ValueErrorBarDisplayMode;
    edgeLength?: number;
    highValueField?: string | undefined;
    lineWidth?: number;
    lowValueField?: string | undefined;
    opacity?: number | undefined;
    type?: undefined | ValueErrorBarType;
    value?: number;
}>;
declare const ValueErrorBar: ((props: IValueErrorBarProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    color?: string | undefined;
    displayMode?: ValueErrorBarDisplayMode | undefined;
    edgeLength?: number | undefined;
    highValueField?: string | undefined;
    lineWidth?: number | undefined;
    lowValueField?: string | undefined;
    opacity?: number | undefined;
    type?: undefined | ValueErrorBarType;
    value?: number | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IVisualRangeProps = React.PropsWithChildren<{
    endValue?: Date | number | string | undefined;
    length?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    startValue?: Date | number | string | undefined;
    defaultEndValue?: Date | number | string | undefined;
    onEndValueChange?: (value: Date | number | string | undefined) => void;
    defaultStartValue?: Date | number | string | undefined;
    onStartValueChange?: (value: Date | number | string | undefined) => void;
}>;
declare const VisualRange: ((props: IVisualRangeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    endValue?: Date | number | string | undefined;
    length?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    startValue?: Date | number | string | undefined;
    defaultEndValue?: Date | number | string | undefined;
    onEndValueChange?: ((value: Date | number | string | undefined) => void) | undefined;
    defaultStartValue?: Date | number | string | undefined;
    onStartValueChange?: ((value: Date | number | string | undefined) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
type IWholeRangeProps = React.PropsWithChildren<{
    endValue?: Date | number | string | undefined;
    length?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    startValue?: Date | number | string | undefined;
    defaultEndValue?: Date | number | string | undefined;
    onEndValueChange?: (value: Date | number | string | undefined) => void;
    defaultStartValue?: Date | number | string | undefined;
    onStartValueChange?: (value: Date | number | string | undefined) => void;
}>;
declare const WholeRange: ((props: IWholeRangeProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    endValue?: Date | number | string | undefined;
    length?: number | Record<string, any> | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    startValue?: Date | number | string | undefined;
    defaultEndValue?: Date | number | string | undefined;
    onEndValueChange?: ((value: Date | number | string | undefined) => void) | undefined;
    defaultStartValue?: Date | number | string | undefined;
    onStartValueChange?: ((value: Date | number | string | undefined) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default PolarChart;
export { PolarChart, IPolarChartOptions, PolarChartRef, AdaptiveLayout, IAdaptiveLayoutProps, Animation, IAnimationProps, Annotation, IAnnotationProps, AnnotationBorder, IAnnotationBorderProps, ArgumentAxis, IArgumentAxisProps, ArgumentAxisMinorTick, IArgumentAxisMinorTickProps, ArgumentAxisTick, IArgumentAxisTickProps, ArgumentFormat, IArgumentFormatProps, AxisLabel, IAxisLabelProps, Border, IBorderProps, Color, IColorProps, CommonAnnotationSettings, ICommonAnnotationSettingsProps, CommonAxisSettings, ICommonAxisSettingsProps, CommonAxisSettingsLabel, ICommonAxisSettingsLabelProps, CommonAxisSettingsMinorTick, ICommonAxisSettingsMinorTickProps, CommonAxisSettingsTick, ICommonAxisSettingsTickProps, CommonSeriesSettings, ICommonSeriesSettingsProps, CommonSeriesSettingsHoverStyle, ICommonSeriesSettingsHoverStyleProps, CommonSeriesSettingsLabel, ICommonSeriesSettingsLabelProps, CommonSeriesSettingsSelectionStyle, ICommonSeriesSettingsSelectionStyleProps, Connector, IConnectorProps, ConstantLine, IConstantLineProps, ConstantLineLabel, IConstantLineLabelProps, ConstantLineStyle, IConstantLineStyleProps, ConstantLineStyleLabel, IConstantLineStyleLabelProps, DataPrepareSettings, IDataPrepareSettingsProps, Export, IExportProps, Font, IFontProps, Format, IFormatProps, Grid, IGridProps, Hatching, IHatchingProps, HoverStyle, IHoverStyleProps, Image, IImageProps, Label, ILabelProps, Legend, ILegendProps, LegendTitle, ILegendTitleProps, LegendTitleSubtitle, ILegendTitleSubtitleProps, Length, ILengthProps, LoadingIndicator, ILoadingIndicatorProps, Margin, IMarginProps, MinorGrid, IMinorGridProps, MinorTick, IMinorTickProps, MinorTickInterval, IMinorTickIntervalProps, MinVisualRangeLength, IMinVisualRangeLengthProps, Point, IPointProps, PointBorder, IPointBorderProps, PointHoverStyle, IPointHoverStyleProps, PointSelectionStyle, IPointSelectionStyleProps, PolarChartTitle, IPolarChartTitleProps, PolarChartTitleSubtitle, IPolarChartTitleSubtitleProps, SelectionStyle, ISelectionStyleProps, Series, ISeriesProps, SeriesBorder, ISeriesBorderProps, SeriesTemplate, ISeriesTemplateProps, Shadow, IShadowProps, Size, ISizeProps, Strip, IStripProps, StripLabel, IStripLabelProps, StripStyle, IStripStyleProps, StripStyleLabel, IStripStyleLabelProps, Subtitle, ISubtitleProps, Tick, ITickProps, TickInterval, ITickIntervalProps, Title, ITitleProps, Tooltip, ITooltipProps, TooltipBorder, ITooltipBorderProps, ValueAxis, IValueAxisProps, ValueErrorBar, IValueErrorBarProps, VisualRange, IVisualRangeProps, WholeRange, IWholeRangeProps };
import type * as PolarChartTypes from 'devextreme/viz/polar_chart_types';
export { PolarChartTypes };
