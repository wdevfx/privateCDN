/*!
 * devextreme-react
 * Version: 25.1.2-beta
 * Build date: Tue May 13 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-react
 */

export { ExplicitTypes } from "devextreme/ui/splitter";
import * as React from "react";
import { Ref, ReactElement } from "react";
import dxSplitter, { Properties } from "devextreme/ui/splitter";
import { IHtmlOptions, NestedComponentMeta } from "./core/component";
import type { dxSplitterItem, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemCollapsedEvent, ItemContextMenuEvent, ItemExpandedEvent, ItemRenderedEvent, ResizeEvent, ResizeEndEvent, ResizeStartEvent, dxSplitterOptions } from "devextreme/ui/splitter";
import type { CollectionWidgetItem } from "devextreme/ui/collection/ui.collection_widget.base";
import type { template } from "devextreme/common";
type ReplaceFieldTypes<TSource, TReplacement> = {
    [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];
};
type ISplitterOptionsNarrowedEvents<TItem = any, TKey = any> = {
    onContentReady?: ((e: ContentReadyEvent<TItem, TKey>) => void);
    onDisposing?: ((e: DisposingEvent<TItem, TKey>) => void);
    onInitialized?: ((e: InitializedEvent<TItem, TKey>) => void);
    onItemClick?: ((e: ItemClickEvent<TItem, TKey>) => void);
    onItemCollapsed?: ((e: ItemCollapsedEvent<TItem, TKey>) => void);
    onItemContextMenu?: ((e: ItemContextMenuEvent<TItem, TKey>) => void);
    onItemExpanded?: ((e: ItemExpandedEvent<TItem, TKey>) => void);
    onItemRendered?: ((e: ItemRenderedEvent<TItem, TKey>) => void);
    onResize?: ((e: ResizeEvent<TKey>) => void);
    onResizeEnd?: ((e: ResizeEndEvent<TKey>) => void);
    onResizeStart?: ((e: ResizeStartEvent<TKey>) => void);
};
type ISplitterOptions<TItem = any, TKey = any> = React.PropsWithChildren<ReplaceFieldTypes<Properties<TItem, TKey>, ISplitterOptionsNarrowedEvents<TItem, TKey>> & IHtmlOptions & {
    dataSource?: Properties<TItem, TKey>["dataSource"];
    itemRender?: (...params: any) => React.ReactNode;
    itemComponent?: React.ComponentType<any>;
    defaultItems?: Array<dxSplitterItem>;
    onItemsChange?: (value: Array<dxSplitterItem>) => void;
}>;
interface SplitterRef<TItem = any, TKey = any> {
    instance: () => dxSplitter<TItem, TKey>;
}
declare const Splitter: <TItem = any, TKey = any>(props: ReplaceFieldTypes<Properties<TItem, TKey>, ISplitterOptionsNarrowedEvents<TItem, TKey>> & IHtmlOptions & {
    dataSource?: import("devextreme/data/data_source").DataSourceLike<TItem, TKey> | null | undefined;
    itemRender?: ((...params: any) => React.ReactNode) | undefined;
    itemComponent?: React.ComponentType<any> | undefined;
    defaultItems?: dxSplitterItem<any>[] | undefined;
    onItemsChange?: ((value: Array<dxSplitterItem>) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    ref?: React.Ref<SplitterRef<TItem, TKey>> | undefined;
}) => ReactElement | null;
type IItemProps = React.PropsWithChildren<{
    collapsed?: boolean;
    collapsedSize?: number | string | undefined;
    collapsible?: boolean;
    maxSize?: number | string | undefined;
    minSize?: number | string | undefined;
    resizable?: boolean;
    size?: number | string | undefined;
    splitter?: dxSplitterOptions | undefined;
    template?: ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | template;
    text?: string;
    visible?: boolean;
    render?: (...params: any) => React.ReactNode;
    component?: React.ComponentType<any>;
}>;
declare const Item: ((props: IItemProps) => React.FunctionComponentElement<React.PropsWithChildren<{
    collapsed?: boolean | undefined;
    collapsedSize?: number | string | undefined;
    collapsible?: boolean | undefined;
    maxSize?: number | string | undefined;
    minSize?: number | string | undefined;
    resizable?: boolean | undefined;
    size?: number | string | undefined;
    splitter?: dxSplitterOptions | undefined;
    template?: template | ((itemData: CollectionWidgetItem, itemIndex: number, itemElement: any) => string | any) | undefined;
    text?: string | undefined;
    visible?: boolean | undefined;
    render?: ((...params: any) => React.ReactNode) | undefined;
    component?: React.ComponentType<any> | undefined;
} & {
    children?: React.ReactNode;
} & {
    elementDescriptor: import("./core/configuration/react/element").IElementDescriptor;
}>>) & NestedComponentMeta;
export default Splitter;
export { Splitter, ISplitterOptions, SplitterRef, Item, IItemProps };
import type * as SplitterTypes from 'devextreme/ui/splitter_types';
export { SplitterTypes };
